(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// stage content:
(lib._300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 19
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(5,1,1).p("EAXcgu3MAAABdvMgu3AAAMAAAhdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(1537));

	// Layer 17
	this.instance = new lib.Symbol39("synched",0);
	this.instance.setTransform(154,300.1,1.11,1,0,0,0,149.5,300.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1515).to({startPosition:0,_off:false},0).wait(22));

	// Layer 18
	this.instance_1 = new lib.Symbol46("synched",0);
	this.instance_1.setTransform(147.3,307.7,0.251,0.251,0,0,0,383,159.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1370).to({startPosition:0,_off:false},0).wait(167));

	// Layer 13
	this.instance_2 = new lib.Symbol38("synched",0);
	this.instance_2.setTransform(156.6,371.5,1,1,0,0,0,178.6,228.3);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1253).to({startPosition:0,_off:false},0).wait(284));

	// Layer 20
	this.instance_3 = new lib.Symbol31("synched",0);
	this.instance_3.setTransform(152.1,366.6,1,1,0,0,0,121.9,133.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1263).to({startPosition:0,_off:false},0).to({_off:true},107).wait(167));

	// Layer 16
	this.instance_4 = new lib.Symbol38("synched",0);
	this.instance_4.setTransform(156.6,371.5,1,1,0,0,0,178.6,228.3);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1089).to({startPosition:0,_off:false},0).wait(448));

	// Layer 7
	this.instance_5 = new lib.Symbol12_1("synched",0);
	this.instance_5.setTransform(150,300,1,1,0,0,0,150,300);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1108).to({startPosition:0,_off:false},0).to({_off:true},154).wait(275));

	// OBJECTS
	this.instance_6 = new lib.Symbol25copy2("synched",0);
	this.instance_6.setTransform(157.3,360.2,1.398,1.398,0,0,0,86.1,119.5);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(961).wait(58).to({startPosition:0,_off:false},0).to({_off:true},79).wait(439));

	// Layer 14
	this.instance_7 = new lib.Symbol37("synched",0);
	this.instance_7.setTransform(145.6,-12.9,1,1,0,0,0,183.6,9);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(992).wait(14).to({startPosition:0,_off:false},0).to({_off:true},92).wait(439));

	// Layer 15
	this.instance_8 = new lib.adam("synched",0);
	this.instance_8.setTransform(109.8,294.1,1,1,0,0,0,-47.2,-12.8);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(961).to({startPosition:0,_off:false},0).to({_off:true},538).wait(38));

	// Layer 12
	this.instance_9 = new lib.Symbol38("synched",0);
	this.instance_9.setTransform(156.6,371.5,1,1,0,0,0,178.6,228.3);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(765).to({startPosition:0,_off:false},0).to({_off:true},196).wait(576));

	// Layer 5
	this.instance_10 = new lib.Symbol5_1("synched",0);
	this.instance_10.setTransform(150,247,1,1,0,0,0,150,87.5);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(772).to({startPosition:0,_off:false},0).to({_off:true},189).wait(576));

	// OBJECTS
	this.instance_11 = new lib.Symbol25copy("synched",0);
	this.instance_11.setTransform(157.3,360.2,1.398,1.398,0,0,0,86.1,119.5);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(611).wait(58).to({startPosition:0,_off:false},0).to({_off:true},103).wait(765));

	// Layer 10
	this.instance_12 = new lib.Symbol37("synched",0);
	this.instance_12.setTransform(145.6,-12.9,1,1,0,0,0,183.6,9);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(642).wait(14).to({startPosition:0,_off:false},0).to({_off:true},116).wait(765));

	// Layer 11
	this.instance_13 = new lib.adam("synched",0);
	this.instance_13.setTransform(109.8,294.1,1,1,0,0,0,-47.2,-12.8);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(611).to({startPosition:0,_off:false},0).to({_off:true},161).wait(765));

	// Layer 8
	this.instance_14 = new lib.Symbol38("synched",0);
	this.instance_14.setTransform(156.6,371.5,1,1,0,0,0,178.6,228.3);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(425).to({startPosition:0,_off:false},0).to({_off:true},186).wait(926));

	// Layer 4
	this.instance_15 = new lib.Symbol1_2("synched",0);
	this.instance_15.setTransform(150,300,1,1,0,0,0,150,300);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(437).to({startPosition:0,_off:false},0).to({_off:true},174).wait(926));

	// Layer 2
	this.instance_16 = new lib.Symbol1("synched",0);
	this.instance_16.setTransform(145.3,277.2,0.202,0.202,0,0,0,392.4,312.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16}]}).wait(1537));

	// Layer 24
	this.instance_17 = new lib.Symbol26("synched",0);
	this.instance_17.setTransform(147.5,425.2,1,1,0,0,0,124.1,8.6);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(155).to({startPosition:0,_off:false},0).to({_off:true},135).wait(1247));

	// Layer 23
	this.instance_18 = new lib.Symbol23("synched",0);
	this.instance_18.setTransform(148.1,323.9,1,1,0,0,0,126.2,36);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(80).to({startPosition:0,_off:false},0).to({_off:true},210).wait(1247));

	// OBJECTS
	this.instance_19 = new lib.Symbol25_1("synched",0);
	this.instance_19.setTransform(157.3,360.2,1.398,1.398,0,0,0,86.1,119.5);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(348).to({startPosition:0,_off:false},0).to({_off:true},84).wait(1105));

	// Layer 6
	this.instance_20 = new lib.Symbol37("synched",0);
	this.instance_20.setTransform(145.6,-12.9,1,1,0,0,0,183.6,9);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(321).wait(14).to({startPosition:0,_off:false},0).to({_off:true},95).wait(1107));

	// Layer 1
	this.instance_21 = new lib.adam("synched",0);
	this.instance_21.setTransform(109.8,294.1,1,1,0,0,0,-47.2,-12.8);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(290).to({startPosition:0,_off:false},0).to({_off:true},968).wait(279));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,478.9,600);


// symbols:
(lib.d = function() {
	this.initialize(img.d);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,47);


(lib.m1 = function() {
	this.initialize(img.m1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,175);


(lib.m2 = function() {
	this.initialize(img.m2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,312);


(lib.m3 = function() {
	this.initialize(img.m3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,263);


(lib.m4 = function() {
	this.initialize(img.m4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,61,172);


(lib.m5 = function() {
	this.initialize(img.m5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,43,120);


(lib.m6 = function() {
	this.initialize(img.m6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,171,72);


(lib.m7 = function() {
	this.initialize(img.m7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,83,69);


(lib.m8 = function() {
	this.initialize(img.m8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,261,51);


(lib.p1 = function() {
	this.initialize(img.p1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,279);


(lib.p2 = function() {
	this.initialize(img.p2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.x1 = function() {
	this.initialize(img.x1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.x2 = function() {
	this.initialize(img.x2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,233,356);


(lib.x3 = function() {
	this.initialize(img.x3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,42,41);


(lib.x4 = function() {
	this.initialize(img.x4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,313);


(lib.x5 = function() {
	this.initialize(img.x5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,269,28);


(lib.Tween21 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.d();
	this.instance.setTransform(-119.9,-23.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-119.9,-23.4,240,47);


(lib.Tween17 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXWAu4MAAAhdvMAutAAAMAAABdvg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-149.4,-300,299.1,600.2);


(lib.Tween16 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("A6tGBIAAsBMA1bAAAIAAMBg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-170.9,-38.4,342.1,77);


(lib.Tween15 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9D2029").s().p("A6tFAIAAp/MA1bAAAIAAJ/g");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-170.9,-31.9,342.1,64.1);


(lib.Tween14 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9D2029").s().p("A8qBaIAAizMA5VAAAIAACzg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-183.5,-8.9,367.1,18);


(lib.Tween13 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7490A1").s().p("AgfAQIA7gfIAEAfg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.1,-1.5,6.4,3.3);


(lib.Tween12 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7490A1").s().p("Ag3AcIBog3IAHA3g");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-5.6,-2.8,11.4,5.8);


(lib.Tween11 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7490A1").s().p("AhYAtICmhZIALBZg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-8.8,-4.4,17.8,9);


(lib.Tween10 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7490A1").s().p("Ah1A7IDdh2IAOB2g");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-11.8,-5.9,23.8,12);


(lib.Tween9 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7490A1").s().p("AiaBOIEiibIATCbg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-15.5,-7.8,31.2,15.8);


(lib.Tween8 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7490A1").s().p("AijAyIEsigIAbDdg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-16.4,-11.1,32.9,22.4);


(lib.Tween7 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3C4952").s().p("AgFAAQAAgGAFgBQAGABAAAGQAAAIgGgBQgFABAAgIg");
	this.shape.setTransform(0,0,3.806,3.806);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-2.5,-3,5.2,6.1);


(lib.Tween6 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgHBHIgHALIhZg0IAQgcIArAAIAAAFIgMAAIgMAWIBOAuIAMgUIAPAAIgBAAIAAgCIADAAIACAAIACAAIABAAIAAgBIAAgBIgBgBIgBAAIgBgBIgBABIgBAAIgBgCIADgEIgDAAIgCgCIgCgDIgBgEIgBgCIAAgIIABgFIACgDIADgDIAFgCIACAAIACABIADABIACACIABACIABACIAAADIgGAAIgBgDIgBgBIgCAAIgCAAIgBACIAAACIgBACIAAAIIABADIABABIACABIACgBIABgBIABgCIAGAAIAAACIAAACIgCAEIgDACIgFAAIgCADIABAAIAAgBIABAAIACABIABABIABABIABACIgBACIgBACIgBAAIAKAAIgRAbIgUgLIgHAMgABSAsIgDAAIgBgBIgCgCIAAgBIgBAAIAAABIgBABIgBABIgBABIgCAAIgDAAIgCAAIgCAAIgCgCIgBgDIgBgEIABgBIABgEIABgCIAEgCIAEgBIAEgBIAAgDIAAgBIAAgBIgBgBIgDAAIgDAAIgCACIgCABIgDgEIACgCIACgBIADgBIAEgBIACAAIACABIADABIACACIACACIAAACIAAACIAAAOIABABIAAABIABAAIAAAGgABJAcIgCABIgCABIgCACIAAADIAAABIACACIABAAIACAAIACgCIAAgBIAAgCIAAgFIgBAAgAAJAsIgCAAIgCgBIgBgCIgBgBIAAAAIgBABIgBABIgBABIAAABIgBAAIgCAAIgCAAIgCAAIgCgCIgBgDIgBgEIAAgBIABgEIACgCIADgCIAFgBIACgBIAAgDIAAgBIgBgBIgBgBIAAAAIgDAAIgCACIgCABIgEgEIACgCIACgBIADgBIAEgBIABAAIACABIACABIADACIABACIABACIAAACIAAAOIAAABIABABIABAAIAAAGgAABAcIgBABIgBABIgCACIgBADIABABIABACIACAAIAAAAIABgCIABgBIAAgCIAAgFIgBAAgAASAsIAAgqIAIAAIAAAqgAgWAsIgFgJIgEAJIgJAAIAJgQIgIgOIAIAAIADAFIABABIAAABIAEgHIAIAAIgIAOIAJAQgAgoAIIAAgnIAHAAIAAAFIABAAIADgEIAFgBIADAAIACACIABACIABABIAAADIAAAFIAAAEIAAAEIAAADIAAACIgBACIgBACIgDABIgCAAIgDgBIgDgBIgCgDIAAAAIAAANgAgegYIgBABIgBABIAAAOIABAAIACABIABAAIACAAIABgBIAAgDIAAgEIAAgFIAAgCIAAgBIgBgBIgBgBIgBAAIgCABgAAcAHIAAgFIAYAAIASgdIhOguIgRAdIgiAAIAWgmIAVAMIAGgLIASALIAHgLIBZAzIgVAlgAgdAHIAAgFIAsAAIAAAFgAhDAAQgDgCgCgFQgBgDABgEIABgDIACgCIABgFIABgDIgBgEIgCgDIgDgBIgEACIADgDIAEgBIAGABIAHAEIAGAHQACAFABAGIAAAGQgBADgCADIgDACIgFAAIgCAAQgDAAgDAAgAgFAAIgCAAIgCgCIgBgDIgBgDIAAgCIABgDIACgDIADgCIAFgBIACgBIAAgDIAAgBIAAgBIgCgBIAAAAIgDAAIgCACIgCABIgEgEIACgBIADgCIADgBIADAAIABAAIACAAIACABIADACIABACIABACIAAACIAAAOIAAABIAAAAIABABIABAAIAAAGIgDAAIgCAAIgCgBIgBgBIgBgCIAAAAIgBACIgBAAIgBABIAAABIgBAAIgCAAIgCAAgAAAgPIgBABIgCACIgBADIABABIABACIACAAIAAAAIABgCIABgBIAAgCIAAgFIgBAAIgBABgAAjAAIgIgRIAHgOIAIAAIgHAOIAJARgAASAAIAAgqIAIAAIAAAqg");
	this.shape.setTransform(-0.6,-5.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CB565F").s().p("AkXCQIgEgHIAAghIgCgxQACgeAMgjQAFgTAMgRQAQgXAZgTQA9gpBbgMQArgEASAAIBBAGQBaALA8AqQAZARAQAVQANATAGATIALByIgCASQAAAVgCAAQgMADhCgLIiCgXQgwgIgaAAQgLAAg1AIQheATgoAGQgwAJgUAAQgJAAgEgCgAAIBEIAIgMIATALIASgbIgKAAIAAAAIACgCIAAgCIAAgCIgBgBIgBgBIgCgBIgBAAIAAABIgCAAIADgDIAEgBIAEgCIACgDIAAgCIAAgDIgHAAIAAADIgBABIgCABIgDgBIgBgBIAAgDIAAgJIAAgCIAAgBIABgCIADAAIACAAIABABIAAACIAHAAIAAgCIgBgCIgBgCIgDgBIgCAAIgCgBIgCAAIgFABIgDABIgDAEIAAAFIAAAHIAAADIACAEIACACIACACIACABIgDAEIABABIACAAIABAAIAAAAIACAAIABABIAAABIAAABIgBABIgDAAIgCAAIgCgBIAAADIABAAIgQAAIgLAUIhPguIANgUIAMAAIAAgFIgrAAIgRAaIBaA0IAHgLgABIAZIABABIABABIACABIADABIACAAIAAgGIgBAAIAAgBIgBgBIAAgOIAAgCIAAgCIgCgDIgDAAIgCAAIgCgBIgCAAIgFABIgCAAIgCAAIgDABIAEAFIACgBIACgCIADAAIADAAIABABIAAABIAAABIAAADIgEAAIgFACIgDACIgBACIgCADIAAACIAAAEIACACIACACIACABIACAAIADAAIACgBIABAAIABgBIAAgBIABgBgAAAAZIAAABIACABIACABIACABIACAAIAAgGIgBAAIAAgBIAAgBIAAgOIAAgCIgBgCIgBgDIgDAAIgCAAIAAgBIgCAAIgFABIgDAAIgCAAIgCABIAEAFIABgBIACgCIAEAAIACAAIABABIAAABIAAABIAAADIgDAAIgFACIgDACIgCACIgBADIgBACIABAEIACACIACACIABABIACAAIADAAIACgBIABAAIABgBIAAgBIAAgBgAAPAcIAIAAIAAgnIgIAAgAgSAcIgIgPIAIgNIgIAAIgEAGIAAgBIgBgBIgDgEIgIAAIAIANIgJAPIAJAAIAEgIIAEAIIAIAAgAgsgGIAIAAIAAgOIABAAIACADIADABIADABIACgBIACgBIACgBIABgCIAAgCIAAgDIAAgEIAAgFIAAgEIAAgDIgBgCIgCgCIgCgBIgCAAIgGABIgDAEIAAAAIAAgFIgIAAgAAZgGIA3AAIAVgnIhag0IgGAMIgSgLIgGALIgWgMIgWAmIAjAAIARgeIBOAvIgSAfIgYAAgAghgGIAtAAIAAgFIgtAAgAhJgxIACADIABAEIgBADIgBAEIgCADIgBADQgBAEABADQABAFAEACQADADAFgBIAFgBIADgEQACgCAAgDIABgGQgBgGgCgFIgHgHIgGgEIgGgCIgEACIgDADIAEgCIADABgAgBgpIABABIAAABIAAABIAAADIgDAAIgFACIgDACIgCADIgBACIgBACIABAEIACADIACABIACABIABAAIADAAIACgBIABAAIABgBIAAgBIAAgBIAAAAIABABIABABIACABIACABIACAAIAAgGIgBAAIAAgBIAAAAIAAgBIAAgOIAAgCIgBgCIgBgCIgDgCIgCgBIAAAAIgCAAIgFAAIgCABIgDABIgCACIAEAEIABgBIADgCIADAAIACAAgAAYggIAIARIAJAAIgJgRIAGgOIgHAAgAAPgPIAIAAIAAgqIgIAAgABBAXIgBgCIgBgBIABgDIACgCIACgBIACgBIABAAIAAAFIAAABIAAACIgCACIgCAAIgCAAgAgGAXIgBgCIAAgBIAAgDIACgCIADgBIACgBIAAAAIAAAFIAAABIAAACIgBACIgCAAIgDAAgAgFgVIgCgCIAAgBIABgDIABgCIADgBIACgBIAAAAIAAAFIAAABIAAACIgBACIgCAAIgCAAgAghgWIgBgBIgCgBIAAgNIACgBIABgBIACgBIABAAIABABIABABIAAABIAAABIAAAGIAAAEIAAACIgBACIgCAAIgCAAg");
	this.shape_1.setTransform(-0.3,-4.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#873D44").s().p("AgMAFQgDgCAAgDQAAgCADgCQAGgDAGAAQAHAAAFADQAEACAAACQAAACgEADQgFADgHAAQgGAAgGgDg");
	this.shape_2.setTransform(0,-18.7,3.806,3.806);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#873D44").s().p("AhJAzIgDgDQgCgCABgDIABgJIACgKIAAgFQAAgRAFgQQADgMANgKIALgIQASgIAYgBQAVACANADQAKADAKAIQAOAJADANQADALAAAJIgBATIAFATQABAEgCADQgDAFgegFIgsgIIgEAAQgNAAgUAGQgSAFgGAAQgJAAgDgCg");
	this.shape_3.setTransform(0,1.7,3.806,3.806);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-29.9,-22.1,60.1,44.4);


(lib.Tween5 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A7001E").s().p("AAgBtQgDgogMgmIgQgpIAAAAIgGgRQgPgggQgVIgRgRQgLgLgBgJIAAgCQABgHAGgEQAGgEAGADQAqAgAbA7IALAcIANAhQALAiAEAkIABABIABAMIAAADIACAWIgDAAIgeAEIgBgYg");
	this.shape.setTransform(-3.3,-13.1,3.806,3.806);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F1C9A0").s().p("AABAdQgBAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQgCgbgJgOQADAHgFAKQgGAMgIgJIABgBQADgFACgIQACgLgBgHQAOgCARAAIAAADQACABADAGIAIAMQAHAJgFAEIgBABIABAGQAAABgBABQAAAAAAABQAAABgBAAQAAAAAAAAQgCABgDgEQgDgKgDgFQADAKABAIQABAJgDABQgDACgEgPIgGgVIADARQABAKgCAIIgCAAIgBAAg");
	this.shape_1.setTransform(18,53,3.806,3.806);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F0D1CF").s().p("AgQAIIABgLIAcgEIADAAIAAANQgQAAgOACg");
	this.shape_2.setTransform(15.7,39.3,3.806,3.806);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-28.7,-64.1,57.6,128.4);


(lib.Tween4 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A7001E").s().p("Ag/CBIgCAAIACgWIAAgDIABgMIAAgBQAGgmAKggIAMghIAMgcQAag7ArggQAGgDAGAEQAGAEABAHIAAABIAAABQgBAJgLALIgSARQgRAXgOAeIgFARIAAAAIgKAXIAAAAIgGASQgMAmgDAoIgBAYg");
	this.shape.setTransform(3.4,-13.1,3.806,3.806);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F1C9A0").s().p("AgDALIACgRIgGAVQgEAPgDgCQgFgBAHgbQgDAKgDAFQgDAEgBgBQgBAAAAAAQgBAAAAgBQAAAAAAgBQAAgBAAgBIAAgGIgBgBQgEgFAGgIQACgFAGgHIAGgHIAAgDQAQAAAOACQAAAHACALQACAIACAFIABABQgHAJgGgMQgGgKADgHQgJAPgCAaIAAAAQgBACgCAAQgCgIABgKg");
	this.shape_1.setTransform(-17.9,53,3.806,3.806);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F0D1CF").s().p("AAPAIQgOgCgRAAIABgNIADAAIAcAEIAAALg");
	this.shape_2.setTransform(-15.6,39.3,3.806,3.806);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-28.7,-64,57.7,128.3);


(lib.Tween3 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D77482").s().p("AgBAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQABABAAAAQAAAAABAAQAAAAAAAAQAAAAAAABQgBAAAAAAQAAAAgBABQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape.setTransform(0,0,3.806,3.806);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.8,-0.8,1.8,1.7);


(lib.Tween2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPCBIgLAUIiiheIAdgzIBPAAIAAAJIgWAAIgXAoICPBUIAVglIALAAIAAABIAQAAIgCgBIACgEIAEABIAEABIADgBIACgBIABgCIgBgDIgCgBIgBAAIgBgBIgCABIgCAAIgDgCIAGgIIgEgBIgFgDQgDgCAAgDIgDgGIgBgGIAAgNIABgJIAEgHIAGgFQAEgCAGABIADAAIADAAIAFACIAEADIADAFIAAADIABAEIgMAAIgBgDIgCgCIgDgBIgEABIgCACIgBAEIAAACIAAAQIABAFIACAEIAEABIAEgBIABgEIABgEIANAAIgBAFIgBAEIgDAGQgCACgDABQgEACgFgBIgBAAIgEAGIACAAIACgBIABAAIADABIACABIADACIABADIgBAFIgEADIgBABIASAAIgfAxIgkgVIgNAWgAB2BQIgDgBIgEgDIgCgFIgBgGIAAgEIABgFIAEgEIAGgFIAIgCIAIgBIAAgEIAAgDIgBgCIgDgBIgDgBIgGABIgEACIgDADIgHgIIADgDIAFgCIAFgCIAHAAIAEAAIAEABIAFABIAEADIADAEIABADIAAAEIAAAbIAAACIACABIABAAIAAAKIgEAAIgEgBIgEgBIgCgDIgBgCIgBAAIgBACIgBACIgDABIgCABIgCABIgFAAIgEAAgACEA0IgEABIgDACIgDAEIgBAEIABAEIACACIADABIAEgBIACgDIACgDIAAgDIAAgIIgDAAgAgLBQIgEgBIgDgDIgDgFIgBgGIABgEIABgFIAEgEIAGgFIAIgCIAFgBIAAgEIAAgDIgBgCIgBgBIgDgBIgFABIgEACIgEADIgGgIIAEgDIADgCIAGgCIAIAAIABAAIAEABIAFABIAEADIADAEIABADIAAAEIAAAbIABACIAAABIACAAIAAAKIgEAAIgFgBIgCgBIgDgDIgBgCIgBAAIgBACIgCACIgBABIgBABIgDABIgEAAIgEAAgAABA0IgBABIgEACIgDAEIgBAEIABAEIABACIAEABIACgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAIABgDIAAgDIAAgIIgCAAgAAgBPIAAhLIAOAAIAABLgAgqBPIgIgPIAAAAIgIAPIgPAAIAPgbIgOgbIAPAAIAGALIAAABIABACIAHgOIAPAAIgOAbIAPAbgAhKAOIAAhGIANAAIAAAIIABAAQACgFAEgCQADgCAGAAIAFABIAEACIACADIABAEIABAFIAAAHIAAAJIAAAHIAAAFIgBAFIgBACIgCADIgFACIgEABIgGgBIgFgDIgDgEIgBAAIAAAXgAg3gtIgDACIgCACIAAAYIACACIAEACIADABIACgCIACgCIABgEIAAgHIAAgLIgBgBIgBgEIgBgCIgCAAIgBAAIgDAAgAAyANIAAgJIAtAAIAgg2IiPhUIgfA1Ig9AAIAnhFIAmAXIALgUIAiAVIANgXICiBeIgoBEgAg2ANIAAgJIBSAAIAAAJgAh7AAQgGgEgCgJQgCgGABgHIACgFIADgFIADgIIABgGQAAgEgBgDIgFgFIgEgBQgEAAgEADQADgEAEgCQACgCAEgBQAGAAAGADQAFACAGAFQAHAHADAHQAFAHACAMQABAFgBAFQgBAHgEADQgDAFgDABQgEABgEAAIgEAAQgGAAgGgBgAgLAAIgEgCIgDgDIgDgEIgBgHIABgEIABgFIAFgEIAFgFIAIgCIAGgBIAAgFIgBgCIAAgBIgCgCIgCgBIgFABIgFACIgEADIgGgIIAEgDIAEgCIAGgCIAHAAIABAAIAEABIAFABIAEADIADAEIABAEIAAADIAAAaIABABIAAACIAAABIACAAIAAAKIgEAAIgFgBIgCgBIgCgDIgCgCIgBAAIgBACIgCABIgBACIgBABIgDABIgEABIgEAAgAABgdIgBABIgEACIgCADQgCADAAACIABADIACADIADABIACgBIACgDIABgDIAAgDIAAgIIgCAAgABAgBIgQgeIANgZIAPAAIgNAYIARAfgAAggBIAAhMIAOAAIAABMg");
	this.shape.setTransform(-1.5,5.5);

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A7001E").s().p("AhLCKIADhmQADgyAIg3QAFgjAVgTQAKgKAKgDIAXgBIAOANQAQARAMAVQALAUAJBnQAEA1ACAwg");
	this.shape_1.setTransform(0,0,3.806,3.806);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-28.9,-52.5,58.1,105.3);


(lib.Symbol56 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2A2828").s().p("AEuJ4QhYgVhng1QhVgshTg9QhHgzhKhCQhNhGhJhQQhHhRg7hWQhMhugshtQgmhggIhQIgBgHIAAguIAJgpQAGgdAkgiIAkgmQAWgVAQgOQAbgVAXgJQAcgMAdADQArAEAoAjQA/A2AvBVQASAhAFAaQAHAigLAfQgJAbgXAZQgaAdgXAVQgeAdANArQALAnAlA1QA9BSB0ByQBHBEAvAmQAjAbAUAOQAgAUAdALQAQAGAMACQAiAFAYgYQAlgnAbgWQA2gpA+ASQAxAPA+AsQArAfAbAfQAeAhALAhQARA0ghA1QgQAcgbAaIg4A4QggAig6AHQgOACgPAAQgvAAg9gPg");
	this.shape.setTransform(65.1,64.7);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,130.1,129.4);


(lib.Symbol55 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2A2828").s().p("AEmGUQgZgZAFgmQALhTgXhRQgVhIgxhNQg/hfhghPQhfhQhpghQhRgZhQAJQgWACgNgCQgSgCgOgKQgigYADgpQADgtAogRQAQgIAVgCQANgCAaAAQCOgDCPBFQBfAvBVBNQB1BoBEB7QBEB5AOCFIACALIAABDQgDAIgBAPQgBAQgCAHQgNAsgoALQgLADgKAAQgcAAgYgXg");
	this.shape.setTransform(42.7,42.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,85.5,85.6);


(lib.Symbol54 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2A2828").s().p("ACsD+QgYgDgSgPQgPgOgGgWIgKgoQgFgZgGgPQgchJg+g7Qg3g1hCgXQgOgFgzgMQg5gMgIgyQgFgkAXgZQAXgZApgBQAhAEAuAPQBKAXBCAwQA6AqAsA4QA+BNAcBeQAKAgAEAeQAEAZgLAVQgKAWgVALQgQAJgSAAIgKgBg");
	this.shape.setTransform(25.5,25.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,51.1,51.1);


(lib.Symbol51 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2A2828").s().p("AweEzQgIAAAAgGQAAgEAEgHQANgXANgfQAMgdAKgjQALgnAFglQAGgoAAgvIAAgKQAAgugGgqQgFgkgLgnQgJgjgNgeQgNgfgNgXQgEgHAAgEQAAgGAIAAIBBAAQAIAAAFACQAGADADAEQArA8AVBDQAVBEAABfIAAAKQAAAzgFAkQgFAngLAlQgNAmgOAcQgSAhgTAbQgDAEgGADQgFACgIAAgEgmEAEzQgHAAgGgCQgFgCgEgFQgVgdgQgfQgQgggKgiQgKgfgHgtQgFgpAAguIAAgKQAAhdAWhGQAVhFAqg6QAEgFAFgCQAGgCAHAAIBBAAQAIAAAAAGQAAADgDAIQgPAbgMAbQgMAegKAjQgKAhgGAqQgFAmAAAyIAAAKQAAAyAFAlQAGAqAKAiQAKAjAMAdQAMAbAPAbQADAIAAADQAAAGgIAAgAEdC2QgjgFgcgJQgFgBgEgDQgEgDAAgHIAAgzQAAgFADgDQADgEAGAAIB2AIQAWAAAQgFQAOgFAJgJQAIgIADgOQADgNAAgRIAAgFQAAgQgEgKQgFgLgKgIQgMgHgRgDQgUgEgZAAIhkAAQgFAAgCgCQgCgDAAgEIAAAAIAUjzQAAgFAEgEQADgDAGAAID8AAQAGAAADADQAEAEAAAFIAABBQAAAGgEADQgEAEgFAAIiwAAIgIBZIATAAQApAAAkAHQAkAHAaARQAaARAOAbQAOAdAAAnIAAAGQAABNgtApQgsAphWAAQgfAAgigFgAiFC2QgkgFgagJQgFgBgFgDQgDgCAAgIIAAgzQAAgFADgDQADgEAFAAIB3AIQAVAAAQgFQAPgFAIgJQAIgIADgOQADgNAAgRIAAgFQAAgQgEgKQgEgLgLgIQgKgHgSgDQgUgEgZAAIhlAAQgEAAgCgCQgDgDAAgEIAAAAIAUjzQABgFADgEQAEgDAFAAID7AAQAFAAAEADQAEAEAAAFIAABBQAAAGgEADQgEAEgFAAIivAAIgHBZIASAAQApAAAlAHQAjAHAYARQAbARANAbQAPAdAAAnIAAAGQAABNgtApQgsAphUAAQgfAAgjgFgAooC2QgkgFgbgJQgFgBgEgDQgEgCAAgIIAAgzQAAgFADgDQADgEAGAAIB2AIQAWAAAQgFQAOgFAJgJQAJgJACgNQADgNAAgRIAAgFQAAgQgEgKQgFgLgKgIQgLgHgSgDQgUgEgYAAIhlAAQgFAAgCgCQgCgEAAgDIAAAAIAUjzQABgFADgEQADgDAGAAID8AAQAGAAADADQAEAEAAAFIAABBQAAAGgEADQgEAEgFAAIiwAAIgIBZIATAAQApAAAlAHQAkAHAZARQAaAQAOAcQAOAdAAAnIAAAGQAABNgtApQgsAphWAAQgfAAgigFgEgieACuQghgMgWgaQgXgbgLgpQgMgpAAg5IAAg4QAAg7AMgpQALgpAXgcQAWgaAhgNQAhgMApAAQAoAAAiAMQAgANAXAaQAWAcAMApQAMApAAA7IAAA4QAAA5gMApQgMApgWAbQgXAbggALQggANgqAAQgrAAgfgNgEghtgDQQgNAGgIAOQgIAPgFAYQgFAXAAAoIAAA4QAAAlAFAYQAFAYAIAPQAIAOANAFQAMAGANAAQANAAAMgGQAMgFAJgOQAJgOAEgZQAFgYAAglIAAg4QAAgogFgXQgEgZgJgOQgJgOgMgGQgMgGgNAAQgNAAgMAGgEAi8AC1QgGAAgDgEQgEgFAAgEIAAhCQAAg1AagsQAZgnAlgcIBfhCQANgJAHgIQAHgHACgIQADgJAAgKQAAgVgPgJQgOgJgoAAQgbAAglACIhAAGIgCAAQgFAAgDgEQgDgDAAgGIAAgzQAAgFADgDQAEgDAFgBQAZgIAogGQAlgGAkAAQBaAAAmAfQAmAeAAA/QAAAngTAeQgTAcglAZIhdA+QgSANgMANQgMANgHAOQgHAPAAAQIAAADIDNAAQAGAAAEADQADAEAAAFIAABDQAAAFgDAEQgEAEgGAAgAcpC1QgGAAgDgEQgEgFAAgEIAAhDQAAgFAEgEQADgDAGAAIBWAAIAAkWIhUAkQgFACgDAAQgHAAAAgIIAAhKQAAgHAGgCIB2g4QAHgCAIAAIA7AAQAMAAAAAMIAAF5IBXAAQAFAAAEADQAEAEAAAFIAABDQAAAFgEAEQgEAEgFAAgATMC1QgFAAgEgEQgEgFAAgEIAAhCQAAg1AagsQAZgnAlgcIBfhCQANgJAHgIQAHgHACgIQADgJAAgKQAAgVgPgJQgOgJgoAAQgbAAglACIhAAGIgCAAQgFAAgDgEQgDgDAAgGIAAgzQAAgFADgDQAFgDAEgBQAZgIAogGQAlgGAkAAQBaAAAmAfQAmAeAAA/QAAAngTAeQgTAcglAZIhdA+QgSANgMANQgMANgHAOQgHAPAAAQIAAADIDNAAQAGAAAEADQADAEAAAFIAABDQAAAFgDAEQgEAEgGAAgAM5C1QgGAAgDgEQgEgFAAgEIAAhDQAAgFAEgEQADgDAGAAIBWAAIAAkWIhUAkQgFACgDAAQgHAAAAgIIAAhKQAAgHAGgCIB2g4QAHgCAIAAIA7AAQAMAAAAAMIAAF5IBXAAQAFAAAEADQAEAEAAAFIAABDQAAAEgEAFQgEAEgFAAgA2gC1QgGAAgDgEQgEgFAAgEIAAhCQAAg2AZgrQAbgoAkgbIBfhCQAKgHAKgKQAHgJACgGQACgHAAgMQAAgWgOgIQgOgJgpAAQgZAAgnACIhAAGIgBAAQgFAAgDgEQgEgDAAgGIAAgzQAAgEAEgEQAEgDAFgBQAYgIAogGQAmgGAkAAQBaAAAmAfQAmAfAAA+QAAAogTAdQgSAcgmAZIhdA+QgTAOgLAMQgMANgHAOQgHANAAASIAAADIDNAAQAGAAADADQAEAEAAAFIAABDQAAAEgEAFQgDAEgGAAgA8zC1QgGAAgEgEQgDgEAAgFIAAhDQAAgFADgEQAEgDAGAAIBWAAIAAkWIhUAkQgFACgDAAQgHAAAAgIIAAhKQAAgHAGgCIB2g4QAGgCAJAAIA7AAQAMAAAAAMIAAF5IBXAAQAFAAAEADQAEAEAAAFIAABDQAAAFgEAEQgEAEgFAAg");
	this.shape.setTransform(254.5,30.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,509,61.6);


(lib.Symbol49 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2A2828").s().p("AwlEzQgIAAAAgHQAAgDADgHQANgWAOggQAMgeAKgiQALgnAEglQAHgpAAguIAAgKQAAgvgHgoQgEgmgLgnQgKgigMgeQgNgfgOgYQgDgGAAgEQAAgGAIgBIBBAAQAGAAAGACQAGADAEAFQArA7AUBDQAWBEAABgIAAAKQAAAygGAlQgEAogMAkQgMAmgPAcQgQAggUAcQgEAGgGABQgEACgIAAgEgmLAEzQgIAAgFgCQgFgBgEgGQgWgegPgeQgQghgLghQgJgegHguQgFgqgBgtIAAgKQABheAVhGQAXhFApg5QAEgFAFgDQAIgCAFAAIBBAAQAIABAAAGQAAADgDAHQgPAcgMAbQgNAegKAiQgJAjgGAqQgFAkAAAzIAAAKQAAAyAFAlQAGAqAJAiQAKAiANAeQAMAbAPAbQADAIAAACQAAAHgIAAgEAj9ACuQgggMgXgaQgVgagNgrQgLgnAAg7IAAg3QAAg9ALgnQANgqAVgbQAXgaAggNQAigMApAAQApAAAhAMQAhANAWAaQAXAcAMApQAMApgBA7IAAA3QABA5gMApQgMAqgXAbQgWAaghAMQghAMgpAAQgqAAghgMgEAkvgDRQgMAHgJAOQgJAPgEAYQgFAXAAAoIAAA3QAAAmAFAXQAEAYAJAPQAJAPAMAFQAMAGANgBQANABAMgGQAMgFAJgPQAIgOAFgZQAFgXAAgmIAAg3QAAgogFgXQgFgZgIgOQgJgOgMgHQgMgFgNAAQgNAAgMAFgAUNCuQgggMgXgaQgVgagNgrQgLgnAAg7IAAg3QAAg9ALgnQANgqAVgbQAXgaAggNQAigMApAAQApAAAhAMQAhANAWAaQAXAcAMApQAMApgBA7IAAA3QABA5gMApQgMAqgXAbQgWAaghAMQghAMgpAAQgpAAgigMgAU/jRQgMAHgJAOQgJAPgEAYQgFAXAAAoIAAA3QAAAmAFAXQAEAYAJAPQAJAPAMAFQAMAGANgBQANABAMgGQAMgFAJgPQAIgOAFgZQAFgXAAgmIAAg3QAAgogFgXQgFgZgIgOQgJgOgMgHQgMgFgNAAQgNAAgMAFgAEVC2QgigFgdgJIgJgEQgDgDgBgHIAAgzQABgFADgEQADgDAFAAIB3AIQAYAAAOgFQAOgFAIgJQAJgJACgOQAEgMAAgRIAAgGQAAgPgFgLQgEgLgKgHQgMgHgRgDQgRgDgcAAIhlAAQgEgBgCgDQgDgCAAgEIAAgBIAVjyQAAgFAEgEQAEgDAFgBID8AAQAEABAFADQAEAEAAAFIAABBQAAAFgEAEQgFADgEAAIixAAIgHBaIATAAQApAAAkAHQAiAHAbAQQAaARAPAcQAOAdAAAnIAAAGQAABNgtApQgsAohWAAQgfABgjgFgAiMC2QgkgFgagJIgKgEQgEgDAAgHIAAgzQABgGADgDQADgDAFAAIB3AIQAYAAANgFQAOgFAJgJQAIgJADgOQADgMAAgRIAAgGQAAgPgEgLQgFgLgKgHQgLgHgRgDQgRgDgcAAIhlAAQgEgBgCgDQgDgCAAgEIAAgBIAUjyQAAgFAEgEQAFgDAEgBID6AAQAFABAEADQAFAEAAAFIAABBQAAAFgFAEQgEADgFAAIiuAAIgIBaIATAAQAoAAAmAHQAhAHAaAQQAZARAPAcQAPAdAAAnIAAAGQAABNgtApQgtAohUAAQgeABgjgFgAowC2QgjgFgbgJIgKgEQgDgDAAgHIAAgzQAAgGADgDQADgDAFAAIB3AIQAYAAANgFQAPgFAIgJQAKgKABgNQADgMABgRIAAgGQgBgPgEgLQgEgLgLgHQgKgHgSgDQgRgDgcAAIhlAAQgDgBgDgDQgCgDgBgDIAAgBIAUjyQABgFAEgEQAEgDAFgBID8AAQAFABAEADQAEAEAAAFIAABBQAAAFgEAEQgEADgFAAIixAAIgHBaIASAAQAqAAAkAHQAkAHAaAQQAZARAOAcQAPAdAAAnIAAAGQAABNgtApQgsAohWAAQgfABgjgFgEgimACuQgggMgXgaQgXgcgKgpQgMgpgBg5IAAg3QABg7AMgpQAKgpAXgcQAXgaAggNQAhgMAqAAQApAAAhAMQAgANAWAaQAXAcAMApQAMApAAA7IAAA3QAAA5gMApQgMAqgXAbQgWAaggAMQghAMgpAAQgqAAghgMgEgh0gDRQgNAHgIAOQgJAPgEAYQgFAXAAAoIAAA3QAAAmAFAXQAEAYAJAPQAIAOANAGQAMAGANgBQANABAMgGQALgFAKgPQAIgOAFgZQAFgXAAgmIAAg3QAAgogFgXQgFgZgIgOQgKgOgLgHQgMgFgNAAQgNAAgMAFgAchC1QgEAAgFgEQgDgEAAgFIAAhDQAAgFADgEQAEgDAFAAIBXAAIAAkWIhUAlIgIABQgIAAABgIIAAhKQAAgHAGgCIB2g4QAGgDAJAAIA7AAQAMAAAAANIAAF5IBWAAQAGAAAEADQADAEAAAFIAABDQAAAFgDAEQgFAEgFAAgAMxC1QgEAAgFgEQgEgEAAgFIAAhDQAAgFAEgEQAEgDAFAAIBXAAIAAkWIhUAlIgIABQgIAAAAgIIAAhKQABgHAGgCIB2g4QAGgDAJAAIA7AAQAMAAAAANIAAF5IBWAAQAGAAAEADQAEAEAAAFIAABDQAAAFgEAEQgFAEgFAAgA2nC1QgGAAgDgEQgFgEAAgFIAAhCQABg3AZgqQAbgoAkgaIBehEIAVgQQAHgIACgHQACgGAAgNQAAgVgPgKQgOgIgogBQgZABgnACIhAAGIgBAAQgGAAgDgEQgDgDAAgGIAAgzQAAgEADgEIAJgEQAdgJAkgGQAigFAoAAQBaAAAmAfQAmAfAAA+QAAAogTAdQgTAdglAZIg4AlIgmAYQgSAOgLAMQgNANgGAOQgIANABASIAAADIDNAAQAGAAADADQAEAEAAAFIAABDQAAAFgEAEQgEAEgFAAgA86C1QgFAAgFgEQgEgEAAgFIAAhDQAAgFAEgEQAEgDAGAAIBWAAIAAkWIhVAlIgIABQgGAAgBgIIAAhKQAAgHAHgCIB1g4QAHgDAJAAIA6AAQANAAAAANIAAF5IBWAAQAGAAADADQAFAEAAAFIAABDQAAAFgFAEQgDAEgGAAg");
	this.shape.setTransform(255.2,30.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,510.4,61.5);


(lib.Symbol48 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B23336").s().p("AtcEnQgFAAgEgEQgEgDAAgGIAAnGQAAgIADgEQAEgEAMgDQAdgIAkgEQAjgFAnAAQBQAAApAsQArArAABQIAAAwQAABNgpAtQgoAthTAAIgYgBIgdgEIAABxQAAAFgEAEQgEAEgFAAgArph3IgXACIAADJIAbACIAaABQASAAALgGQALgGAHgKQAHgNACgNQACgQAAgQIAAgwQAAgQgCgQQgCgMgHgNQgHgKgLgHQgMgFgRAAIgeABgEAhIACoQgWgGgOgNQgPgLgKgXQgJgWAAgfIAAgGQgBg4AmgaQAngaBUAAIAjAAIAAgXQAAgcgNgIQgNgJgXAAIhvAEQgFAAgDgCQgEgDAAgHIAAg0QAAgLANgDQAQgEAggFQAfgFAhAAQAjAAAcAIQAcAHAUAQQATAPALAaQALAZAAAkIAADmQAAAGgEADQgEAEgFAAIhIAAQgFAAgFgEQgEgDAAgGIAAgLQgVAQgSAGQgYAIgbAAQgVAAgUgGgEAiGAAMQgLACgHAHQgGAFgDAJQgDAKAAALIAAAGQABAUAJAGQAKAHAWAAQAPgBANgEQANgDAMgHIAAhIIglAAQgRAAgLAEgAYoCoQgVgFgPgOQgQgMgIgWQgKgUAAghIAAgGQAAg4AmgaQAngaBTAAIAjAAIAAgXQAAgdgNgHQgMgJgXAAIhwAEQgEAAgFgCQgDgDAAgHIAAg0QAAgLANgDQAQgEAhgFQAfgFAgAAQAkAAAbAIQAdAHATAQQAUAQALAZQAKAYABAlIAADmQAAAFgFAEQgDAEgGAAIhJAAQgEAAgFgEQgDgEAAgFIAAgLQgVAPgUAHQgWAIgcAAQgVAAgUgGgAZmAMQgKACgIAHQgGAFgDAJQgCAIAAANIAAAGQAAAVAKAFQAKAHAUAAQAQgBANgEQANgDAMgHIAAhIIglAAQgQAAgMAEgATaCEQgpgrAAhQIAAg1QAAhPApgqQApgrBFAAQAfAAAUADQAZAEALADQAGABAEAEQADADABAHIAAA5QAAAGgEADQgDACgGAAIgBAAIgjgDQgRgBgcAAQgKAAgKAEQgJADgIAJQgHAIgEAPQgFARAAATIAAA1QAAAVAFAPQAEAQAHAIQAHAIAKAEQAJADALABQAiAAALgBIAjgEIABAAQAFAAAEADQAEADAAAFIAAA6QgBAHgDADQgCADgIACIgkAGQgZAEgaAAQhEAAgqgqgALPCoQgVgFgPgOQgPgMgKgWQgJgUAAghIAAgGQAAg4AmgaQAmgaBUAAIAjAAIAAgXQAAgcgNgIQgMgJgYAAIhvAEQgFAAgEgCQgCgDAAgHIAAg0QgBgLAMgDQASgFAggEQAfgFAgAAQAjAAAdAIQAcAHATAQQAUAQAKAZQAMAYAAAlIAADmQAAAFgFAEQgDAEgGAAIhJAAQgFAAgEgEQgDgEAAgFIAAgLQgUAPgVAHQgWAIgcAAQgUAAgVgGgAMNAMQgLACgHAHQgGAFgDAJQgCAKAAALIAAAGQAAAUAKAGQAKAHAUAAQAPgBAOgEQAMgDANgHIAAhIIglAAQgRAAgLAEgAmtCoQgUgGgPgNQgPgMgKgWQgJgVAAggIAAgGQAAg4AmgaQAmgaBTAAIAkAAIAAgXQAAgcgNgIQgNgJgXAAIhvAEQgFAAgDgCQgEgEAAgGIAAg0QAAgLANgDQAQgEAggFQAfgFAhAAQAjAAAcAIQAcAGAUARQAUAQALAZQAKAZAAAkIAADmQAAAGgDADQgGAEgEAAIhJAAQgEAAgFgEQgEgDAAgGIAAgLQgTAPgUAHQgXAIgcAAQgUAAgWgGgAluAMQgLACgHAHQgGAFgDAJQgCAKgBALIAAAGQAAAUAKAGQALAHAVAAQAPgBANgEQAMgDANgHIAAhIIgmAAQgQAAgLAEgEAmHACoQgJAAgHgGQgGgIAAgHIAAgqQAAgGACgGIAHgNICNi+IADgFQgBgDgFAAIiCAAQgLAAAAgKIAAg+QAAgEAEgFQAEgEAFABIDtAAQAJgBAHAHQAGAGAAAJIAAAwQAAAGgCAGQgBAFgEAGIiHC3QgBABAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAADAEAAICBAAQAFAAAEADQADADAAAEIAABBQAAAGgEADQgEAEgFAAgAdpCoQgGAAgDgEQgFgDAAgGIAAhSQAAgFAFgEQAEgDAFgBIBMAAQAFABAEADQAEAEAAAFIAABSQAAAFgEAEQgEAEgFAAgAQRCoQgFAAgEgEQgFgFAAgEIAAnBIBpAAIAAHBQAAAFgDAEQgDAEgFAAgAHvCoQgGAAgDgDQgDgDgFgHIhBhmIg8BmIgIAKQgEADgFAAIhXAAQgHAAAAgIQAAgEABgBIByizIhuilIgCgEQAAgEADgDQADgCAEAAIBgAAQAGgBADAEIAIAKIA7BZIA1hZQAFgIADgDQAEgCAEAAIBYAAQAHgBABAJIgBAFIhsCqIB2CuIABAEQAAADgCADQgDADgEAAgABeCoQgGAAgDgBQgEgDgDgFIhdiZIAACVQAAAFgDAEQgEAEgFAAIhPAAQgFAAgFgEQgEgEAAgFIAAnBIBpAAIAAD6IBhiVQAEgGAFgBQAEgCAEAAIBeAAQAJAAAAAGQAAADgDAEIh4CkIB4C0IABAEQAAAJgJAAgAwQCoQgEAAgFgEQgEgDAAgGIAAhSQAAgFAEgEQAFgDAEgBIBNAAQAFABAEADQAEAEAAAFIAABSQAAAFgEAEQgEAEgFAAgAzXCoQgWAAgOgLQgNgLgFgUIgsinQAAgBAAgBQAAAAgBgBQAAAAAAAAQgBgBgBAAQAAAAgBABQAAAAgBAAQAAABAAAAQgBABAAABIgrCnQgGAUgNALQgNALgXAAIgoAAQgLAAgJgCQgKgDgGgEQgIgFgFgJQgGgKgCgNIg6k3IAAgCQAAgFADgEQADgCAEAAIBOAAQAHAAACACQAFABAAAIIAmD0QACAJADAAQADAAABgJIAsipQAEgQAJgHQAJgHAOAAIA2AAQAPAAAJAHQAIAHAEAQIAsCpQACAJADAAQACAAACgJIAmj0QABgIAEgBQADgCAGAAIBOAAQAFAAADACQADAEAAAFIAAACIg7E3QgFAdgPAIQgQAJgUAAgA78CoQgXAAgNgLQgNgLgGgUIgrinQAAgBAAgBQgBAAAAgBQgBAAAAAAQgBgBgBAAQAAAAAAABQgBAAAAAAQgBABAAAAQAAABAAABIgsCnQgFAUgNALQgOALgWAAIgpAAQgLAAgIgCQgKgDgHgEQgHgFgFgJQgHgKgCgNIg5k3IAAgCQAAgFACgEQADgCAFAAIBOAAQAGAAADACQADABACAIIAmD0QACAJACAAQADAAACgJIAsipQAEgQAIgHQAJgHAPAAIA2AAQAPAAAIAHQAIAHAFAQIAsCpQABAJADAAQADAAACgJIAmj0QABgIAEgBQACgCAHAAIBOAAQAEAAADACQADAEAAAFIAAACIg6E3QgGAdgPAIQgPAJgVAAgEgkiACoQgWAAgOgLQgNgLgFgUIgsinQAAgBAAgBQAAAAgBgBQAAAAgBAAQAAgBgBAAQgBAAAAABQAAAAgBAAQAAABAAAAQgBABAAABIgrCnQgGAUgNALQgNALgXAAIgoAAQgLAAgJgCQgKgDgGgEQgIgFgFgJQgGgKgCgNIg6k3IAAgCQAAgFADgEQACgCAFAAIBOAAQAHAAACACQAEABABAIIAmD0QACAJADAAQADAAABgJIAsipQAFgQAIgHQAHgHAQAAIA2AAQAQAAAIAHQAIAHAFAQIArCpQABAJAEAAQACAAACgJIAmj0QACgIADgBQADgCAGAAIBOAAQAFAAADACQACAEAAAFIAAACIg5E3QgGAdgPAIQgQAJgUAAg");
	this.shape.setTransform(269.7,29.6);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,539.3,59.1);


(lib.Symbol36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AB0000").s().p("AhrgnIC7AAIAcBPg");
	this.shape.setTransform(42.9,38.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#AB0000").s().p("AjRhMIFtAAIA2CZg");
	this.shape_1.setTransform(32.7,34.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#AB0000").s().p("Ag4gNIEbAAIApB2gAg4gNIjThOIAVgMIG6AAIAfBag");
	this.shape_2.setTransform(26.9,32.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#AB0000").s().p("AkLhbIAVgMIG6AAIBIDQg");
	this.shape_3.setTransform(26.9,32.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#AB0000").s().p("AkLg4ICMhSIEqAAIBhEWg");
	this.shape_4.setTransform(26.9,28.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#AB0000").s().p("AkLAPIGEjjICTGpg");
	this.shape_5.setTransform(26.9,21.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).wait(934));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgTieIAngCIAAFBg");
	this.shape.setTransform(2.1,20.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AhFkSICLgHIAAIiIhGARg");
	this.shape_1.setTransform(7.1,32.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AiQkPIEhgOIAAIFIjaA2g");
	this.shape_2.setTransform(14.6,32);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AjKkMIGUgUIAAHuIlMBTg");
	this.shape_3.setTransform(20.3,31.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF0000").s().p("AkakIII1gbIAAHNIntB7g");
	this.shape_4.setTransform(28.3,31.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AlnkEILPgjIAAGvIqICgg");
	this.shape_5.setTransform(36.1,31);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0000").s().p("AmrkBINWgqIAAGUIsODDg");
	this.shape_6.setTransform(42.8,30.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF0000").s().p("Andj/IO6guIAAGAItyDbg");
	this.shape_7.setTransform(47.8,30.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0000").s().p("AoXj+IPegwIBQFlIvmD4g");
	this.shape_8.setTransform(53.6,30.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).wait(1263));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AB0000").s().p("AgXFFIAAqMIAvgCIgNKTg");
	this.shape.setTransform(112.8,33);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#AB0000").s().p("AhVE1IAAp5ICrgFIgMKTg");
	this.shape_1.setTransform(106.5,33);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#AB0000").s().p("AiSElIAApmIEkgIIgMKTg");
	this.shape_2.setTransform(100.5,33);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#AB0000").s().p("AjQEVIAApTIGhgLIgNKTg");
	this.shape_3.setTransform(94.3,33);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#AB0000").s().p("Ak7D5IAAoxIJ3gRIgMKTg");
	this.shape_4.setTransform(83.5,33);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#AB0000").s().p("Al9DoIAAodIL6gUIgMKTg");
	this.shape_5.setTransform(77,33);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#AB0000").s().p("AmzDaIAAoMINngXIgMKTg");
	this.shape_6.setTransform(71.5,33);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#AB0000").s().p("AnoDMIAAn7IPRgaIgNKTg");
	this.shape_7.setTransform(66.3,33);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#AB0000").s().p("AofC+IAAnrIQ/gcIgNKTg");
	this.shape_8.setTransform(60.8,33);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#AB0000").s().p("Ao/C1IApnhIRVgdIgMKTg");
	this.shape_9.setTransform(57.6,33);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(869));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgysBIBlgTIAAYnIghACg");
	this.shape.setTransform(5.1,100.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("Ahar5IC1giIAAYxIhvAGg");
	this.shape_1.setTransform(9.1,99.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AiYruIExg5IAAZCIjsANg");
	this.shape_2.setTransform(15.4,98.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AjUrjIGphPIAAZSIlkATg");
	this.shape_3.setTransform(21.4,97.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF0000").s().p("AknrTIJPhuIAAZoIoJAbg");
	this.shape_4.setTransform(29.6,96.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AlvrGILfiIIAAZ6IqaAkg");
	this.shape_5.setTransform(36.9,94.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0000").s().p("Am9q4IN7ilIAAaQIs1Arg");
	this.shape_6.setTransform(44.6,93.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF0000").s().p("AocqmIQ5jJIAAapIv0A2g");
	this.shape_7.setTransform(54.2,91.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0000").s().p("ApnqYITPjkIAAa9IyKA8g");
	this.shape_8.setTransform(61.7,90.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF0000").s().p("Aq3qUIT5jsIB2a8I0qBFg");
	this.shape_9.setTransform(69.7,89.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(976));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7490A1").s().p("Ag1AfIgGg9IB3A9g");
	this.shape.setTransform(6.1,3.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7490A1").s().p("AhzBCIgNiDIEBCDg");
	this.shape_1.setTransform(12.9,6.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7490A1").s().p("Ah2BaIgRizIEPCLIhIAog");
	this.shape_2.setTransform(13.6,9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7490A1").s().p("AhzBrIgUjVIEPCKIiHBLg");
	this.shape_3.setTransform(13.6,10.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#7490A1").s().p("AiHiJIEPCKIj1CJg");
	this.shape_4.setTransform(13.6,13.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).wait(822));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#294964").s().p("Agdi6IA7gGIAAF/IgaACg");
	this.shape.setTransform(3.1,36.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#294964").s().p("Ag3i3IBvgMIAAGAIhMAHg");
	this.shape_1.setTransform(5.7,36.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#294964").s().p("AhniyIDPgWIAAGCIisAPg");
	this.shape_2.setTransform(10.4,35.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#294964").s().p("AiuirIFdglIAAGFIk6Acg");
	this.shape_3.setTransform(17.6,34.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#294964").s().p("AjtikIHbgyIAAGGIm4Ang");
	this.shape_4.setTransform(23.8,34.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#294964").s().p("Ak4icIJxhCIAAGJIpOA0g");
	this.shape_5.setTransform(31.3,33.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#294964").s().p("AlxiWILjhOIAAGLIrAA+g");
	this.shape_6.setTransform(37.1,32.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#294964").s().p("AmsiQINZhaIAAGMIs2BJg");
	this.shape_7.setTransform(43,32.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#294964").s().p("AnniKIPPhmIAAGOIusBTg");
	this.shape_8.setTransform(48.8,31.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#294964").s().p("AoCiHIQFhsIAAGPIviBYg");
	this.shape_9.setTransform(51.6,31.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#294964").s().p("AosiDIRZh0IAAGQIw1Bfg");
	this.shape_10.setTransform(55.7,30.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#294964").s().p("Apah+IS1h+IAAGRIySBog");
	this.shape_11.setTransform(60.3,30.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#294964").s().p("AqCh6IUFiGIAAGSIziBvg");
	this.shape_12.setTransform(64.3,30);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#294964").s().p("Aquh1IVdiQIAAGUI05B3g");
	this.shape_13.setTransform(68.7,29.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#294964").s().p("ArhhwIXDiaIAAGWI2gB/g");
	this.shape_14.setTransform(73.8,29);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#294964").s().p("AsIhsIYRiiIAAGXI3tCGg");
	this.shape_15.setTransform(77.7,28.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#294964").s().p("As4hnIZxisIAAGYI5OCPg");
	this.shape_16.setTransform(82.6,28.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#294964").s().p("AtXhlIaUiwIAbGWI6MCVg");
	this.shape_17.setTransform(85.6,27.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).wait(783));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol21 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("AjuJGQglgIgrgWQgpgWgfgjQghgngTg2QgUg4AAhMQAAgoAJgvQAKgyAagwQAYgxAxguQAvgtBNgkQBRgkBTgTQBTgUBJgDIAAhXQgCgjgEgRQgEgTgLgOQgQgWgfgMQgfgOgrgBQhBABgxATQgwATgpAdQgsAhgYAWIiNiuQAngeAjgYQAogcAwgUQAwgVBCgNQBDgLBYgCQAdABAqAEQAmAEA1AMQAxANAsAVQAsAVAlAjQAqAsARAoQATAqADAkQAEAggBAjIAAImIADANQACAJAHAOQAGAMAOALQANAKAVABIAADLIhXAAQg2AAgngOQgogPgagVQgbgXgRgXQgQgVgMgWIgJAAQgQAVgQATQgOAQgSAPQgOANgaAPQgFAEgcAPQgYALgtAPQgqAMgxAAQgjABgqgJgAAsAAQghAGgmAQQglAQgkAbQgjAcgWAoQgWAqgBA5QAAAnAPAeQAOAfAbATQAaASAlABQAygBAegWQAggVASgiQASgjAFghQAHgogBgYIAAisQgfAGgXAGg");
	this.shape.setTransform(46.3,59.1);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,92.7,118.2);


(lib.Symbol20 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("Ah6MwQgggFgWgFQgYgGgfgLIhAgXIAmhZQAyAPAeAHQAsALAnABQAkAAAagMQAagMALgSQAOgTAAgWQAAgZgMgRQgMgQgQgHQgSgIgOgBIgYgDQgWAAgVAGQgSAEgYAHIgsgqIBwisQgtgEgxgUQgwgTgqgoQgygtgdg6Qgdg7gMhAQgMhDAAg/IAAkJQAAhkAVhUQAWhVAvg/QAvhABPgjQBPgjBxgBQATgBAsADQApADAsALQAsAMAtAZQAsAZAlAtQAjArAOAqQAQAsADAlQAEAnAAAjIjwAAQAAgcgJggQgIgdgagTQgZgTg1gBQgxABgeAVQgcAVgNAgQgNAigDAfQgCAdAAAdIAAFIQAABHAMAnQANArAfASQAhATA2gBQAxAAAbgVQAbgVAMglQAKgmAAgqID+AAQAAAfgFA0QgGAygSA1QgTA1gpAvQgqAvhIAcQhIAdhxABIgKAAIhHBoIAfgIQALgDAMgBQAIgBAPAAQAiAAAgALQAiALAaATQAbAVAPAdQAQAeAAAmQAAA0gXAnQgWAmgnAaQgnAZgvAMQgsAMgxAAQgiAAgcgDg");
	this.shape.setTransform(41.1,81.9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,82.3,163.8);


(lib.Symbol19 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("AiUMKIAA4TIEpAAIAAYTg");
	this.shape.setTransform(15,77.9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,29.9,155.8);


(lib.Symbol18 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("AjuJGQglgIgrgWQgpgWgfgjQghgngTg2QgUg4AAhMQAAgoAJgvQAKgyAagwQAYgxAxguQAvgtBNgkQBRgkBTgTQBTgUBJgDIAAhXQgCgjgEgRQgEgTgLgOQgQgWgfgMQgfgOgrgBQhBABgxATQgwATgpAdQgsAhgYAWIiMiuQAkgdAlgZQAogcAwgUQAwgVBCgNQBDgLBYgCQAdABAqAEQAmAEA1AMQAxANAsAVQAsAVAlAjQAqAsARAoQATAqADAkQAEAggBAjIAAImIADANQACAJAHAOQAGAMAOALQANAKAVABIAADLIhXAAQg2AAgngOQgogPgagVQgbgXgRgXQgQgVgMgWIgJAAQgQAVgQATQgOAQgSAPQgOANgaAPQgFAEgcAPQgYALgtAPQgqAMgxAAQgjABgqgJgAAsAAQghAGgmAQQglAQgkAbQgjAcgWAoQgWAqgBA5QAAAnAPAeQAOAfAbATQAaASAlABQAygBAegWQAggVASgiQASgjAFghQAHgogBgYIAAisQgfAGgXAGg");
	this.shape.setTransform(46.3,59.1);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,92.7,118.2);


(lib.Symbol17 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("ACiIyIifk/IgJAAIibE/Ik6AAIE6o5IkroqIE4AAIBwDpQAFAIAFALIAUArIAHAAIASgsIAHgSIBzjpIE3AAIkpIoIFBI7g");
	this.shape.setTransform(47.6,56.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,95.3,112.5);


(lib.Symbol16 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("ACbMKIk1paIEDoIIE6AAIkWH3IFZJrgAnmMKIAA4TIEoAAIAAYTg");
	this.shape.setTransform(48.7,77.9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,97.4,155.8);


(lib.Symbol15 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("AjuJGQgngIgpgWQgogVgggkQghgmgTg2QgUg5AAhMQAAgoAJgvQAKgxAagxQAZgyAwgsQAwgvBMgjQBSglBSgSQBOgTBOgEIAAhXQgCgkgEgQQgEgSgLgPQgPgVgggOQgggOgqAAQg/AAgzAUQgxATgoAdQgmAcgfAbIiMiuQAfgYArgeQAogbAwgVQAwgVBCgNQBAgLBbgBQAaAAAtAEQAtAFAuAMQAxAMAsAVQAtAWAkAiQApArASApQATAqADAkQAEAggBAjIAAImIACANQADALAHANQAGALAOALQANAKAVABIAADLIhXAAQg1AAgogOQgngOgbgWQgZgVgUgZQgQgWgLgWIgJAAQgQAWgQATQgRAUgPALQgOAMgaAQQgFAEgcAPQgcANgpAMQgqANgxAAQgmAAgngIgAAsAAQgeAFgpARQgkAQglAbQgjAbgWApQgWApgBA6QAAAnAPAfQAPAfAaASQAaASAlABQAygBAegVQAggWASghQARgjAGgiQAHgngBgZIAAisQgWAEggAIg");
	this.shape.setTransform(46.4,59.1);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,92.8,118.2);


(lib.Symbol14 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("Am5L6IAA3cIEUAAIAACyIARAAQAwhmBNgxQBKgyBkAAQBHABAxAVQAvAVAeAiQAeAgARAnQAQAlAHAhQAMAzAFBBQAFBBABBSIABCmIgBCcQgBBBgFAtQgGAugLAgQgLAjgUAfQgUAegfAZQgfAZgsAPQgrAOhAABQhGgBgzgWQg0gXgngkQgmgkgfgwIgPAAIAAIKgAgsnmQgfANgZASQgZATgRATIAAH5IAzAmQAaATAdAMQAcAMAgABQAsAAAYgRQAZgSALgkQAKgjADg7QADg3gBhPIgGjfQgBgXgCgLQgFgmgNgZQgMgWgSgMQgPgKgSgDQgPgCgRAAQgjABgeALg");
	this.shape.setTransform(44.3,76.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,88.5,152.6);


(lib.Symbol13copy3 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgtjASUMAmphC/MA0eAeZMgmpBC+g");
	this.shape.setTransform(291.6,311.7);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,583.2,623.3);


(lib.Symbol13copy2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgtjASUMAmphC/MA0eAeZMgmpBC+g");
	this.shape.setTransform(291.6,311.7);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,583.2,623.3);


(lib.Symbol13copy = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgtjASUMAmphC/MA0eAeZMgmpBC+g");
	this.shape.setTransform(291.6,311.7);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,583.2,623.3);


(lib.Symbol13 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("EgtjASUMAmphC/MA0eAeZMgmpBC+g");
	this.shape.setTransform(291.6,311.7);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,583.2,623.3);


(lib.Symbol11 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1182C").s().p("AiwKeQiDhagxivQgkh/AiiIQAOg2Aag/QAPggAkhLQAuhfAQguQAchNgCg9QgChSglhFQgmhFg7gdQgsgVgxAEQhCAGhFAzIgDgDQAzhJBFgqQBFgrBSgIQBrgLBzAwQB0AwBsBoQCaCUBPCKQBhCnAnDkQARBpgbB0QgdB2hGBdQg5BMhMAtQhMAthaAKQghADgfAAQiIAAhshIg");
	this.shape.setTransform(54.7,74.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,109.5,148.6);


(lib.Symbol10 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("AjJIfIBuhlQCpgKBYgzQBrg9AxiQQAchTgNhOQgThrhmgiQhRgag+A0QhBA2AfBTQAQAuAkAUQAhASAdgKQAegLADgfQADgkgmgtQBAAtgFA/QgEA3gxApQgwAogzgJQg5gKgUhIQgoAYgngEIhPgQQAkAGAcgfQAUgXAYg3QAhhKAHgMQAYgtAagLQgZgIgaAVQgPANgdAcQghAZgfALQghAKgpAAQg0ABgrgbQgpgcgUgtQgVguAIgvQAIgzApglQAagYAkgKQAogLAdAPQAkASgFApIgEAeQgBAPAHAHQgYgYgcgDQgYgDgSAOQgRAOgBAWQAAAYAVAWQAeAeBng3QBAgjAPgGQAqgTAUAGQAZAGgYgnQgVgngxgwQiFiBhXAXQASguA9gCQAsgBAzAUQAFgqAKgNQAMgPAsgOQAVgHAhAFQAlAFAQANQAYAVgCAaQgEAmADAKQgLglgYgQQgVgOgWAIQgVAIgGAZQgJAcAPAkQAbBIB5BXIBeBEQA0AnAaAiQA1BEAJBeQAJBagfBWQg7ClimBcQh0A/hyAAQg1AAg1gNg");
	this.shape.setTransform(38.5,55.7);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,77,111.4);


(lib.Symbol6 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("EgteASPIINuNIDsAAInhNBMAu4AbGIGzrzIDtAAIpVQLgAeqBBIKdyDMgu4gbGIp+RSIjsAAIMf1qMA0bAeSIrITPg");
	this.shape.setTransform(291.2,310.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,582.4,621);


(lib.Symbol2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8F694D").s().p("AAEAFQgCgDgCgCIgFgBQgBgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAABAAIAFAEQAEABABAEQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABgBAAIgBAAIgBgBg");
	this.shape.setTransform(17.2,160.5,3.806,3.806);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#8F694D").s().p("AAFAFQgFgFgFgBQgBgBAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQAAAAABAAQAGACAFAGQABAAAAAAQAAABAAAAQAAAAgBABQAAAAAAABIgBAAIgBgBg");
	this.shape_1.setTransform(13.6,161.9,3.806,3.806);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8F694D").s().p("AAEAFQgEgFgFgBQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAQAAAAABAAQAAgBAAABQAEABABADIAFACQAAAAAAABQABAAAAAAQAAABAAAAQAAAAgBABIgBABIgBgBg");
	this.shape_2.setTransform(10.4,163.2,3.806,3.806);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#482505").s().p("AgtAIQgFgDADgFQAGAFARgBIAYgEQAJAAATgEIAWgHQgBAHgDADQgDABgIABQgaAHglAEIgDAAQgJAAgFgEg");
	this.shape_3.setTransform(19.1,168.5,3.806,3.806);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6E3D1B").s().p("AgwAKQACgFAGgEQAHgEAQgFQAQgFAHgBIAAAAQAFACAFAAQAOADASAAIABAIIAAABIgWAFQgTAFgIABIgZAEIgEAAQgOAAgFgFg");
	this.shape_4.setTransform(19.4,164.2,3.806,3.806);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#8F694D").s().p("AgGAFQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAEgCAHgEQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQgHACgDADIgCABIgBAAg");
	this.shape_5.setTransform(86.6,161.9,3.806,3.806);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#8F694D").s().p("AgGAFQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQAEgGAIgCQABAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQgGABgEAFIgBABIgBgBg");
	this.shape_6.setTransform(82.7,160.3,3.806,3.806);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#6E3D1B").s().p("AAAANIgZgHQgRgGgFgFIgBAAIAAgBQAJAAAVgIIAGgCIAAABQAGgBAIADIAQAGQAZAKAHAIQgKAGgOAAQgMAAgOgEg");
	this.shape_7.setTransform(78.8,162.2,3.806,3.806);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#482505").s().p("AgZAGQgPgFgEgBQgGgEABgKIABAAQAGAIARAFIAZAFQAeAJATgKQAGAIgQACIgQACQgVAAgbgJg");
	this.shape_8.setTransform(79.2,165.4,3.806,3.806);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#8F694D").s().p("AgFAFQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQADgFAIgDQAAAAAAAAQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAAAQAAAAgBABQAAAAAAAAQgGABgDAFIgBABIgBgBg");
	this.shape_9.setTransform(78.5,158.6,3.806,3.806);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#5C697B").s().p("AgCAIIAAgPQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAABQAAAAAAABIAAAPQAAABAAAAQAAABgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBg");
	this.shape_10.setTransform(48.8,4.9,3.806,3.806);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#5C697B").s().p("AgCAHIAAgOQAAgDACAAQABAAAAAAQABAAAAAAQABABAAAAQAAABAAABIAAAOQAAAEgDABQgCgBAAgEg");
	this.shape_11.setTransform(57.4,4.6,3.806,3.806);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#5C697B").s().p("AgCAIIAAgPQAAgBAAgBQAAAAABgBQAAAAABAAQAAAAAAAAQAAAAABAAQABAAAAAAQABABAAAAQAAABAAABIAAAPQAAABAAABQAAAAgBABQAAAAgBAAQgBABAAAAQAAAAAAgBQgBAAAAAAQgBgBAAAAQAAgBAAgBg");
	this.shape_12.setTransform(13.9,5,3.806,3.806);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#5C697B").s().p("AgCAIIAAgPQAAgEACAAQABAAAAABQABAAAAAAQABABAAAAQAAABAAABIAAAPQAAADgDAAQgCAAAAgDg");
	this.shape_13.setTransform(22.6,4.8,3.806,3.806);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#9CA0AD").s().p("AgEAdQgBglgCgUIABAAIABAAIADA2QAFgIACgCIABgJIgCgiIABgBIABABIACAsIAAAAQgGAEgEAIIgBABIgBgBg");
	this.shape_14.setTransform(36.6,20.4,3.806,3.806);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9CA0AD").s().p("AALAKIgXgQQAAAAAAAAQAAAAgBgBQAAAAABAAQAAgBAAAAQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAIAXAQQAAAAAAAAQAAAAAAABQABAAAAAAQgBABAAAAIgBABIgBAAg");
	this.shape_15.setTransform(60,14.4,3.806,3.806);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#9CA0AD").s().p("AgLALQAAAAAAAAQgBgBAAAAQAAAAABgBQAAAAAAAAQAQgQAFgEQAAAAABAAQAAAAAAAAQABAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQgBABAAAAQAAAAAAAAQgGAFgPAOIgBABIgBgBg");
	this.shape_16.setTransform(12.1,17,3.806,3.806);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#5F6B7E").s().p("AAPDEIgEgCIADgBQghhpgEjcIAAgBIgBhBIAOAAQgFA1ADAhIAJBqQAXC0AFAZQgGgBgEgCg");
	this.shape_17.setTransform(16.1,83.3,3.806,3.806);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#A05927").s().p("AgbAHIAAgNIA3AAIAAANg");
	this.shape_18.setTransform(17.5,4.6,3.806,3.806);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F6DEAB").s().p("AgIALIAAgVIARAAIAAAVg");
	this.shape_19.setTransform(32.3,4.7,3.806,3.806);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#4C5D72").s().p("AAEDFQgEgYgYi0IgJhqQgDgiAFg0IAqAAIAAAEIAUAAIABA6IgCABIAAAAQgXAQADB9QADBzAQBCQAEAHACAHQgRAAgOgDg");
	this.shape_20.setTransform(24.1,83.8,3.806,3.806);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F6DEAB").s().p("AgFALIAAgVIALAAIAAAVg");
	this.shape_21.setTransform(38.6,4.7,3.806,3.806);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A05927").s().p("AgeAHIAAgNIA7AAIACANg");
	this.shape_22.setTransform(53.2,4.6,3.806,3.806);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#475769").s().p("AARC+IABAAQgBiDgPhcQgCgXgLgjQgRgzgQAGIgBg6IANAAIAAgEIAsAAQAHAZASB9QAEAjACBkQACBhABAGIAAACQgVAHgJAAg");
	this.shape_23.setTransform(53.7,83.4,3.806,3.806);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3E4C5E").s().p("AALDCQgBgGgChiQgBhjgFgjQgPh9gHgZIASAAIAGA+QAZDCgLCDIgGACg");
	this.shape_24.setTransform(66.8,81.9,3.806,3.806);

	this.addChild(this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,98.6,173.2);


(lib.Tween53 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9D2029").s().p("An6E4QgUgEgPgKQgNgIgHgJQgHgKAAgKQABgQASgOIAFgDIABABQARARAVAKIAXAIQALADALAAQAaAAANgIQAMgJAAgRQABgKgKgIQgKgIgUgGIglgJQgTgFgRgJQgKgFgHgHQgHgGgGgIQgEgJgDgKQgCgJgBgMQAAgPAFgMQADgNAJgKQAHgKAMgHQANgIAPgFQAVgGAYAAQAYAAATAEQATAEAOAIQANAIAGAIQAHAJgBAKQAAAJgEAIQgFAHgLAHIgFACQgPgRgSgJQgTgIgXAAQgYAAgMAIQgMAIAAARQAAALAJAHQAJAGASAEQAaAGAUAGQAbAJARAMQAOALAHAPQAHAOAAASQABAwgkAWQgOAKgUAEQgUAFgZAAQgaAAgVgFgAtcEoQgOgJgIgLQgGgLAAgMQgBgIAEgGQADgGAHgFQAJgGALAAIAEABQAEALAGAJQAFAIAKAGQAIAFAMADQALADAOAAQAWAAAPgJQAIgFAFgIQAFgIAAgKQAAgKgEgHQgCgHgHgFQgGgFgJgCQgJgDgNAAIgOAAQgQAAgHgFQgIgGAAgKIAAgEQAAgKAHgGQAIgFAOAAIAVAAQAUAAAKgIQAKgJAAgQQAAgJgDgGQgDgHgHgFQgGgEgKgCIgWgCQgMAAgKACQgKADgIAFQgHAFgGAHQgGAIgDAKIgFABQgKAAgJgGQgHgEgDgHQgEgGAAgIQABgLAGgLQAHgKANgJQAPgJATgFQASgEAWAAQBuAAAABMQAAALgDAJQgDAJgGAIQgGAHgJAGQgJAFgNAEQAOAEAKAHQAKAGAHAJQAHAJADALQADAMAAANQAAAXgJARQgIARgTALQgPAIgTAFQgUAEgZAAQgxAAgegVgAFGE5QgOgCgLgFQgMgGgKgHQgKgIgJgLQgIgKgGgLIgKgXQgFgRgDgmIAAgDQAAgMAIgFQAFgFALAAIC2AAQgCgRgHgMQgGgNgKgKQgMgMgPgGQgPgGgRAAQgXAAgRAHQgQAGgKANIgQAWQgNgCgIgGQgLgJAAgPQAAgMAJgLQAIgLAOgJQASgMAVgGQAUgHAYAAQAPAAAOADQANADANAFQAMAFALAHQAMAIAKAKQAJALAHALQAIAMAEANQAFANADAPIACAeQgBAXgFAVQgFAVgLARQgKASgPAOQgPAOgTAJQgNAGgNACQgNADgPAAQgOAAgNgDgAEjDiQAFAKAGAIQAKAKAMAGQANAFAQAAQAQAAANgFQAOgGALgKQAJgJAFgKQAGgLAFgOIiUAAQACAPAFALgAjiE5QgNgCgLgFQgMgGgLgHQgKgIgJgLQgIgKgGgLIgKgXQgFgRgDgmIAAgDQAAgMAIgFQAGgFAKAAIC2AAQgCgRgHgMQgFgNgKgKQgMgMgPgGQgPgGgSAAQgWAAgRAHQgQAGgKANIgQAWQgOgCgIgGQgLgJAAgPQABgMAIgLQAIgLAPgJQASgMAUgGQAVgHAXAAQAPAAAOADQAOADAMAFQANAFALAHQALAIAKAKQAJALAIALQAHAMAEANQAFANADAPIACAeQAAAXgFAVQgGAVgKARQgKASgQAOQgOAOgUAJQgMAGgOACQgNADgPAAQgOAAgNgDgAkFDiQAFAKAHAIQAJAKAMAGQANAFAQAAQARAAANgFQAOgGAKgKQAJgJAGgKQAGgLAEgOIiTAAQACAPAEALgAM9E5QgOAAgGgHQgHgHAAgPIAAjhQAAgPAHgHQAGgHAOAAIAJAAQAOAAAHAHQAHAHAAAPIAADhQAAAPgHAHQgHAHgOAAgAIsE3QgQAAgIgJQgJgIAAgSIAAjRQAAgSAJgJQAIgIAQAAIBgAAQAZAAASAEQASAEAMAJQANAJAFAOQAHANAAASQAAALgDAKQgEAJgGAHQgHAIgIAGQgKAFgNADQAPAEAMAGQALAGAIAJQAHAJAEALQAEALAAAOQAAAXgJAQQgJARgSAJQgNAHgTAEQgTADgZAAgAJKEIIA5AAQAZAAALgHQAIgEAEgIQAEgIAAgLQAAgJgEgHQgDgHgGgEQgHgFgJgCQgKgCgNAAIg5AAgAJKCVIA2AAQAVAAAMgJQALgJAAgSQAAgRgLgJQgLgIgWAAIg2AAgAADE3QgPAAgIgJQgJgIAAgSIAAjRQAAgSAJgJQAIgIAPAAIBgAAQAYAAASAEQATAEAMAJQAMAJAGAOQAGANAAASQAAALgDAKQgDAJgHAHQgGAIgJAGQgKAFgMADQAPAEAMAGQALAGAIAJQAHAJADALQAEALABAOQgBAXgIAQQgJARgSAJQgOAHgTAEQgTADgZAAgAAgEIIA6AAQAZAAALgHQAIgEAEgIQADgIAAgLQABgJgEgHQgEgHgFgEQgHgFgKgCQgKgCgMAAIg6AAgAAgCVIA2AAQAWAAAMgJQALgJgBgSQABgRgLgJQgMgIgWAAIg2AAgAMpAAQgKgIAAgOQAAgPALgJQAJgJAPAAQAPAAAKAJQAJAJAAAPQAAAOgJAIQgJAIgQAAQgPAAgKgIgAjxg5QgFgCAAgEIAAgCIAJgWQgPgEgMgIQgNgIgIgMQgJgMgEgOQgEgNAAgQQAAgKABgJQACgJADgIQADgJAFgHQAEgHAHgGQAGgHAHgEIAPgIQAIgDAJgCQAJgCAKAAQAPAAANAEQANADAJAIQAIAFAFAHQADAGAAAGQAAAIgDAFQgFAEgIADIgFABIgBAAQgDgGgFgFQgEgEgFgDQgGgDgGgCIgNgBQgMAAgJAEQgKAEgGAIQgHAIgDAJQgEAKAAALQAAAMAEAKQADAKAIAIQAHAHAJAEQAJAEALAAQAIAAAHgCIAMgFQAFgDAEgFQAEgFADgGIABgBQAGAAAHAFQAJAGAAAKQABAGgEAFQgDAGgGAGQgJAHgKAEQgKAFgNABIgcAcQgCACgGAAgApDhYQgMgCgKgGQgIgFgEgGQgEgGAAgHQAAgJALgJIADgBIABAAQALAKAMAHIAOAFIAOABQAQAAAIgFQAIgFAAgLQAAgGgGgFQgHgFgMgDIgXgGQgLgDgLgGQgFgDgFgEIgIgJQgDgFgBgGQgCgGAAgHQAAgJADgIQACgIAFgGQAFgGAIgFQAHgFAKgDQANgEAPAAQAOAAAMADQAMADAIAFQAIAEAEAGQAEAFAAAGQAAAGgEAEQgCAFgHAEIgDACQgJgLgLgFQgMgGgOAAQgPAAgIAFQgHAGAAAKQAAAGAGAFQAFAEALACIAdAIQAQAFALAIQAIAHAFAIQAEAJAAAMQABAdgWAOQgJAGgNACQgMADgQAAQgQAAgMgDgACBhXIgQgFQgHgDgGgFIgMgLQgFgGgEgHIgGgPQgDgKgCgYIAAgBQABgHAEgEQADgDAHAAIBwAAQgBgKgEgIQgDgIgHgGQgHgHgJgEQgKgEgKAAQgOAAgLAEQgJAEgHAIIgKAOQgJgBgEgEQgHgGAAgJQAAgHAFgHQAGgHAJgGQALgHAMgEQANgEAPAAQAJAAAJACQAIABAHAEQAJADAGAEIANALQAGAHAFAHIAGAPQAEAJABAJIABASQAAAOgDANQgDANgGALQgHALgJAJQgJAIgNAGQgHADgIACQgJACgIAAQgKAAgHgCgABriNQADAGAEAFQAGAHAIADQAHADALAAQAKAAAIgDQAIgDAGgHQAGgFAEgHQADgGADgJIhbAAQABAJADAHgARehXQgHAAgEgDQgGgCgCgFIhOhrIAABjQAAAJgEAEQgFAFgJAAIgDAAQgIAAgFgFQgDgEAAgJIAAiKQAAgJADgFQAFgFAJAAIAEAAQAMAAAJALIBKBnIAAhgQAAgJAEgFQAFgEAIAAIADAAQAJAAAEAEQAEAFAAAJIAACJQAAAKgEAFQgEAFgJAAgAOghXQgIAAgFgFQgEgEAAgJIAAiLQAAgJAEgFQAFgEAIAAIAFAAQAJAAAFAEQADAFAAAJIAACLQAAAJgDAEQgFAFgJAAgAKyhXQgIAAgEgFQgFgEAAgJIAAiLQAAgJAFgFQAEgEAIAAIAGAAQAJAAAEAEQAEAFAAAJIAACLQAAAJgEAEQgEAFgJAAgAJthXQgGAAgFgDQgFgCgDgFIhOhrIAABjQAAAJgEAEQgEAFgJAAIgDAAQgJAAgEgFQgEgEAAgJIAAiKQAAgJAEgFQAEgFAJAAIAFAAQAMAAAIALIBLBnIAAhgQgBgJAFgFQAEgEAJAAIADAAQAJAAADAEQAFAFAAAJIAACJQAAAKgFAFQgDAFgJAAgAGvhXQgJAAgEgFQgEgEAAgJIAAiLQAAgJAEgFQAEgEAJAAIAFAAQAJAAAFAEQADAFABAJIAACLQgBAJgDAEQgFAFgJAAgAE4hXQgIAAgEgFQgEgEAAgJIAAg1Ig8haQAAgDAFgFQAIgGAMAAQAFAAAFADQAEAEAFAGIAkA8IAlg7QAEgHAFgEQAFgDAFAAQAKAAAIAGQAGAFAAAEIg8BZIAAA1QgBAJgEAEQgEAFgJAAgAAbhXQgIAAgEgFQgEgEAAgJIAAhnIgaBGQgEAIgEACQgEACgJAAQgLAAgDgDQgDgDgDgGIgdhFIAABmQAAAJgDAEQgEAFgIAAIgGAAQgIAAgEgFQgDgEAAgJIAAiJQAAgKAEgFQAFgFAKAAIALAAQAIAAAFADQAEADAEAIIAiBSIAkhSQABgIAEgDQAFgDAIAAIAKAAQAKAAAFAFQAFAFAAAKIAACJQABAJgEAEQgFAFgIAAgArFhXQgIAAgFgFQgEgEAAgJIAAiLQAAgJAEgFQAFgEAIAAIAFAAQAJAAAFAEQADAFAAAJIAACLQAAAJgDAEQgFAFgJAAgAuzhXQgJAAgDgFQgFgEAAgJIAAiLQAAgJAFgFQADgEAJAAIAGAAQAIAAAEAEQAFAFAAAJIAACLQAAAJgFAEQgEAFgIAAgAL7hYQgLAAgFgEQgHgFABgIIAAgCQgBgMANgPIBPheIhJAAQgJAAgDgEQgFgEAAgHIAAgCQAAgIAFgEQADgEAJAAIBlAAQALAAAGAEQAGAEAAAJIAAACQAAAFgEAHIgJAOIhRBfIBPAAQAJAAAEADQAEAEABAIIAAACQgBAIgEAEQgEAEgJAAgAm0hYQgKAAgGgGQgEgFAAgLIAAiBQAAgLAEgGQAGgFAKAAIBhAAQAIAAAFAEQAFAEAAAJIAAABQAAAIgFAEQgFAEgIAAIhOAAIAAAjIA4AAQAKAAAEADQAFAEgBAIIAAABQABAIgFAEQgEAEgKAAIg4AAIAAAmIBPAAQAJAAAEADQAFAEAAAIIAAACQAAAIgFAEQgEAFgJAAgAtqhYQgLAAgGgEQgFgFAAgIIAAgCQgBgMANgPIBPheIhIAAQgJAAgFgEQgEgEAAgHIAAgCQAAgIAEgEQAFgEAJAAIBkAAQAMAAAFAEQAGAEAAAJIAAACQgBAFgDAHIgJAOIhRBfIBPAAQAJAAAEADQAEAEABAIIAAACQgBAIgEAEQgEAEgJAAgAxchYQgKAAgFgGQgGgFAAgLIAAiBQAAgLAGgGQAFgFAKAAIA7AAQAPAAAMADQALACAHAGQAIAGADAIQAFAIAAALQAAAHgDAGQgCAGgDAEQgFAFgFADQgGAEgIACQAKACAHAEQAGAEAFAFQAFAFACAHQADAHAAAJQAAAOgFAKQgGAKgLAGQgIAEgMADQgMACgQAAgAxKh2IAjAAQARAAAGgEQAFgCACgFQACgFABgHQAAgGgCgEQgCgEgFgDQgEgCgFgCQgHgBgIAAIgjAAgAxKi8IAhAAQAOAAAHgGQAHgFAAgMQAAgKgHgFQgHgGgOAAIghAAgAOTkZQgFgFAAgJQAAgJAFgGQAHgGAJAAQAJAAAGAGQAHAGgBAJQAAAJgFAFQgHAFgJAAQgJAAgHgFgAKmkZQgGgFAAgJQAAgJAGgGQAGgGAKAAQAJAAAFAGQAHAGAAAJQAAAJgGAFQgGAFgJAAQgKAAgGgFgAGikZQgFgFgBgJQABgJAFgGQAHgGAJAAQAKAAAFAGQAGAGAAAJQAAAJgFAFQgHAFgJAAQgJAAgHgFgArSkZQgFgFAAgJQAAgJAFgGQAHgGAJAAQAKAAAFAGQAHAGgBAJQAAAJgFAFQgHAFgJAAQgJAAgHgFgAu/kZQgHgFAAgJQAAgJAHgGQAFgGAKAAQAJAAAGAGQAGAGABAJQAAAJgHAFQgFAFgKAAQgKAAgFgFg");
	this.shape.setTransform(2.3,-9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-111.4,-40.7,227.6,63.5);


(lib.Tween52 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AM1McQgEgCgDgEIgBgCIATgrQgIgBgDgGIgnhbQAAgCAGgDQAFgEAHAAQAGAAAEAEQAFAEADAIIAZBBIAWhBQACgHAFgFQAEgEAHAAQAEAAAEABQAFADADACIABADIgzCGQgDAIgFAEQgFAEgGAAQgFAAgEgBgAK6McQgEgCgDgEIgBgCIATgrQgIgBgDgGIgnhbQAAgCAGgDQAFgEAHAAQAGAAAEAEQAFAEADAIIAZBBIAWhBQACgHAFgFQAEgEAHAAQAEAAAEABQAFADADACIABADIgzCGQgDAIgFAEQgFAEgGAAQgFAAgEgBgAtDMLQgDgBAAgDIAAgCIAHgTQgOgBgJgEQgHgEgDgEQgEgFAAgFQAAgJAIgEIACgBQAIAIAJADQAJAEAMAAQAKAAAFgDQAFgDAAgFQAAgEgEgDQgFgDgIgCIgQgDQgIgBgHgEQgIgFgEgGQgFgHAAgKQAAgGACgFQACgGADgDQAEgFAFgEQAFgCAHgDQAIgCAMAAIAPABQAHABAGADQAJACAEAGQAFAEAAAHQAAAEgCAEQgCADgEACIgDABQgGgIgJgEQgIgDgKAAQgKAAgFACQgEADAAAGQAAADAEAEQAEADAJABIAQAEIAQAEQAIAFAEAHQAFAHAAAJQAAAHgCAFQgCAFgDAFQgEAEgFADIgMAFQgBADgHAGIgSASQgCACgEAAgAOwLwQgKgEgIgIQgHgIgEgKQgEgLAAgMIAAgCQAAgFACgCQACgCAEAAIBOAAQgBgGgDgFQgDgGgEgDQgEgDgGgDQgGgBgGAAQgGAAgIAEQgIAFgLAIQgEAAgEgEQgHgEAAgIQAAgJAMgIQAIgEAJgCQAJgCALAAQAcAAARAQQAIAIAEAKQAEALAAAOQAAAagQARQgJAJgLAEQgKAEgNAAQgMAAgLgEgAOvLNQACAFAEAEQADADAFACQAFACAFAAQAGAAAFgCQAFgCAEgDQAEgEACgFQADgEABgGIg4AAQAAAGACAEgAhiLwQgKgEgIgIQgHgIgEgKQgEgLAAgMIAAgCQAAgFACgCQACgCAEAAIBOAAQgBgGgDgFQgDgGgEgDQgEgDgGgDQgGgBgGAAQgGAAgIAEQgIAFgLAIQgEAAgEgEQgHgEAAgIQAAgJAMgIQAIgEAJgCQAJgCALAAQAcAAARAQQAIAIAEAKQAEALAAAOQAAAagQARQgJAJgLAEQgKAEgNAAQgMAAgLgEgAhjLNQACAFAEAEQADADAFACQAFACAFAAQAGAAAFgCQAFgCAEgDQAEgEACgFQADgEABgGIg4AAQAAAGACAEgApzLwQgKgEgIgIQgHgIgEgKQgEgLAAgMIAAgCQAAgFACgCQACgCAEAAIBOAAQgBgGgDgFQgDgGgEgDQgEgDgGgDQgGgBgGAAQgGAAgIAEQgIAFgLAIQgEAAgEgEQgHgEAAgIQAAgJAMgIQAIgEAJgCQAJgCALAAQAcAAARAQQAIAIAEAKQAEALAAAOQAAAagQARQgJAJgLAEQgKAEgNAAQgMAAgLgEgAp0LNQACAFAEAEQADADAFACQAFACAFAAQAGAAAFgCQAFgCAEgDQAEgEACgFQADgEABgGIg4AAQAAAGACAEgAQxLxQgGgDgFgEQgFgFgCgHQgCgIAAgJIAAg1IgGAAQgHABgDgDQgDgDAAgFIAAgDQAAgGADgDQADgDAHAAIAGAAIAAgOQAAgIADgEQAEgEAIAAIACAAQAIAAADAEQAEAEAAAIIAAAOIAUAAQAGAAAEADQADADAAAGIAAACQAAAFgDAEQgEACgHAAIgUAAIAAAxQAAAQANAAQAJABAGgIQACAAACAEQADADAAAGQAAAFgCAEQgDAEgFADQgIAFgMgBQgJAAgHgCgAFqLwQgIgDgFgHQgFgHgDgIQgCgIAAgLIAAg2QAAgIADgEQAEgEAHAAIAEAAQAHAAAEAEQADAEAAAIIAAAyQAAAGACAFQABAEADADQACADAEABQAEACAGAAQAIAAAGgDQAGgEAEgHIAAg8QAAgIAEgEQADgEAIAAIADAAQAHAAAEAEQAEAEAAAIIAABgQAAACgGAAIgGABQgJAAgEgEQgFgEgCgKQgHAKgJAGQgKAEgLAAQgLABgIgEgArPLxQgGgDgFgEQgFgFgCgHQgCgIAAgJIAAg1IgGAAQgHABgDgDQgDgDAAgFIAAgDQAAgGADgDQADgDAHAAIAGAAIAAgOQAAgIADgEQAEgEAIAAIACAAQAIAAADAEQAEAEAAAIIAAAOIAUAAQAGAAAEADQADADAAAGIAAACQAAAFgDAEQgEACgHAAIgUAAIAAAxQAAAQANAAQAJABAGgIQACAAACAEQADADAAAGQAAAFgCAEQgDAEgFADQgIAFgMgBQgJAAgHgCgAvNLwQgIgDgFgHQgFgHgCgIQgDgIAAgLIAAg2QAAgIAEgEQADgEAHAAIAEAAQAHAAAEAEQAEAEAAAIIAAAyQAAAGABAFQACAEACADQADADAEABQAEACAFAAQAJAAAGgDQAGgEAEgHIAAg8QAAgIADgEQAEgEAHAAIADAAQAIAAAEAEQADAEAAAIIAABgQAAACgFAAIgHABQgIAAgFgEQgFgEgBgKQgHAKgKAGQgJAEgMAAQgLABgIgEgASALxQgIAAgDgDQgEgFAAgHIAAhUQAAgIAEgEQADgEAIAAIADAAQAHAAAEAEQAEAEAAAIIAABUQAAAHgEAFQgDADgIAAgAJxLxQgIAAgDgDQgEgFAAgHIAAhUQAAgIAEgEQADgEAIAAIADAAQAHAAAEAEQAEAEAAAIIAABUQAAAHgEAFQgDADgIAAgAI4LxQgHAAgEgDQgEgFAAgHIAAgxQAAgZgVAAQgIAAgHAEQgGAEgEAHIAAA7QAAAHgDAFQgEADgHAAIgEAAQgHAAgEgDQgDgFAAgHIAAhgQAAgBAFgCIAHgBQAIAAAFAFQAFAFACAIQAHgJAJgFQAJgGAMAAQAKABAIADQAIADAGAIQAFAGADAHQACAJAAAKIAAA3QAAAHgEAFQgDADgHAAgAEqLxQgHAAgEgDQgEgFAAgHIAAgxQAAgZgVAAQgIAAgHAEQgGAEgEAHIAAA7QAAAHgDAFQgEADgHAAIgEAAQgHAAgEgDQgDgFAAgHIAAhgQAAgBAFgCIAHgBQAIAAAFAFQAFAFACAIQAHgJAJgFQAJgGAMAAQAKABAIADQAIADAGAIQAFAGADAHQACAJAAAKIAAA3QAAAHgEAFQgDADgHAAgACjLxQgHAAgEgDQgEgFAAgHIAAgzQAAgMgFgFQgEgGgKAAQgIAAgFAEQgGADgEAHIAAA8QAAAHgEAFQgDADgHAAIgEAAQgHAAgEgDQgEgFAAgHIAAgyQAAgYgTAAQgHAAgGAEQgGADgEAHIAAA8QAAAHgDAFQgEADgHAAIgEAAQgHAAgEgDQgCgFAAgHIAAhgQAAgBAEgCIAHgBQAIAAAFAFQAFAEACAJQAGgKAJgEQAJgGALAAQAHABAGABQAFACAFADIAIAHQADAEACAGQADgGAFgEIAIgHQAFgDAGgCQAFgBAGgBQAKAAAIADQAIADAFAGQAFAFADAJQACAIAAALIAAA5QAAAHgEAFQgDADgIAAgAioLxQgIAAgDgDQgEgFAAgHIAAgzQAAgMgFgFQgFgGgKAAQgHAAgGAEQgFADgEAHIAAA8QAAAHgEAFQgEADgHAAIgDAAQgIAAgDgDQgEgFAAgHIAAgyQAAgYgUAAQgHAAgFAEQgGADgEAHIAAA8QAAAHgEAFQgDADgIAAIgDAAQgIAAgDgDQgEgFAAgHIAAhgQAAgBAGgCIAGgBQAJAAAFAFQAEAEACAJQAHgKAJgEQAIgGALAAQAHABAGABQAGACAEADIAIAHQADAEACAGQAEgGAEgEIAJgHQAFgDAFgCQAGgBAGgBQAKAAAIADQAHADAFAGQAFAFADAJQADAIAAALIAAA5QAAAHgEAFQgEADgHAAgAmgLxQgIAAgDgDQgEgFAAgHIAAhUQAAgIAEgEQADgEAIAAIADAAQAHAAAEAEQAEAEAAAIIAABUQAAAHgEAFQgDADgIAAgAoCLxQgHAAgEgDQgDgFAAgHIAAhgQAAgBAFgCIAHgBQAJAAAFAFQAFAFABAJQADgKAHgFQAHgFAKgBQALAAAFAGQAGAEAAAJQAAAGgCAEQgCAEgEACIgDACQgFgGgKAAQgFAAgFADQgEACgDAFQgDAEgBAHQgCAHAAAJIAAAiQAAAHgDAFQgEADgHAAgAwPLxQgHAAgDgDQgEgFAAgHIAAhaIgZA9QgDAHgDACQgDACgIAAQgKAAgDgDQgCgCgCgGIgag7IAABYQAAAHgDAFQgDADgHAAIgFAAQgHAAgDgDQgEgFAAgHIAAh4QAAgIAEgEQAFgFAIAAIAKAAQAHABAEACQAEACADAIIAeBGIAfhGQADgIADgCQAEgCAHgBIAJAAQAJAAAEAFQAFAEAAAIIAAB4QAAAHgEAFQgDADgHAAgAR1JuQgEgEAAgJQAAgIAEgEQAEgEAIgBQAJABAEAEQAFAEAAAIQAAAJgFAEQgEAEgIAAQgIAAgFgEgAJmJuQgEgEAAgJQAAgIAEgEQAEgEAIgBQAJABAEAEQAFAEAAAIQAAAJgFAEQgEAEgIAAQgIAAgFgEgAmrJuQgEgEAAgJQAAgIAEgEQAEgEAIgBQAJABAEAEQAFAEAAAIQAAAJgFAEQgEAEgIAAQgIAAgFgEgAugJuQgFgEAAgJQAAgIAEgEQAFgEAIgBQAIABAFAEQAEAEAAAIQAAAJgEAEQgEAEgJAAQgIAAgEgEgAvQJuQgEgEAAgJQAAgIAEgEQAEgEAJgBQAIABAEAEQAFAEAAAIQAAAJgEAEQgEAEgJAAQgIAAgFgEgAAMHPQgMgEgIgHQgKgHgIgJQgJgKgGgKQgHgLgEgNQgFgQgDgoIAAgeQAAgUAIglQAFgMAGgLQAGgLAJgJQAJgKAKgGQAIgHAMgFQAQgGAlgDIAcACQANADAMAEQAMAFAJAHQALAGAIAKQAJAJAGALIALAXQAIAkAAAVIAAAdQgCAogGARQgEAMgHALQgGALgJAKQgIAIgLAIQgKAGgLAFQgMAFgNACIgdADQglgDgQgHgAAnDkQgLAEgIAKQgHAKgEAPQgEAPAAAUIAAAlQAAAUAEAPQAEAOAHALQAIAJALAFQAMAFAPABQAPAAALgGQAMgFAIgJQAHgKAEgPQAEgPAAgUIAAglQAAgUgEgPQgEgPgHgKQgIgKgMgEQgLgGgQAAQgPAAgLAGgAkUHPQgMgEgKgHQgKgHgIgJQgJgKgGgKQgHgLgEgNQgFgQgDgoIAAgeQAAgUAIglQAFgMAGgLQAGgLAJgJQAJgKAKgGQAKgHAMgFQAQgGAlgDIAcACQANADAMAEQAMAFAJAHQALAGAIAKQAJAJAGALIALAXQAIAkAAAVIAAAdQgCAogGARQgEAMgHALQgGALgJAKQgIAIgLAIQgKAGgLAFQgMAFgNACIgdADQglgDgQgHgAj5DkQgLAEgIAKQgHAKgEAPQgEAPAAAUIAAAlQAAAUAEAPQAEAOAHALQAIAJALAFQAMAFAPABQAPAAALgGQAMgFAIgJQAHgKAEgPQAEgPAAgUIAAglQAAgUgEgPQgEgPgHgKQgIgKgMgEQgLgGgQAAQgPAAgLAGgAD+HRQgLgGAAgKQAAgIAMgOIDjkCIACAAQAIAAAIAGQAKAGAAAKQAAAKgMANIjjECIgBAAQgGAAgKgHgAG2HUQgLgDgIgFQgJgFgGgIQgHgIgEgKQgGgMAAgQIAAgDQAAgRAGgMQAFgNAMgKQAKgJANgFQANgFAQABQAMAAALACQALACAIAGQAJAFAGAHQAGAJAFAKQAFANAAAPIAAAEQAAAPgFANQgFANgLAKQgVATggAAQgMAAgLgDgAG3F0QgHAIAAAPIAAAHQAAAPAIAJQAIAKAOAAQAOAAAIgKQAIgJAAgPIAAgHQAAgPgIgIQgIgKgPAAQgOAAgIAKgAm5HWQgOAAgHgIQgHgIAAgPIAAi2QgNAHgOABQgRgBgLgJQgMgLAAgQQAAgVAOgKIAEgCIAAAAQANALAPgBQAOAAALgJQAKgJADgPIATAAQAPAAAHAHQAHAIAAAQIAADsQAAAPgHAIQgHAIgPAAgAEOE3QgLgDgJgGQgIgEgHgIQgGgIgFgKQgFgNAAgPIAAgEQAAgQAFgMQAGgNALgLQAKgIANgFQANgFAQAAQANAAAKADQALACAJAFQAIAFAHAJQAGAHAEALQAGAMAAAQIAAADQAAAQgGANQgFAMgLAKQgUAUgggBQgNAAgKgCgAEPDWQgIAKAAAPIAAAGQAAAPAIAJQAIAJAOAAQAOAAAIgJQAIgJAAgPIAAgGQAAgPgIgKQgIgJgOAAQgOAAgIAJgAqshzIgQgDQgLgEgFgGQgFgHAAgKQAAgNALgIQAKgGAOgCQgEgEAAgHQAAgHAIgGQgPgEgIgJQgEgGgCgGQgDgFAAgHQAAgIADgFQACgHAEgFQAEgGAGgDQAFgDAHgDQAKgDALAAIANABIAMAEIAFgJQACgGAFgDQAEgDAFAAQAFAAAEADQAEACACAGIABADIgUATQAFAFADAGQACAHAAAHQAAAHgCAGQgCAGgEAFQgEAEgGAEQgFADgHADQgKACgMAAIgBAAIgBADQAAACAEACIANAEIAPAEQAIADAGADQAIAFAEAGQAEAGAAAJQAAAKgFAIQgGAGgLAFQgHAEgKABQgKACgMAAgAqridQgHAEAAAGQAAAHAHADQAHADAOAAQAdAAAAgOQAAgGgJgDIgUgGQgOABgHAFgAqmj8QgFAHAAAJQAAAKAGAGQAGAFAJAAQAKAAAGgFQAGgGAAgKQAAgJgGgHQgGgFgKAAQgKAAgGAFgAn0h3QgEgCgDgEIgBgCIATgrQgIgBgDgGIgnhbQAAgCAGgDQAFgEAHAAQAGAAAEAEQAFAEADAIIAZBBIAWhBQACgHAFgFQAEgEAHAAQAEAAAEACQAFACADACIABADIgzCGQgDAIgFAEQgFAEgGAAQgFAAgEgBgADyijQgKgEgIgIQgIgIgEgKQgEgLAAgMIAAgCQAAgFACgCQACgCAEAAIBOAAQgBgGgDgFQgCgGgFgDQgEgEgGgCQgFgBgHAAQgFAAgJAEQgIAFgKAIQgEAAgFgEQgGgEAAgIQAAgJAMgIQAHgEAJgCQAJgCAMAAQAbAAARAQQAIAIAFAKQAEALAAAOQAAAagRARQgIAJgLADQgLAFgMAAQgNAAgKgEgADxjGQACAGADACQAEAEAEACQAFACAGAAQAGAAAFgCQAFgCAEgEQADgCADgGQACgEABgGIg3AAQAAAGACAEgAmLivQgJgJgEgKQgEgLAAgNQAAgbARgRQAIgIALgEQAKgEANgBQANAAAKAFQAKADAIAIQAIAJAEAJQAEALAAANIAAACQAAAEgCADQgCACgEAAIhOAAQABAGACAFQADAFAEAEQAFADAFACQAGABAGABQAGAAAIgFQAJgEAKgIQAEAAAFACQAGAFAAAIQAAAJgMAIQgHAEgJACQgJACgMAAQgbAAgRgPgAlHjlQAAgHgCgEQgCgFgDgDQgEgEgFgCQgEgCgGABQgGgBgFACQgFACgEAEQgEADgCAFQgDAEAAAHIA3AAIAAAAgAtyiiQgHgBgHgCIgMgIIgKgJIgJgLIgGgOQgCgGgBgIIgCgQQAAgJACgIIAEgPIAHgNQAEgHAFgFQAGgFAGgFIAOgGIAPgFIARgBQANAAALADQALADAIAEQAHAFAEAGQAEAFAAAHQAAAGgDAEQgDADgHACIgEACIAAgBIgBAAIgHgIIgJgGQgKgFgNgBQgKAAgJAEQgIAEgHAHQgGAIgDAJQgDAIAAALQAAAJACAHQABAHAEAFQADAHAFADQAEAFAHADQAIAEAKAAQAPAAAKgHQAGgEADgFQAEgGABgHIAAgDIgbAAQgIgBgEgDQgFgDAAgGIAAgCQAAgHAFgDQAEgBAIgBIAqAAQAIABAEADQADAEAAAJIAAA/QAAABgGABIgGABQgIAAgEgEQgFgFgBgKQgOAVggAAQgIAAgIgCgAOUikIgJgIIgjgrIAAAmQAAAHgEAFQgDADgIAAIgDAAQgIAAgDgDQgEgFAAgHIAAiPQAAgCAGgBIAGgBQAHAAAFAEQAEACADAIQACAFAAAHIAABHIAggoQAFgGADgCQAFgCAFAAQAFAAAEACQAEACADADIABAEIgjAtIAoAxQAAADgFADQgHAFgGAAQgFAAgFgDgAgHikIgJgIIgkgrIAAAmQAAAHgDAFQgEADgHAAIgEAAQgHAAgEgDQgDgFAAgHIAAiPQAAgCAFgBIAHgBQAHAAAEAEQAFACACAIQACAFAAAHIAABHIAggoQAFgGAEgCQAFgCAEAAQADAAAEACQAEACADADIACAEIgiAtIAmAxQAAADgFADQgHAFgGAAQgDAAgEgDgAMbiiQgHAAgEgDQgDgFAAgHIAAhUQAAgIADgEQAEgEAHAAIAEAAQAHAAAEAEQADAEAAAIIAABUQAAAHgDAFQgEADgHAAgALgiiQgHAAgEgDQgDgFAAgHIAAiPQAAgCAFgBIAHgBQAHAAAEAEQAFACACAIQACAFAAAHIAAB5QAAAHgDAFQgEADgHAAgAIyiiQgHAAgEgDQgDgFAAgHIAAhUQAAgIADgEQAEgEAHAAIAEAAQAHAAAEAEQADAEAAAIIAABUQAAAHgDAFQgEADgHAAgAH5iiQgHAAgEgDQgEgFAAgHIAAgzQAAgMgFgFQgEgGgKAAQgIAAgFAEQgGADgEAHIAAA8QAAAHgEAFQgDADgHAAIgEAAQgHAAgEgDQgEgFAAgHIAAgyQAAgYgTAAQgHAAgGAEQgGADgEAHIAAA8QAAAHgDAFQgEADgHAAIgEAAQgHAAgEgDQgDgFAAgHIAAhgQAAgBAFgCIAHgBQAIAAAFAFQAFAEACAJQAGgKAJgEQAJgGALAAQAHABAGABQAFACAFADIAIAHQADAEACAGQADgGAFgEIAIgHQAFgDAGgCQAFgBAGgBQAKAAAIAEQAIADAFAFQAFAFADAJQACAIAAALIAAA5QAAAHgEAFQgDADgIAAgACAiiQgHAAgEgDQgDgFAAgHIAAhqIgiAAQgIAAgEgEQgEgDAAgIIAAgBQAAgGAEgEQAEgEAIAAIBlAAQAIAAAEAEQAEAEAAAGIAAABQAAAIgEADQgEAEgIAAIghAAIAABqQAAAHgEAFQgEADgHAAgAiAiiQgHAAgEgDQgDgFAAgHIAAhUQAAgIADgEQAEgEAHAAIAEAAQAHAAAEAEQADAEAAAIIAABUQAAAHgDAFQgEADgHAAgAi5iiQgHAAgEgDQgEgFAAgHIAAgyQAAgYgVAAQgIAAgHAEQgGAEgEAHIAAA7QAAAHgDAFQgEADgHAAIgEAAQgHAAgEgDQgDgFAAgHIAAhgQAAgBAFgCIAHgBQAIAAAFAFQAFAFACAIQAHgJAJgFQAJgGAMAAQAKABAIADQAIADAGAIQAFAGADAHQACAJAAAKIAAA3QAAAHgEAFQgDADgHAAgAo9iiQgIAAgDgDQgEgFAAgHIAAhUQAAgIAEgEQADgEAIAAIADAAQAHAAAEAEQAEAEAAAIIAABUQAAAHgEAFQgDADgIAAgArviiQgIAAgDgDQgEgFAAgHIAAhUQAAgIAEgEQADgEAIAAIADAAQAHAAAEAEQAEAEAAAIIAABUQAAAHgEAFQgDADgIAAgAJlijQgGAAgDgCQgDgDAAgGIAAgCQAAgIAHgHIAyg8IgrAAQgOAAAAgMIAAgBQAAgMAOAAIBJAAQAGAAADADQADADAAAGIAAABQAAAGgCADIg5BCIAwAAQANAAAAAMIAAACQAAAGgDADQgDACgHAAgAMRklQgEgEAAgJQAAgIAEgEQAEgFAIAAQAJAAAEAFQAEAEAAAIQAAAJgEAEQgEAEgIAAQgJAAgEgEgAIoklQgEgEAAgJQAAgIAEgEQAEgFAIAAQAJAAAEAFQAEAEAAAIQAAAJgEAEQgEAEgIAAQgJAAgEgEgAiKklQgEgEAAgJQAAgIAEgEQAEgFAIAAQAJAAAEAFQAEAEAAAIQAAAJgEAEQgEAEgIAAQgJAAgEgEgApIklQgEgEAAgJQAAgIAEgEQAEgFAIAAQAJAAAEAFQAFAEAAAIQAAAJgFAEQgEAEgIAAQgIAAgFgEgAr6klQgEgEAAgJQAAgIAEgEQAEgFAIAAQAJAAAEAFQAFAEAAAIQAAAJgFAEQgEAEgIAAQgIAAgFgEgAKbpLIgQgDQgKgEgGgHQgFgGAAgKQAAgNAMgIQAJgHAPgCQgFgDAAgHQAAgHAIgGQgOgEgIgKQgFgFgCgGQgCgFAAgHQAAgHACgHQACgGAFgFQAEgFAFgEQAGgDAHgDQAKgDALAAIAMABIAMADIAFgJQADgFAEgDQAEgDAFAAQAGAAAEACQADAEACAEIABAEIgTATQAFAGACAFQADAHAAAHQAAAHgCAGQgDAGgEAFQgDAEgGAEQgGAEgHACQgKACgLAAIgCAAIAAADQAAACAEACIAMAEIAPAEQAJADAGADQAIAFAEAHQAEAFAAAJQAAAKgGAHQgFAIgLAEQgIADgKACQgKACgLgBgAKcp2QgHAFAAAGQAAAGAHADQAHAEAOAAQAeAAAAgOQAAgGgJgEIgUgEQgPABgHADgAKirTQgGAFAAAKQAAAKAGAFQAGAHAKAAQAKAAAFgHQAGgFAAgKQAAgKgGgFQgGgGgJAAQgKAAgGAGgANTpQQgEgBgDgDIgBgDIATgqQgIgCgDgGIgnhbQAAgCAGgEQAFgDAHAAQAGAAAEAEQAFAEADAJIAZBAIAWhAQACgJAFgEQAEgEAHAAQAEAAAEABQAFACADAEIABACIgzCGQgDAIgFAEQgFAEgGAAQgFAAgEgCgAIcp7QgLgFgJgIQgRgQAAgbQAAgNAFgLQAEgLAIgIQAJgIALgEQALgFANABQAKgBAJADQAIADAHAEQAIAFAFAGQAGAHADAIQAEALAAANQAAAKgCAIQgCAJgFAHQgEAHgHAGQgHAFgIADQgLAEgOAAQgOAAgKgDgAInrSQgGACgEAFQgEAFgCAGQgDAGAAAHQAAAHACAHQADAFAEAFQAEAFAGADQAGABAHAAQAHAAAGgBQAGgDAEgFQAEgFADgGQACgGAAgHQAAgHgDgGQgCgGgEgFQgEgFgGgCQgGgDgHAAQgHAAgGADgAgvqIQgJgIgEgKQgEgLAAgOQAAgZARgRQAIgJALgEQAKgFANABQALAAAKADQAKAFAIAIQAIAHAEALQAEAJAAANIAAACQAAAFgCACQgCACgEAAIhMAAQABAHACAFQADAFAEAEQAFADAFACQAGABAGAAQAEAAAIgDQAJgFAKgJQAEABAFADQAGAEAAAHQAAALgMAHQgHAFgJACQgJACgKgBQgbAAgRgQgAATq+QAAgFgCgFQgCgFgDgEQgEgDgFgCQgDgCgFAAQgGAAgFACQgFACgEADQgEAEgCAFQgDAFAAAFIA1AAIAAAAgApKqIQgIgIgEgKQgFgLAAgOQAAgZARgRQAJgJAKgEQALgFANABQAMAAAKADQALAFAHAIQAIAHAEALQAEAJAAANIAAACQAAAFgCACQgCACgEAAIhOAAQABAHADAFQADAFAEAEQAEADAGACQAFABAHAAQAGAAAIgDQAIgFALgJQAEABAEADQAHAEAAAHQAAALgNAHQgHAFgJACQgJACgLgBQgcAAgRgQgAoFq+QAAgFgDgFQgBgFgEgEQgDgDgFgCQgFgCgGAAQgGAAgFACQgFACgDADQgEAEgDAFQgCAFgBAFIA4AAIAAAAgAraqKQgGgIgEgKQgDgLAAgMQAAgNAEgLQADgLAHgIQAIgIAJgFQAKgDAMAAQAMgBAJAFQAJAEAGAJIAAg7QAAgCAGgBIAGgBQAHAAAFADQAFAEACAGQACAGAAAIIAAB4QAAAHgEAEQgDAFgHAAIgEAAQgHAAgEgFQgEgEAAgHIAAgEIgGAKIgJAGQgEADgGABQgFABgHAAQgYAAgPgSgAq2rSQgGADgEAEQgEAFgBAGQgCAGAAAHQAAAXARAIQAGADAGgBQAGAAAFgBQAFgCAEgEQAEgDACgGQACgEAAgHIAAgVQgDgJgIgFQgHgEgKAAQgHAAgFACgAtJp7QgLgFgIgIQgRgQAAgbQAAgNAEgLQAEgLAJgIQAIgIALgEQALgFAOABQAJgBAJADQAJADAHAEQAHAFAGAGQAFAHAEAIQAEALAAANQAAAKgCAIQgDAJgEAHQgFAHgGAGQgHAFgJADQgLAEgOAAQgNAAgLgDgAs9rSQgGACgEAFQgFAFgCAGQgCAGAAAHQAAAHACAHQACAFAFAFQAEAFAGADQAGABAHAAQAHAAAFgBQAGgDAEgFQAFgFACgGQACgGAAgHQAAgHgCgGQgCgGgFgFQgEgFgGgCQgFgDgHAAQgHAAgGADgAPCp6QgGgCgFgEQgGgEgDgGQgDgHAAgIQAAgJAFgIQAEgHAJgFQAKgEANgDQAOgCASAAIAEAAQAAgGgCgEQgBgEgDgDQgDgDgEgBQgEgCgGAAQgKAAgHAEQgHAFgEAIIgCAAIAAABQgKAAgFgEQgFgDAAgHQAAgGAEgFQADgEAGgEQAHgFAKgCQAKgDAMABQANAAAKACQAKAEAHAFQAGAGAEAJQADAJAAALIAABDQAAACgFABIgHABQgJAAgEgFQgFgEgBgJIgIAJIgJAFQgKAFgNAAQgIAAgHgCgAPyqtQgSABgGABQgIACgEAFQgDADAAAGQAAAHAEADQAEADAJABQAGAAAFgCIAJgFQAEgDACgFQACgFAAgGIAAgHgAFVp6QgHgCgFgEQgGgEgCgGQgDgHAAgIQAAgJAEgIQAFgHAJgFQAJgEAOgDQANgCATAAIADAAQAAgGgBgEQgBgEgDgDQgDgDgFgBQgEgCgGAAQgKAAgHAEQgHAFgEAIIgBAAIgBABQgJAAgFgEQgFgDAAgHQAAgGADgFQADgEAHgEQAHgFAKgCQAJgDAMABQAOAAAKACQAKAEAGAFQAHAGADAJQAEAJAAALIAABDQAAACgGABIgHABQgIAAgFgFQgFgEgBgJIgHAJIgJAFQgKAFgNAAQgIAAgHgCgAGEqtQgRABgHABQgHACgEAFQgEADAAAGQAAAHAEADQAFADAJABQAGAAAFgCIAJgFQADgDACgFQACgFAAgGIAAgHgACPp8QgEgDgEgGIgTgeIgTAeQgIAMgKAAQgGAAgEgCQgFgCgCgEIgCgDIAjgvIgjgwQAAgCAGgEQAGgEAHAAQAGAAAEACQAFAEADAFIATAfIATgfQAFgGAEgDQAEgCAFAAQAFAAAFABQAEACAEAFIABACIgjAwIAiAvIABABQAAACgGADQgGAFgHAAQgFAAgFgDgAMKp5QgIAAgDgFQgEgEAAgHIAAhUQAAgIAEgEQADgEAIAAIADAAQAHAAAEAEQAEAEAAAIIAABUQAAAHgEAEQgDAFgIAAgAHSp5QgIAAgDgFQgEgEAAgHIAAiPQAAgCAGgBIAGgBQAHAAAFADQAEAEADAGQACAGAAAIIAAB4QAAAHgEAEQgDAFgIAAgAEap5QgHAAgEgFQgEgEAAgHIAAgxQAAgZgVAAQgIAAgHADQgGAFgEAHIAAA7QAAAHgDAEQgEAFgHAAIgEAAQgHAAgEgFQgDgEAAgHIAAhhQAAAAAFgCIAHgBQAIAAAFAEQAFAFACAJQAHgJAJgGQAJgEAMAAQAKgBAIAEQAIAEAGAGQAFAGADAJQACAIAAAKIAAA3QAAAHgEAEQgDAFgHAAgAiPp5QgHAAgDgFQgEgEAAgHIAAhqIgiAAQgIAAgEgDQgEgEAAgHIAAgBQAAgIAEgDQAEgDAIgBIBmAAQAIABAEADQAEADAAAIIAAABQAAAHgEAEQgEADgIAAIgiAAIAABqQAAAHgDAEQgEAFgIAAgAkXp5QgHAAgEgFQgEgEAAgHIAAgxQAAgZgVAAQgIAAgHADQgGAFgEAHIAAA7QAAAHgDAEQgEAFgHAAIgEAAQgHAAgEgFQgDgEAAgHIAAhhQAAAAAFgCIAHgBQAIAAAFAEQAFAFACAJQAHgJAJgGQAJgEAMAAQAKgBAIAEQAIAEAGAGQAFAGADAJQACAIAAAKIAAA3QAAAHgEAEQgDAFgHAAgAnGp5QgIAAgDgFQgEgEAAgHIAAhhQAAAAAGgCIAGgBQAJAAAFAFQAFAEABAKQAEgKAHgFQAHgGAKABQALAAAFAEQAFAFAAAKQAAAFgCAEQgCAFgEACIgCABQgGgGgJAAQgGAAgEACQgFADgCAEQgDAFgCAHQgBAHAAAJIAAAiQAAAHgEAEQgDAFgIAAgAuTp5QgHAAgDgFQgEgEAAgHIAAhaIgZA+QgDAGgDACQgDACgIAAQgKAAgDgDQgCgCgCgFIgag9IAABZQAAAHgDAEQgDAFgHAAIgFAAQgHAAgDgFQgEgEAAgHIAAh3QAAgJAEgFQAFgDAIAAIAKAAQAHgBAEADQAEADADAGIAeBHIAfhHQADgGADgDQAEgDAHABIAJAAQAJAAAEADQAFAFAAAJIAAB3QAAAHgEAEQgDAFgHAAgAL/r9QgEgEAAgIQAAgJAEgEQAEgEAIAAQAJAAAEAEQAFAEAAAJQAAAIgFAEQgEAEgIAAQgIAAgFgEg");
	this.shape.setTransform(-1.2,69.2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-118.3,-10.5,234.3,159.5);


(lib.Tween50 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B41F2A").s().p("AFlBVQgBAAgBgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIAAgBIAGgOQgJAAgGgDQgHgCgFgEQgEgDgCgDQgDgEAAgEQAAgGAIgGIACgBQAHAHAJAFIAJADQAFABAFAAQAKAAAFgDQAGgEAAgHQAAgEgEgDQgFgEgIgCIgPgEQgIgCgHgDIgHgFIgFgFIgDgHIgBgIQAAgHACgFQABgFAEgEQADgEAFgDQAFgDAGgCQAJgDAKAAQAKAAAHACQAIACAGADQAFADADADQACAEAAAEQAAAEgCADQgCADgEADIgCABQgGgHgIgEQgIgDgJAAQgKAAgFADQgFADAAAHQAAAFAEACQAEADAHACIATAFQALABAHAFQAGAFADAGQADAGAAAHQAAAHgCAGQgCAGgEAEQgDAEgGADQgGADgHACIgBABIgSASQgDACgDAAgAh0BAQgEgCgDgEQgIAEgHACQgIADgIAAIgNgBIgLgDIgKgGIgJgHIgHgJIgFgKQgDgFgBgGIgBgNQAAgHACgEIADgLIAFgKIAHgJIAJgHQAFgEAFgCIAMgDIAMgBIANABIALADIAKAFIAJAIIAHAJIAFAKIADALIABALQAAAKgDAJQgDAJgGAIIAOAOQAAADgEADQgFAEgGAAQgEAAgEgDgAiogZQgGADgFAFQgEAFgCAHQgCAFAAAHIABALIAEAJQACAFAEADQAEAEAFACQAGACAHAAQAHAAAIgCIgLgMQgEgEAAgGQAAgEADgCIABgBQACgDADAAQAGAAAEAGIALALIADgJIABgKQAAgKgFgIQgDgFgEgEQgDgDgFgCQgGgDgIAAQgIAAgGADgAofBBQgJgCgGgEQgFgDgDgEQgDgEAAgFQAAgGAIgGIACgBQAHAHAJAFIAJADQAFABAFAAQAKAAAFgDQAGgEAAgHQAAgEgEgDQgFgEgIgCIgPgEQgIgCgHgDIgHgFIgFgFIgDgHIgBgIQAAgHACgFQABgFAEgEQADgEAFgDQAFgDAGgCQAJgDAKAAQAKAAAHACQAIACAGADQAFADADADQACAEAAAEQAAAEgCADQgCADgEADIgCABQgGgHgIgEQgIgDgJAAQgKAAgFADQgFADAAAHQAAAFAEACQAEADAHACIATAFQALABAHAFQAGAFADAGQADAGAAAHQAAAUgPAJQgGAEgIACQgIACgKAAQgLAAgIgCgAP+BBQgGgBgEgCIgJgFIgIgIIgGgJIgEgJQgCgHgBgQIAAgBQAAgFADgCQACAAAEAAIBLAAQgBgHgCgFQgDgFgEgEQgFgFgGgDQgGgCgHAAQgJAAgHADQgHACgEAFIgHAKQgFgBgEgDQgEgEAAgFQAAgFAEgFQADgEAGgEQAHgFAJgDQAIgCAKAAIAMABIAKADQAGACAEADIAJAHIAHAJIAEALIADALIABAKQAAAKgCAIQgCAJgEAHQgFAIgGAFQgGAGgIAEIgKADIgMABIgLgBgAPwAdQABAEADAEQAEAEAFACQAFACAHAAQAHAAAFgCQAGgCAEgEIAGgIIAEgLIg8AAIADALgAK+BBQgGgBgEgCIgJgFIgIgIIgGgJIgEgJQgCgHgBgQIAAgBQAAgFADgCQACAAAEAAIBLAAQgBgHgCgFQgDgFgEgEQgFgFgGgDQgGgCgHAAQgJAAgHADQgHACgEAFIgHAKQgFgBgEgDQgEgEAAgFQAAgFAEgFQADgEAGgEQAHgFAJgDQAIgCAKAAIAMABIAKADQAGACAEADIAJAHIAHAJIAEALIADALIABAKQAAAKgCAIQgCAJgEAHQgFAIgGAFQgGAGgIAEIgKADIgMABIgLgBgAKwAdQABAEADAEQAEAEAFACQAFACAHAAQAHAAAFgCQAGgCAEgEIAGgIIAEgLIg8AAIADALgAHQBBQgFgBgFgCIgJgFIgIgIIgFgJIgEgJQgDgHgBgQIAAgBQAAgFADgCQADAAAEAAIBLAAQgBgHgDgFQgCgFgEgEQgFgFgGgDQgGgCgIAAQgJAAgHADQgGACgFAFIgGAKQgGgBgDgDQgEgEAAgFQAAgFADgFQADgEAGgEQAIgFAIgDQAJgCAJAAIAMABIALADQAFACAFADIAIAHIAHAJIAFALIADALIABAKQAAAKgCAIQgDAJgEAHQgEAIgGAFQgGAGgIAEIgLADIgLABIgMgBgAHCAdQACAEADAEQAEAEAFACQAFACAHAAQAGAAAGgCQAFgCAFgEIAGgIIAEgLIg9AAIADALgAmzA/QgJgDgGgGQgGgHgDgJQgDgJAAgNIAAg1QAAgGACgDQADgDAGAAIADAAQAGAAADADQADADAAAGIAAA1QAAAHABAFQACAFADAEIAHAFQAEABAGAAQAGAAAEgBQAFgCADgDQADgEABgFQABgFAAgHIAAg1QAAgGADgDQADgDAGAAIADAAQAGAAADADQADADAAAGIAAA1QAAAygyAAQgMAAgKgDgAqiBBQgFgBgFgCIgJgFIgIgIIgFgJIgEgJQgDgHgBgQIAAgBQAAgFADgCQADAAAEAAIBLAAQgBgHgDgFQgCgFgEgEQgFgFgGgDQgGgCgIAAQgJAAgHADQgGACgFAFIgGAKQgGgBgDgDQgEgEAAgFQAAgFADgFQADgEAGgEQAIgFAIgDQAJgCAJAAIAMABIALADQAFACAFADIAIAHIAHAJIAFALIADALIABAKQAAAKgCAIQgDAJgEAHQgEAIgGAFQgGAGgIAEIgLADIgLABIgMgBgAqwAdQACAEADAEQAEAEAFACQAFACAHAAQAGAAAGgCQAFgCAFgEIAGgIIAEgLIg9AAIADALgAABA+QgCgDgCgGIgHgSIgqAAIgHASQgCAGgEADQgDADgFAAIgHgBIgGgEIgBgCIAnhkQACgEAEgCQAEgCAHAAIAKABQAFACACAFIAmBjIAAABQAAACgEADQgFACgFAAQgFAAgEgDgAgPAPIgQgnIgQAnIAgAAgAsQA/QgEgDgCgFIgohgQAAgCAFgDQAFgDAGAAQAFAAAEADQAEADACAGIAZBIIAZhIQACgGAEgDQADgDAFAAQAFAAADABQAEACADADIABACIgoBgQgCAFgEADQgEACgFAAQgGAAgEgCgAwVA+QgEgDgDgGIgGgSIgqAAIgHASQgDAGgDADQgEADgFAAIgHgBIgFgEIgCgCIAohkQABgEAEgCQAFgCAHAAIAKABQAFACACAFIAoBjIAAABQAAACgFADQgEACgFAAQgGAAgDgDgAwoAPIgQgnIgPAnIAfAAgATJBBQgGAAgDgDQgDgDAAgGIAAhaQAAgGADgDQADgDAGAAIADAAQAGAAADADQADADAAAGIAABaQAAAGgDADQgDADgGAAgASSA+IgHgIIgYgfIgKAAIAAAeQAAAGgDADQgDADgGAAIgDAAQgGAAgDgEQgCgDAAgHIAAhVQAAgHADgEQADgEAHAAIAiAAQALAAAJADQAIACAGAEQAGAFADAHQACAGAAAJQAAAHgCAGQgBAEgEAEQgEAEgFADQgGADgHABIAdAkIABABQAAACgEADQgFAEgHAAQgGAAgEgDgARoAEIAUAAIAJgBQAEgBADgCQADAAABgDQABgEAAgEQAAgEgBgEIgEgFQgDgCgEgBIgJgBIgUAAgANTA+IgHgIIgZgfIgKAAIAAAeQAAAGgDADQgCADgGAAIgEAAQgFAAgDgEQgDgDAAgHIAAhVQAAgHADgEQAEgEAHAAIAiAAQALAAAIADQAJACAGAEQAFAFADAHQADAGAAAJQAAAHgCAGQgCAEgEAEQgDAEgGADQgFADgIABIAeAkIAAABQAAACgDADQgFAEgHAAQgGAAgEgDgAMpAEIAUAAIAJgBQAEgBACgCQADAAABgDQACgEAAgEQAAgEgCgEIgEgFQgCgCgEgBIgKgBIgTAAgAJ4BBQgFAAgDgDQgDgDAAgGIAAgjIgxAAIAAAjQAAAGgDADQgDADgGAAIgDAAQgGAAgDgDQgCgDAAgGIAAhaQAAgGACgDQADgDAGAAIADAAQAGAAADADQADADAAAGIAAAjIAxAAIAAgjQAAgGADgDQADgDAFAAIAEAAQAGAAADADQADADAAAGIAABaQAAAGgDADQgDADgGAAgADqBBQgGAAgCgDQgDgDAAgGIAAhPIgaAAQgGAAgDgCQgDgDAAgGIAAgBQAAgFADgDQADgDAGAAIBOAAQAGAAADADQADADAAAFIAAABQAAAGgDADQgDACgGAAIgaAAIAABPQAAAGgDADQgDADgFAAgACcBBQgGAAgDgDQgDgDAAgGIAAhaQAAgGADgDQADgDAGAAIADAAQAGAAADADQADADAAAGIAABaQAAAGgDADQgDADgGAAgABNBBQgFAAgDgDQgDgDAAgGIAAgjIgog6QAAgCAEgDQAFgEAIAAQADAAADACIAGAHIAYAnIAZgnIAGgHQADgCADAAQAHAAAGAEQAEADAAACIgpA6IAAAjQAAAGgCADQgDADgGAAgAj0BBQgFAAgDgDQgCgDAAgGIAAhCIgUAsQgCAFgDACQgCABgGAAQgHAAgDgCIgDgGIgTgrIAABBQAAAGgDADQgCADgGAAIgEAAQgFAAgCgDQgDgDAAgGIAAhZQAAgHADgDQADgDAHAAIAHAAQAGAAADACQADACACAFIAXA0IAYg0QACgFADgCQADgCAFAAIAHAAQAHAAADADQADADAAAHIAABZQAAAGgCADQgDADgFAAgAt5BBQgFAAgDgDQgDgDAAgGIAAhaQAAgGADgDQADgDAFAAIAEAAQAFAAADADQADADAAAGIAABaQAAAGgDADQgDADgFAAgAurA/IgHgGIgmguIAAAqQAAAGgDADQgDADgGAAIgDAAQgGAAgDgDQgCgDAAgGIAAhaQAAgGACgDQADgDAGAAIADAAQAGAAADADQADADAAAGIAAAnIAlgrIAIgHIAHgBQAEAAAEACQADABADAEIABADIgoAtIApAxIAAAAQAAACgEAEQgFAEgHAAQgEAAgDgCgAOKBAQgHAAgDgDQgDgEAAgHIAAhXQAAgGACgDQADgDAGAAIADAAQAGAAADADQADADAAAGIAABOIArAAQAGAAADADQADADAAAFIAAABQAAAGgDACQgDADgGAAgAzKBAQgHAAgEgDQgDgEAAgHIAAhUQAAgHADgEQAEgEAHAAIAnAAQAKAAAIACQAHACAFAEQAFADADAGQACAGAAAHQAAAEgBAEIgEAHIgHAEIgJADQAHACAEACIAIAGQADAEACAEQABAFAAAGQAAAJgDAHQgEAHgHADQgGADgIACQgHABgLAAgAy+AtIAXAAQALAAAEgDQADgCACgDQACgDAAgFQAAgEgCgCQgBgDgDgCQgCgCgEgBIgKgBIgXAAgAy+AAIAWAAQAJAAAFgEQAEgEAAgHQAAgHgEgEQgFgDgJAAIgWAAgATAg+QgEgDAAgGQAAgGAEgEQAEgEAHAAQAGAAAEAEQAEAEAAAGQAAAGgEADQgEAEgGAAQgHAAgEgEg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-124,-8.5,248.3,17.3);


(lib.Tween49 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B41F2A").s().p("AAAEbQgHgEgHgIIgkgrQgggngegvQghg0gUguQgWgwgHgsQgKg7AXg2QAVgxArggQAngdAugIIAXgDIATAAIACABIABAAQAnADAhAQQAeAOAYAYQAUATANAYQAaAvAAA0QAAAWgFAXQgEAVgHAVQgPAtgbAyQgbAvgeApIgbAjIgbAiIgLAPQgHAHgIAEgAgwjJQgXAKgRASQgSARgKAXQgKAYAAAaQgBAZALAYQAJAXASAQQASARAXAKQAXALAZAAQAZAAAYgKQAXgKARgSQASgPAKgXQAKgYAAgaQAAgagKgXQgJgXgSgSQgSgSgXgKQgYgKgZAAQgYAAgYAKg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-19.8,-28.2,39.7,56.6);


(lib.Tween48 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkdEVQgGgCgDgFIgCgCIAXg2QgKgBgDgIIgxhwQAAgDAIgEQAHgFAIAAQAHAAAGAFQAFAFAEAKIAfBRIAbhQQADgLAGgFQAGgFAHAAQAHAAAEACQAGACAEAEIACADIhBCnQgDAKgGAFQgGAFgHAAQgHAAgEgCgAiODfQgKgFgGgIQgHgIgDgKQgDgKAAgNIAAhEQAAgKAFgFQAEgFAJAAIAFAAQAJAAAEAFQAEAFABAKIAAA+QAAAHABAGQACAGAEADQACAEAGACQAEACAIAAQAKAAAHgFQAIgEAEgJIAAhKQABgKAEgFQAFgFAIAAIAFAAQAJAAAEAFQAFAFAAAKIAAB3QAAACgHABIgIABQgKAAgHgFQgGgGgCgLQgIANgMAGQgLAGgPAAQgNAAgKgEgAnODfQgKgFgHgIQgGgIgDgKQgDgKAAgNIAAhEQAAgKAEgFQAFgFAJAAIAEAAQAKAAAEAFQAFAFgBAKIAAA+QAAAHADAGQABAGADADQAEAEAEACQAFACAHAAQAKAAAIgFQAHgEAGgJIAAhKQgBgKAFgFQAEgFAKAAIADAAQAKAAAFAFQAEAFAAAKIAAB3QAAACgHABIgIABQgLAAgFgFQgHgGgBgLQgJANgLAGQgMAGgPAAQgNAAgKgEgAHwDdQgMgEgFgGQgHgHAAgIQAAgKAKgGIACgBQAKAKAMAEQALAFAOAAQAMAAAHgEQAGgDAAgHQAAgFgFgDQgGgEgKgCIgTgEQgLgCgIgFQgLgFgFgIQgFgJAAgMQAAgHACgHQACgHAEgFQAFgFAHgEQAGgEAIgDQALgDAOAAIASABQAKABAHADQALAEAFAGQAGAGgBAJQAAAFgCAEQgDAEgFADIgCABIAAAAQgJgJgKgFQgKgFgNAAQgLAAgHAEQgFADAAAHQgBAFAGADQAFAEALACIATAEQAMADAIAEQALAFAFAJQAFAIAAAMQAAAMgFAJQgFAJgJAGQgIAFgLACQgLACgMAAQgbgBgLgEgAFaDgQgIgCgHgFQgGgGgEgIQgDgHAAgKQgBgMAHgJQAFgJALgGQALgGASgDQARgDAWAAIAEAAQAAgHgCgFQgBgGgDgDQgEgDgFgCQgGgCgIAAQgMAAgIAGQgJAFgFALIgCAAIgBAAQgMAAgFgEQgHgFAAgJQABgHAEgGQAEgGAHgEQAKgGAMgDQALgCAQAAQAQAAANADQAMAEAIAHQAIAHAEALQAFALAAAOIAABUQgBABgGACIgJABQgKAAgGgFQgGgGgBgLQgFAGgEAEQgGAFgGADQgMAFgQAAQgKAAgJgCgAGVChQgWAAgIADQgJACgFAFQgEAFgBAHQABAIAFAFQAGAEALAAQAGAAAHgCQAGgCAFgFQAEgEADgGQACgGAAgHIAAgIgAJ/DgQgKAAgEgEQgFgFAAgKIAAhoQAAgKAFgFQAEgFAJAAIAEAAQAKAAAEAFQAEAFAAAKIAABoQAAAKgEAFQgEAEgKAAgAERDgQgJAAgFgEQgEgFAAgKIAAg/QAAgOgGgHQgGgHgNAAQgIAAgIAEQgHAEgFAJIAABKQAAAKgEAFQgFAEgIAAIgEAAQgKAAgFgEQgEgFAAgKIAAg+QAAgdgYAAQgJAAgHAEQgHAEgFAJIAABKQAAAKgFAFQgEAEgJAAIgFAAQgIAAgFgEQgFgFAAgKIAAh3QAAgCAHgCIAJgBQAKAAAGAGQAGAFACAMQAJgMAKgGQALgGAOAAQAIAAAHABQAHACAHAEQAFADAEAGQAEAFADAHIAJgMQAFgGAGgDQAGgEAGgCQAIgBAHAAQAMAAAKADQAJAEAHAHQAGAGADALQADAKAAAOIAABGQABAKgFAFQgEAEgKAAgAAPDgQgJAAgEgEQgDgFAAgKIAAixQAAgCAFgCIAIgBQAIAAAHAEQAFAEADAIQACAIABAJIAACVQgBAKgEAFQgFAEgIAAgApTDgQgJAAgFgEQgEgFgBgKIAAg5IhBhhQABgEAGgFQAIgGAMAAQAGAAAFADQAFAEAFAHIAnBAIAng/QAFgIAFgEQAFgDAGAAQALAAAJAGQAGAFAAAFIhBBgIAAA5QABAKgGAFQgEAEgJAAgAJ1hPQgNgFgJgJQgKgKgFgNQgEgNAAgPIAAgDQAAgGABgCQADgDAFAAIBhAAQgCgIgDgGQgDgGgGgFQgFgEgGgCQgIgDgIAAQgHAAgKAGQgLAFgMALQgGAAgFgEQgIgGAAgJQAAgMAPgKQAJgFAMgDQAKgCAOAAQAjAAAVAUQALAKAEANQAGANAAARQAAAggVAVQgLALgNAFQgNAFgQAAQgPAAgNgFgAJzh5QADAGAEAEQAEAEAGADQAHACAHAAQAHAAAGgCQAHgDAEgEQAFgEADgGQADgGABgHIhFAAQABAHABAGgAEzhOQgKgFgHgIQgGgIgDgKQgDgKgBgNIAAhEQAAgKAFgFQAFgFAIAAIAFAAQAJAAAEAFQAFAFAAAKIAAA+QAAAHACAGQACAGADADQADAEAFACQAFACAHAAQAKAAAIgFQAHgEAFgJIAAhKQAAgKAFgFQAEgFAJAAIAEAAQAJAAAFAFQAEAFABAKIAAB3QAAACgIABIgIABQgKAAgGgFQgGgGgCgLQgIANgMAGQgMAGgPAAQgNAAgJgEgAhAhPQgMgFgKgJQgKgKgFgNQgEgNAAgPIAAgDQAAgGACgCQACgDAFAAIBgAAQgBgIgDgGQgDgGgFgFQgGgEgGgCQgHgDgJAAQgHAAgKAGQgKAFgNALQgFAAgGgEQgIgGAAgJQAAgMAPgKQAJgFALgDQALgCAOAAQAjAAATAUQALAKAEANQAGANAAARQAAAggVAVQgLALgLAFQgNAFgQAAQgPAAgNgFgAhCh5QADAGAFAEQAEAEAFADQAGACAIAAQAHAAAGgCQAGgDAFgEQAFgEADgGQADgGAAgHIhEAAQAAAHACAGgAmohPQgMgFgKgJQgKgKgFgNQgEgNAAgPIAAgDQAAgGACgCQACgDAFAAIBhAAQgCgIgDgGQgDgGgGgFQgFgEgGgCQgHgDgJAAQgHAAgKAGQgKAFgNALQgFAAgGgEQgIgGAAgJQAAgMAPgKQAJgFALgDQALgCAOAAQAjAAAVAUQALAKAEANQAGANAAARQAAAggVAVQgLALgNAFQgNAFgQAAQgPAAgNgFgAmqh5QADAGAFAEQAEAEAFADQAGACAIAAQAHAAAGgCQAGgDAFgEQAFgEADgGQADgGABgHIhFAAQAAAHACAGgApxhgQgIgLgEgNQgFgMAAgQQAAgQAFgOQAEgNAJgKQAJgKAMgFQAMgFAPAAQAPAAALAFQALAFAIALIAAhJQAAgCAHgCIAIgBQAIAAAHAEQAFAEADAIQACAIABAJIAACVQgBAKgEAFQgEAEgJAAIgFAAQgJAAgEgEQgFgFAAgKIAAgFQgEAHgFAFQgEAFgGADQgFAEgHABQgHACgIAAQgeAAgSgWgApFi6QgHADgFAGQgFAFgCAIQgDAIAAAJQABAcAVAKQAHADAHAAQAIAAAGgDQAGgCAFgFQAFgEADgGQADgHAAgHIAAgaQgEgMgJgFQgJgGgNAAQgJAAgGADgAtshPQgMgFgKgJQgKgKgFgNQgEgNgBgPIAAgDQABgGACgCQACgDAFAAIBhAAQgBgIgDgGQgEgGgFgFQgGgEgHgCQgHgDgHAAQgIAAgKAGQgKAFgNALQgGAAgFgEQgIgGAAgJQAAgMAQgKQAIgFALgDQAMgCAOAAQAiAAAVAUQAKAKAGANQAFANAAARQAAAggVAVQgKALgOAFQgNAFgQAAQgPAAgNgFgAtth5QACAGAFAEQADAEAHADQAFACAIAAQAHAAAHgCQAGgDAEgEQAFgEADgGQADgGABgHIhFAAQABAHACAGgAjPhPQgFgCgCgFIgzh6QAAgDAHgEQAHgFAHAAQAIAAAHAFQAFAGAEAKIAcBUIAdhUQAEgKAFgGQAGgFAIAAQAGAAAFACQAFACAEAFIABADIgyB5QgCAGgFACQgHADgJAAQgJAAgGgDgAQkhNQgJAAgFgEQgFgFAAgKIAAg9QAAgegaAAQgKAAgIAEQgIAFgEAJIAABJQgBAKgEAFQgEAEgKAAIgEAAQgJAAgEgEQgFgFAAgKIAAh3QAAgCAGgCIAJgBQAKAAAGAGQAHAGACALQAIgMALgGQAMgGAPAAQANAAAKAEQAJAEAHAJQAHAHADAKQADALAAANIAABDQAAAKgFAFQgEAEgJAAgAN7hNQgKAAgFgEQgEgFAAgKIAAhoQAAgKAEgFQAFgFAJAAIAFAAQAJAAAEAFQAEAFAAAKIAABoQAAAKgEAFQgEAEgJAAgAMBhNQgJAAgEgEQgEgFgBgKIAAh3QABgCAGgCIAJgBQALAAAGAGQAFAGADAMQAEgNAJgGQAIgGAMAAQAOAAAHAFQAFAGAAAMQAAAHgBAFQgDAFgFADIgDACQgHgHgLAAQgIAAgFACQgGADgDAGQgDAGgCAIQgCAJAAALIAAAqQAAAKgFAFQgEAEgJAAgAIchNQgKAAgFgEQgEgFAAgKIAAixQAAgCAHgCIAIgBQAIAAAHAEQAFAEADAIQACAIABAJIAACVQgBAKgEAFQgEAEgKAAgAHShNQgJAAgFgEQgFgFAAgKIAAixQABgCAGgCIAIgBQAJAAAGAEQAGAEADAIQACAIAAAJIAACVQAAAKgFAFQgEAEgJAAgACuhNQgKAAgEgEQgEgFAAgKIAAiDIgrAAQgKAAgEgEQgFgFAAgJIAAgBQAAgJAFgFQAEgEAKAAIB/AAQAJAAAGAEQAEAFAAAJIAAABQAAAJgEAFQgGAEgJAAIgqAAIAACDQAAAKgFAFQgFAEgIAAgArfhNQgKAAgEgEQgFgFABgKIAAh3QgBgCAHgCIAIgBQAMAAAFAGQAHAGABAMQAFgNAJgGQAIgGANAAQANAAAGAFQAHAGAAAMQAAAHgCAFQgDAFgFADIgDACQgHgHgMAAQgHAAgFACQgFADgEAGQgEAGgCAIQgBAJAAALIAAAqQAAAKgEAFQgFAEgJAAgAwnhNQgJAAgEgEQgFgFAAgKIAAiQQAAgMAGgGQAFgGAMAAIAwAAQBMAAABA/QAAAQgFALQgFAMgJAIQgKAIgOAEQgPAEgTAAIgcAAIAAAqQAAAKgFAFQgEAEgKAAgAwPiqIAcAAQAJAAAHgCQAGgCAFgEQAEgEADgFQACgGAAgIQAAgHgCgGQgDgGgEgDQgFgEgGgCQgHgCgJAAIgcAAgANtjwQgFgFAAgKQAAgKAFgGQAFgFALAAQAKAAAGAFQAEAGAAAKQAAAKgEAFQgGAGgKAAQgKAAgGgGgAFqjwQgGgFAAgKQAAgKAFgGQAFgFAKAAQALAAAFAFQAGAGAAAKQAAAKgGAFQgFAGgJAAQgMAAgEgGgAEvjwQgGgFABgKQAAgKAEgGQAGgFAKAAQALAAAFAFQAGAGgBAKQABAKgGAFQgFAGgKAAQgLAAgFgGg");
	this.shape.setTransform(2.8,6.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-105.4,-21.5,216.5,55.9);


(lib.Tween47 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9D2029").s().p("AjzDyQgEgBgEgEIgBgCIAUgwQgJAAgDgHIgqhiQABgDAFgDQAHgFAHAAQAGAAAFAFQAFAEAEAJIAbBGIAXhGQADgJAFgEQAFgFAHAAQAFAAAEACQAEACAFADIABADIg4CSQgDAIgFAEQgGAFgHAAQgFAAgEgCgAh1DDQgJgDgFgIQgGgHgCgJQgDgJAAgLIAAg8QAAgIAEgEQAEgFAHAAIAEAAQAJAAAEAFQADAEAAAIIAAA2QAAAHACAFQABAFADAEQADACAFACQAEACAGAAQAJAAAGgEQAHgEAEgIIAAhBQAAgIAEgEQAEgFAIAAIADAAQAJAAADAFQAFAEAAAIIAABoQAAACgHABIgHABQgIAAgGgEQgFgFgCgKQgHALgLAFQgKAGgNAAQgLAAgJgEgAmNDDQgIgDgHgIQgFgHgCgJQgDgJAAgLIAAg8QAAgIAEgEQADgFAIAAIAEAAQAIAAAFAFQADAEAAAIIAAA2QABAHABAFQABAFADAEQADACAFACQAEACAGAAQAIAAAHgEQAHgEAEgIIAAhBQAAgIAEgEQAEgFAIAAIAEAAQAHAAAEAFQAFAEAAAIIAABoQgBACgGABIgHABQgIAAgGgEQgFgFgCgKQgHALgKAFQgLAGgNAAQgLAAgJgEgAG5DBQgKgDgFgGQgFgFgBgHQAAgJAJgFIACgBIAAAAQAJAIAJAEQAKAEANABQALAAAFgDQAGgEgBgFQABgFgFgDQgEgDgKgCIgRgDQgIgDgIgEQgJgEgFgHQgEgIAAgKQAAgHACgGQACgGADgFQAEgEAGgEQAFgDAIgCQAJgDAMAAIARABIAOAEQAJADAFAGQAFAFAAAHQAAAEgCAEQgCADgEADIgDABIgBAAQgHgIgIgEQgKgEgLAAQgKAAgFADQgFADgBAGQAAAEAGADQAEADAJACIARAEQALACAHAEQAJAEAFAHQAEAIAAAKQAAALgEAIQgEAIgKAFQgGAEgKACQgJADgLAAQgXgCgKgEgAE2DEQgHgCgGgEQgGgFgDgHQgDgHAAgIQAAgLAFgHQAFgIAKgGQAKgFAPgDQAPgCATAAIAEAAQAAgGgCgFQgBgFgDgDQgDgCgFgCQgFgCgGAAQgLAAgIAFQgHAFgFAJIgBAAQgLAAgFgDQgGgEABgHQAAgHADgFQAEgFAGgFQAIgFAKgCQALgDAOAAQAOAAALAEQAKADAIAHQAHAFAEALQADAJAAANIAABIQAAACgGABIgHABQgJAAgGgFQgEgEgCgLQgEAGgEADQgFAEgFADQgKAGgOAAQgJAAgIgDgAFQCQQgJACgEADQgEAFAAAGQAAAHAFAFQAFADAJAAQAGAAAGgCQAFgBAEgFQAFgDACgFQACgGAAgGIAAgHIgGAAQgUABgGADgAI2DEQgIAAgEgEQgEgEAAgIIAAhcQAAgIAEgEQAEgFAIAAIAEAAQAHAAAFAFQADAEAAAIIAABcQAAAIgDAEQgEAEgIAAgAD2DEQgIAAgEgEQgEgEAAgIIAAg4QAAgMgGgHQgFgFgKAAQgJgBgFAEQgGAEgFAHIAABCQAAAIgEAEQgEAEgIAAIgDAAQgIAAgFgEQgDgEAAgIIAAg3QgBgZgUAAQgJgBgGAEQgGAEgEAHIAABCQAAAIgEAEQgEAEgIAAIgDAAQgIAAgFgEQgDgEAAgIIAAhoQgBgCAHgBIAGgCQAKAAAFAFQAGAFABAKQAHgLAKgFQAKgGALAAQAIAAAGADQAGABAGADQAEADAEAFQADAFACAGQAEgGAFgFQAEgFAFgDQAGgDAGgBQAGgDAGAAQALAAAIAEQAJADAGAGQAFAGADAJQADAKAAAMIAAA9QAAAIgFAEQgDAEgJAAgAAVDEQgIAAgFgEQgDgEAAgIIAAicQgBgCAHgBIAGAAQAIAAAFADQAGAEACAGQACAHAAAIIAACDQAAAIgEAEQgEAEgIAAgAoCDEQgHAAgEgEQgFgEAAgIIAAgyIg5hVQAAgDAHgFQAGgFALgBQAFAAAFADQAEAEAEAHIAiA4IAjg4QAEgHAEgEQAFgDAFAAQAJAAAIAHQAFADABAFIg6BUIAAAyQAAAIgEAEQgEAEgHAAgAgdgTQgIAAgEgEQgEgEAAgJIAAg0QgDAGgEAEQgEAFgFADQgFACgGACQgGACgHgBQgaAAgQgUQgHgJgEgKQgEgMAAgOQAAgOAEgMQAEgLAIgJQAIgJAKgFQALgEANAAQAOAAAKAFQAKAFAGAKQACgJAFgEQAGgGAJAAIAGACQAHACgBABIAACYQAAAJgDAEQgFAEgIAAgAhZijQgGADgEAFQgEAFgDAGQgCAHAAAIQABAYASAKQAHACAGAAQANAAAJgIQAJgJAAgMIAAgYQgEgKgHgEQgIgGgLAAQgIAAgGADgAlsgnQgFgCAAgDIAAgCIAIgUQgOgCgLgFQgHgDgEgFQgEgFABgGQgBgJAJgEIACgBIABAAQAHAIALAEQAKAEAMAAQAKAAAGgDQAFgDABgGQgBgFgEgDQgFgDgIgBIgRgEQgJgCgIgEQgJgFgEgHQgFgIAAgKQAAgHABgFQADgGAEgFQADgEAGgEQAFgEAIgCQAJgCAMAAIARAAIAOAEQAJADAFAGQAFAFAAAIQAAAEgCAEQgDADgEACIgCACIgBAAQgHgJgJgEQgIgDgMAAQgKAAgFACQgGAEABAFQAAAFAEADQAFACAJACIASAFQAKACAHADQAJAFAEAHQAFAHAAALQAAAHgCAFQgBAGgEAFQgEAEgFAEQgGADgIADQgBADgHAGIgUATQgDADgEAAgAIohSQgJgJgFgMQgEgLAAgPQAAgcASgSQAJgKAMgEQALgFAOAAQANAAAMAEQAKAFAJAJQAIAIAFALQAFALAAAOIAAACQAAAFgDADQgCACgEAAIhVAAQABAHADAFQADAGAFADQAEAFAHABQAGACAGAAQAHABAJgFQAJgFALgJQAEAAAFADQAHAFABAIQAAALgOAIQgIAFgJACQgKADgNgBQgdAAgTgRgAJziMQgBgHgCgGIgGgJQgEgDgFgCQgFgCgGAAQgHAAgGACQgFACgEADQgEAFgCAEQgDAGgBAHIA9AAIAAAAgAGnhWIAAACQAAAIgDAFQgFAEgHAAIgEAAQgIAAgEgEQgEgFAAgIIAAibQAAgCAGgBIAHgBQAIAAAEAEQAGADACAHQACAHAAAIIAAAoQAIgKAJgFQAKgFANAAQAOAAALAFQAKAFAIAJQAHAJAEALQADAMAAANQAAAPgEAMQgEAMgIAIQgIAKgLAEQgJAFgNgBQgcABgMgWgAG0igQgIAFgFAKIAAAXQAAAGADAFQACAGAEAEQAFADAFADQAFACAHAAQAIAAAFgCQAHgDADgFQAEgFADgHQACgGAAgIQAAgIgCgGQgCgGgEgGQgEgFgGgDQgGgDgHAAQgMABgHAFgAEFhSQgJgJgEgMQgFgLAAgPQAAgcASgSQAJgKAMgEQALgFAOAAQANAAALAEQALAFAJAJQAJAIAEALQAFALgBAOIAAACQAAAFgCADQgCACgEAAIhVAAQABAHADAFQADAGAEADQAGAFAFABQAGACAIAAQAGABAJgFQAIgFAMgJQAFAAAEADQAIAFAAAIQAAALgOAIQgIAFgKACQgKADgLgBQgeAAgTgRgAFQiMQgBgHgCgGIgGgJQgDgDgGgCQgFgCgHAAQgGAAgGACQgEACgFADQgEAFgDAEQgCAGgBAHIA9AAIAAAAgArihEQgJgEgFgHQgGgIgCgIQgDgKAAgKIAAg8QAAgJAEgEQAEgEAHgBIAEAAQAJABAEAEQADAEAAAJIAAA2QAAAHACAEQABAFADAEQADADAFACQAEABAGABQAJAAAGgFQAHgDAEgJIAAhAQAAgJAEgEQAEgEAIgBIADAAQAJABADAEQAFAEAAAJIAABoQAAACgHABIgHABQgIAAgGgFQgFgEgCgKQgHALgLAFQgKAGgNgBQgLAAgJgDgAj+hDQgHgCgFgFQgHgFgDgGQgDgHAAgJQAAgKAFgIQAFgIAKgFQAKgFAOgDQAPgCAUAAIAEAAQAAgGgCgGQgBgEgDgDQgDgDgFgCQgEgBgHAAQgLAAgHAEQgIAGgFAJIgCAAQgKAAgFgDQgGgFABgHQgBgHAEgFQAEgFAGgEQAIgFAKgDQALgCAOAAQAOAAALADQAKADAIAHQAHAGAEAKQADAJAAANIAABJQABABgHACIgHAAQgJAAgGgEQgEgFgCgKQgEAGgEADQgFAEgFADQgLAFgNAAQgKAAgHgCgAjkh4QgJACgEAEQgEAFAAAGQAAAHAFAEQAEAEAKAAQAGgBAGgCQAFgBAEgEQAFgEACgEQACgGAAgGIAAgHIgGAAQgUABgGACgAONhDQgIAAgFgEQgDgFAAgIIAAg2QAAgagXAAQgKAAgGAEQgHAEgEAIIAABAQAAAIgEAFQgEAEgIAAIgDAAQgJAAgDgEQgFgFAAgIIAAhoQAAgBAHgCIAHgCQAJABAFAFQAGAFABAKQAIgLAKgGQAKgFAMAAQAMAAAJAEQAIAEAGAHQAGAGACAKQADAIABAMIAAA7QgBAIgEAFQgEAEgHAAgAL4hDQgIAAgEgEQgEgFAAgIIAAhbQAAgJAEgEQAEgEAIgBIADAAQAIABAFAEQAEAEAAAJIAABbQAAAIgEAFQgFAEgHAAgAK4hDQgIAAgEgEQgEgFAAgIIAAibQAAgCAGgBIAHgBQAHAAAGAEQAFADADAHQACAHAAAIIAACCQAAAIgFAFQgEAEgHAAgADJhDQgHAAgFgEQgDgFAAgIIAAhhIgbBCQgDAIgEACQgDACgJAAQgKAAgEgDIgEgJIgchBIAABgQAAAIgEAFQgDAEgIAAIgFAAQgHAAgFgEQgDgFAAgIIAAiBQAAgKAEgFQAFgEAJAAIALAAQAIAAAEADQAEACADAIIAhBOIAihOQADgHAEgDQAEgDAIAAIAJAAQAKAAAEAEQAFAFAAAKIAACBQAAAIgDAFQgEAEgIAAgAm1hDQgIAAgEgEQgEgFAAgIIAAg3QAAgMgGgHQgEgGgMAAQgIAAgFAEQgGAEgFAHIAABBQAAAIgEAFQgEAEgIAAIgDAAQgIAAgFgEQgDgFAAgIIAAg3QAAgZgWAAQgIAAgFAEQgHAEgEAHIAABBQAAAIgEAFQgEAEgIAAIgDAAQgIAAgFgEQgDgFAAgIIAAhoQAAgBAFgCIAHgCQAKAAAFAGQAGAEABAKQAIgKAJgGQAJgFAMAAQAIAAAGACQAGABAGAEQAEADAEAEQADAFACAHQAFgHAEgFQAFgEAEgDQAGgEAFgBQAHgCAGAAQALAAAIADQAJADAGAGQAFAHACAJQAEAJAAAMIAAA9QAAAIgFAFQgDAEgJAAgAtXhDQgHAAgEgEQgEgFgBgIIAAgxIg5hWQAAgDAHgFQAGgFALAAQAFAAAFADQAEAEAEAGIAiA4IAjg4QAEgGAEgEQAFgDAFAAQAKAAAHAGQAFAEABAEIg5BVIAAAxQgBAIgEAFQgEAEgHAAgALtjSQgFgEAAgJQAAgKAFgEQAEgFAIABQAKgBAFAFQAEAEAAAKQAAAJgEAEQgEAFgKAAQgJAAgEgFg");
	this.shape.setTransform(-1.4,1.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-94.3,-23,185.8,48.9);


(lib.Tween46 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFdDyQgEgBgDgDIgCgDIAVgvQgJgBgDgGIgqhjQAAgDAGgDQAGgEAHgBQAHAAAFAFQAEAFAEAIIAbBGIAYhGQACgIAGgFQAEgFAIAAQAEAAAFACQAFACADADIACADIg4CSQgEAIgFAFQgFAFgGAAQgGAAgFgDgAsHDiQgEgDAAgCIAAgCIAJgXIgHgCQgIgDgHgFQgHgGgGgIQgFgJgDgIQgCgKAAgLQAAgOAEgLQAFgMAKgJQAJgJALgEQALgFAPAAQAMAAALAEQAKACAHAHQANAJAAALQgBAGgDAEQgEAEgGACIgFABIgBgBQgFgKgIgFQgHgFgMAAQgHAAgGADQgHACgEAFQgFAFgCAHQgDAGAAAHQAAAIADAHQACAGAFAFQAEAFAHADQAGACAHAAQAMAAAHgEQAIgGAFgKIABAAQAGAAAFAEQAHAEABAIQgBAFgCAEQgCAFgEAEQgGAFgGAEQgIADgIABIgbAbQgDADgEAAgAHbDDQgIgDgGgIQgFgHgDgJQgCgIAAgLIAAg9QAAgIADgEQAEgFAIAAIAEAAQAIAAAEAFQAEAEAAAIIAAA3QAAAGACAGQABAFADADQACADAFACQAFABAFAAQAKAAAGgDQAGgEAFgIIAAhCQAAgIAEgEQADgFAJAAIADAAQAIAAAFAFQADAEAAAIIAABpQABACgHABIgHABQgJAAgFgFQgGgFgBgKQgHALgLAGQgKAGgNAAQgMAAgJgFgADCDDQgIgDgGgIQgFgHgDgJQgDgIAAgLIAAg9QABgIAEgEQADgFAIAAIAEAAQAIAAAEAFQAEAEAAAIIAAA3QAAAGACAGQABAFADADQADADAEACQAFABAGAAQAJAAAGgDQAHgEAEgIIAAhCQAAgIADgEQAFgFAIAAIADAAQAIAAAEAFQAFAEAAAIIAABpQAAACgHABIgHABQgJAAgFgFQgFgFgCgKQgIALgKAGQgKAGgNAAQgLAAgKgFgAQNDCQgKgEgGgFQgFgFAAgIQAAgJAIgFIADAAIAAAAQAIAIAKADQAKAFAMAAQALAAAGgEQAGgCAAgGQgBgEgFgDQgEgEgJgCIgRgDQgJgCgHgEQgKgFgEgHQgEgHAAgLQgBgGACgHQACgFAEgFQADgEAHgFIAMgFQAKgDAMAAIAQABQAIACAGACQAKAEAFAFQAEAFAAAHQAAAFgBADQgCAEgFADIgCABQgIgJgJgDQgJgFgLAAQgKAAgGADQgFADAAAGQAAAFAFACQAEADAKADIASADQAJADAHADQAKAFAEAHQAFAHAAALQAAAKgFAIQgEAIgIAGQgIADgIACQgKADgMAAQgWgCgKgDgAOKDEQgHgCgGgEQgGgEgDgIQgDgGgBgJQABgKAEgIQAFgIALgGQAJgEAPgDQAPgCAUgBIAEAAQAAgGgBgEQgCgFgDgDQgEgDgFgCQgEgBgGgBQgLAAgIAGQgIAEgEAJIgBAAIgBABQgLAAgEgEQgGgEAAgHQAAgHADgFQAEgFAHgFQAIgEALgCQAKgDANAAQAOAAALADQALADAHAHQAIAGADAJQAEAKAAANIAABJQAAACgGAAIgIABQgJABgEgFQgGgFgBgKQgEAGgEADQgEAEgGACQgKAGgPAAQgJAAgHgDgAO+CNQgUABgHABQgIADgEAEQgEAFgBAFQAAAIAGAEQAEADAKAAQAGAAAGgBQAFgCAFgEQADgEACgFQADgFAAgGIAAgIgAnKDEQgIgCgFgEQgHgEgDgIQgCgGAAgJQAAgKAEgIQAGgIAKgGQAKgEAOgDQAPgCAUgBIAEAAQAAgGgBgEQgCgFgEgDQgCgDgGgCQgEgBgHgBQgKAAgIAGQgHAEgFAJIgBAAIgBABQgLAAgEgEQgGgEAAgHQAAgHAEgFQADgFAHgFQAIgEALgCQAKgDANAAQAOAAALADQALADAHAHQAIAGADAJQAEAKAAANIAABJQAAACgGAAIgIABQgIABgFgFQgGgFgCgKQgDAGgFADQgDAEgGACQgKAGgPAAQgJAAgHgDgAmXCNQgTABgHABQgIADgEAEQgFAFAAAFQABAIAEAEQAFADAKAAQAGAAAGgBQAGgCADgEQAFgEACgFQACgFAAgGIAAgIgAqUDEQgHgCgGgEQgGgEgDgIQgEgGAAgJQAAgKAGgIQAFgIAJgGQALgEAOgDQAPgCAUgBIAEAAQAAgGgCgEQgBgFgDgDQgDgDgFgCQgFgBgGgBQgLAAgIAGQgHAEgFAJIgBAAIgBABQgKAAgGgEQgFgEAAgHQAAgHADgFQAEgFAHgFQAIgEAKgCQALgDANAAQAPAAALADQAKADAIAHQAHAGADAJQAEAKAAANIAABJQAAACgGAAIgHABQgJABgGgFQgFgFgBgKQgEAGgEADQgEAEgGACQgLAGgOAAQgJAAgHgDgApgCNQgUABgHABQgIADgEAEQgEAFgBAFQAAAIAGAEQAEADAKAAQAGAAAGgBQAFgCAFgEQADgEACgFQADgFAAgGIAAgIgAvgDEQgHgCgGgEQgGgEgDgIQgEgGAAgJQABgKAFgIQAEgIALgGQAJgEAPgDQAPgCAUgBIAEAAQAAgGgCgEQgBgFgDgDQgEgDgFgCQgEgBgGgBQgLAAgIAGQgHAEgFAJIgBAAIgBABQgKAAgGgEQgFgEAAgHQAAgHADgFQAEgFAHgFQAIgEAKgCQALgDANAAQAPAAALADQAKADAIAHQAHAGADAJQAEAKAAANIAABJQAAACgGAAIgIABQgJABgFgFQgFgFgBgKQgEAGgEADQgFAEgFACQgKAGgPAAQgJAAgHgDgAusCNQgUABgHABQgIADgEAEQgEAFgBAFQAAAIAGAEQAEADAKAAQAGAAAGgBQAGgCAEgEQADgEACgFQADgFAAgGIAAgIgAySDDQgFgDgEgFIgCgDIAAAAIAzhGIgyhEQABgDAGgGQAIgFAJgBQAGABAEADQAFADAEAGIAhAxIAggxQAEgGAFgEQAFgDAFAAQAHABAFACQAFADAFAEIABAEIgyBFIAyBFIAAABQAAACgHAGQgIAFgJAAQgGAAgFgDQgFgDgEgHIgggxIghAxQgEAHgFADQgFADgFAAQgHAAgFgCgASKDFQgIAAgEgEQgEgEAAgJIAAhcQAAgIAEgEQAEgFAIAAIADAAQAJAAADAFQAFAEAAAIIAABcQAAAJgFAEQgEAEgHAAgANJDFQgHAAgEgEQgFgEAAgJIAAg4QAAgMgFgGQgFgGgLAAQgIAAgGADQgGAEgFAIIAABBQAAAJgDAEQgFAEgIAAIgDAAQgJAAgDgEQgEgEgBgJIAAg3QAAgZgUAAQgIAAgHADQgFAEgFAIIAABBQAAAJgEAEQgEAEgIAAIgDAAQgJAAgDgEQgFgEAAgJIAAhoQAAgCAHgBIAHgCQAJABAFAEQAFAFACAKQAIgLAJgEQAJgGAMAAQAIAAAHABQAFACAFADQAFADAEAFIAGALIAIgLQAEgFAGgDQAFgDAGgCQAGgBAGAAQALAAAJADQAIADAGAHQAFAGADAIQADAJAAANIAAA9QAAAJgEAEQgEAEgIAAgAJnDFQgIAAgEgEQgEgEAAgJIAAicQAAgCAGAAIAHgBQAIgBAEAEQAGADADAIQABAGAAAIIAACDQAAAJgDAEQgFAEgHAAgABODFQgIAAgEgEQgEgEAAgJIAAgyIg5hVQAAgDAGgFQAHgFALgBQAFABAEADQAEADAFAGIAiA5IAig5QAFgGAEgDQAEgDAFgBQAKAAAIAHQAFAEAAAEIg4BUIAAAyQAAAJgFAEQgEAEgIAAgAhEDFQgIAAgEgEQgEgEAAgJIAAg1QAAgbgXAAQgJAAgHAEQgHAEgEAIIAABAQAAAJgEAEQgEAEgHAAIgFAAQgHAAgFgEQgDgEAAgJIAAhoQAAgCAFgBIAIgCQAJABAGAEQAEAFACALQAIgLAKgFQAKgGANAAQALAAAJAEQAIADAHAIQAFAHADAJQACAJAAALIAAA7QAAAJgDAEQgEAEgIAAgAjZDFQgIAAgEgEQgEgEAAgJIAAhcQAAgIAEgEQAEgFAIAAIAEAAQAHAAAEAFQAEAEAAAIIAABcQAAAJgEAEQgDAEgIAAgAlDDFQgIAAgEgEQgEgEAAgJIAAhoQAAgCAGgBIAHgCQAKABAGAEQAEAGACALQAEgMAIgFQAHgGALAAQALAAAHAFQAFAGAAAKQAAAGgCAEQgCAFgEACIgDACIgBAAQgFgHgLAAQgGABgFACQgEADgEAEQgDAFgBAIQgBAHAAAKIAAAlQAAAJgFAEQgDAEgIAAgAoMDFQgIAAgEgEQgEgEAAgJIAAicQAAgCAGAAIAHgBQAIgBAEAEQAGADACAIQACAGAAAIIAACDQAAAJgDAEQgEAEgIAAgAtYDFQgIAAgEgEQgEgEAAgJIAAicQAAgCAGAAIAHgBQAIgBAEAEQAGADACAIQACAGAAAIIAACDQAAAJgEAEQgDAEgIAAgAKphEQgIgEgGgIQgFgHgDgIQgCgKAAgLIAAg7QAAgJADgEQAEgEAIAAIAEAAQAIAAAEAEQAEAEAAAJIAAA2QAAAHACAEQABAFADAEQADADAEACQAFABAFABQAKAAAGgFQAGgDAFgJIAAhAQAAgJADgEQAFgEAIAAIADAAQAIAAAFAEQAEAEAAAJIAABoQAAACgHABIgHABQgJAAgFgFQgFgFgCgJQgIAKgKAGQgKAFgNAAQgMAAgJgDgAGehFQgMgEgKgKQgRgRgBgdQABgPAEgMQAFgLAJgJQAJgJAMgFQAMgEAPAAQAKAAAJACQAJADAJAFQAHAFAGAHQAHAHADAJQAFAMAAAPQAAAKgCAJQgDAKgFAHQgFAJgIAFQgGAGgKAEQgMAEgPAAQgPAAgLgEgAGqikQgGADgFAFQgEAGgDAGQgCAHAAAIQAAAHACAHQADAGAEAGQAFAFAGADQAGACAJAAQAHAAAGgCQAGgDAFgFQAEgGADgGQACgGAAgIQAAgIgCgHQgDgHgEgFQgFgEgGgEQgGgCgHAAQgIAAgHACgAi+hEQgLgFgJgJQgIgIgEgMQgFgLAAgNIAAgDQAAgEACgDQADgDADABIBWAAQgCgIgDgFQgDgFgEgEQgFgEgGgCQgGgCgHAAQgGAAgJAFQgJAEgLAKQgFAAgFgEQgHgEAAgJQAAgKANgIQAIgFAKgDQAKgCAMAAQAeAAASASQAKAJAFALQAEALAAAPQAAAcgTATQgJAJgLAFQgMAEgOAAQgNAAgLgDgAjAhqQACAFAFAEQADADAGACQAEADAHAAQAGAAAGgDQAFgCAEgDQAEgEADgFQACgFACgHIg9AAQAAAHACAFgAsuhWIAAACQAAAJgFAEQgEAEgHAAIgEAAQgIAAgEgEQgEgEAAgJIAAibQAAgCAGgCIAHgBQAHABAGADQAFADADAIQACAGAAAIIAAApQAGgKALgFQAKgFAMAAQAOAAAKAFQAMAEAHALQAHAJAEAKQAEAMAAAOQAAAOgFAMQgEALgHAJQgJAKgKAEQgKAEgNAAQgbABgMgWgAsjihQgHAFgEAKIAAAYQgBAGADAFQACAGAFADQADAEAGADQAGACAGAAQAIAAAGgCQAGgEAEgEQAEgFACgHQACgGAAgIQAAgIgBgHQgCgGgFgFQgEgFgGgDQgFgDgJABQgKAAgJAEgAQYhDQgHgCgGgFQgGgFgDgGQgEgHAAgJQAAgLAGgHQAFgIAJgFQALgGAOgCQAPgDAUAAIAEAAQAAgGgCgFQgBgEgDgDQgDgDgFgCQgFgBgGAAQgLAAgIAEQgHAFgFAKIgBAAIgBAAQgKAAgGgEQgFgDAAgJQAAgFADgGQAEgFAHgEQAIgFAKgDQALgCANAAQAPAAALADQAKAEAIAFQAHAHAEAKQADAJAAANIAABJQAAACgGABIgHABQgJgBgGgEQgFgFgBgKQgEAGgEADQgEAEgGACQgLAGgOAAQgJAAgHgCgARMh7QgUABgHACQgIACgEAEQgEAEgBAHQAAAHAGAEQAEADAKAAQAGAAAGgCQAFgCAFgDQAEgDABgFQADgGAAgGIAAgHgAAGhDQgGgBgGgDIgNgIQgGgEgFgHQgEgFgEgHIgGgOQgDgJgCgXIAAgBQAAgHAEgDQAFgEAFAAIBpAAQgBgJgEgIQgEgHgFgFQgIgIgIgDQgJgEgKAAQgNAAgJAFQgIADgHAHIgJANQgIAAgFgEQgGgFAAgJQAAgHAFgHQAFgGAJgFQAJgIANgDQAKgDAOgBQAJABAIABIAPAEQAIADAGAEIAMALQAFAGAEAHIAHAPQADAHACAIIABASQAAANgDANQgDAMgGALQgGAKgJAIQgJAIgLAFQgHADgIACQgIACgJAAQgIAAgIgCgAgMh2IAHALQAFAGAFADQAIADAJAAQAKAAAHgDQAJgDAGgHQAFgEAEgHQADgGACgIIhUAAIAEAPgAvJhDQgHgCgGgFQgHgFgDgGQgCgHAAgJQAAgLAEgHQAFgIAKgFQALgGAOgCQAPgDAUAAIAEAAQAAgGgCgFQgBgEgEgDQgDgDgEgCQgFgBgHAAQgKAAgIAEQgHAFgFAKIgBAAIgBAAQgLAAgFgEQgFgDAAgJQAAgFAEgGQADgFAHgEQAIgFAKgDQALgCANAAQAPAAAKADQALAEAHAFQAIAHAEAKQADAJAAANIAABJQAAACgGABIgHABQgKgBgFgEQgFgFgCgKQgDAGgFADQgEAEgFACQgLAGgOAAQgJAAgHgCgAuWh7QgTABgHACQgIACgEAEQgFAEABAHQAAAHAEAEQAFADAKAAQAGAAAGgCQAFgCAEgDQAFgDACgFQACgGAAgGIAAgHgAJghFQgFgEgEgHIgVggIgUAgQgIANgMABQgGAAgFgCQgEgDgEgEIgBgDIAlgzIglg0QAAgDAGgEQAGgFAIAAQAGAAAGADQAEADAEAHIAVAhIAUghQAFgHAFgDQAEgDAGAAQAFAAAGACQAEACAEAFIACACIgnA1IAmAzIAAAAQAAADgGADQgGAGgJAAQgFAAgFgDgAk7hEQgFgDgCgEIgshsQAAgCAFgEQAHgDAHAAQAGAAAFAEQAFAEADAKIAaBJIAahJQACgKAGgEQAFgEAGAAQAGAAAEABQAEACAEAEIABACIgsBrQgCAFgFADQgFACgIAAQgIAAgFgCgAm9hFQgEgDgFgGIgngvIAAApQAAAJgEAEQgEAEgHAAIgFAAQgIAAgEgEQgDgEAAgJIAAibQAAgCAFgCIAIgBQAHABAFADQAFADADAIQACAGAAAIIAABNIAigsQAGgGAEgCQAFgDAFAAQAGAAAEACQAFACADAFIACADIgoAxIAsA2QAAACgFAEQgIAGgGAAQgGAAgFgDgAPYhDQgJAAgDgEQgFgEAAgJIAAg3QAAgMgFgHQgFgGgLAAQgIAAgGADQgHAFgEAHIAABBQAAAJgDAEQgFAEgIAAIgDAAQgIAAgEgEQgEgEgBgJIAAg2QAAgagUAAQgIAAgHADQgFAFgFAHIAABBQAAAJgEAEQgEAEgIAAIgDAAQgIAAgFgEQgDgEgBgJIAAhpQAAgBAHgCIAHAAQAJAAAFAEQAFAGACAJQAIgKAJgGQAJgFAMAAQAIAAAHACQAGABAFADQAEADAEAFIAGALIAIgLQAFgFAFgDQAFgDAGgBQAGgCAGAAQALAAAJADQAIADAGAGQAGAHACAJQADAIAAANIAAA9QAAAJgEAEQgEAEgIAAgAEhhDQgJAAgDgEQgEgEAAgJIAAhzIglAAQgIAAgFgEQgEgEAAgIIAAgBQAAgIAEgEQAFgDAIAAIBvAAQAIAAAFADQAEAEAAAIIAAABQAAAIgEAEQgFAEgIAAIglAAIAABzQAAAJgEAEQgEAEgIAAgACKhDQgJAAgDgEQgFgEAAgJIAAibQAAgCAHgCIAHgBQAHABAFADQAGADACAIQACAGAAAIIAACDQAAAJgEAEQgEAEgIAAgApAhDQgIAAgEgEQgEgEAAgJIAAhbQAAgJAEgEQAEgEAIAAIAEAAQAHAAAEAEQAEAEABAJIAABbQgBAJgEAEQgDAEgIAAgAqphDQgIAAgFgEQgDgEAAgJIAAhpQgBgBAHgCIAHAAQAKAAAFAEQAFAGACAKQADgLAIgGQAHgFALAAQAMAAAGAFQAGAFAAAKQAAAGgDAFQgBAEgFADIgDABIAAAAQgGgFgKgBQgGAAgFADQgEACgEAGQgDAFgCAHQgBAHAAAKIAAAlQAAAJgEAEQgEAEgIAAgAxXhDQgJAAgDgFQgFgGAAgJIAAh7QAAgLAGgFQAEgGAKABIBVAAQAIAAAEADQAEAEABAHIAAACQgBAIgEAEQgEADgIAAIhEAAIAAApIAxAAQAJAAADADQAFAFAAAGIAAABQAAAIgFAEQgDADgJAAIgwAAIAAAtQAAAJgDADQgEAFgJAAgApMjSQgEgEAAgKQAAgIAEgFQAFgFAJAAQAJAAAFAFQAFAFAAAIQAAAKgFAEQgFAFgIgBQgKABgFgFg");
	this.shape.setTransform(4.1,-13.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-114,-38,236.4,49);


(lib.Tween41 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.p1();
	this.instance.setTransform(-132.4,-139.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-132.4,-139.4,265,279);


(lib.Tween40 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.p2();
	this.instance.setTransform(-149.9,-299.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-149.9,-299.9,300,600);


(lib.Tween39 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A4XJfIAAy9MAwvAAAIAAS9g");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-155.9,-60.7,312,121.5);


(lib.Tween38 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.m1();
	this.instance.setTransform(-149.9,-87.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-149.9,-87.4,300,175);


(lib.Tween37 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.m2();
	this.instance.setTransform(-149.9,-155.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-149.9,-155.9,300,312);


(lib.Tween36 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.m4();
	this.instance.setTransform(-30.4,-85.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-30.4,-85.9,61,172);


(lib.Tween35 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.m3();
	this.instance.setTransform(-149.9,-131.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-149.9,-131.4,300,263);


(lib.Tween34 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.m5();
	this.instance.setTransform(-21.4,-59.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-21.4,-59.9,43,120);


(lib.Tween33 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.m6();
	this.instance.setTransform(-85.4,-35.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-85.4,-35.9,171,72);


(lib.Tween32 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.m7();
	this.instance.setTransform(-41.4,-34.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-41.4,-34.4,83,69);


(lib.Tween31 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.m8();
	this.instance.setTransform(-130.4,-25.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-130.4,-25.4,261,51);


(lib.Tween30 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.x1();
	this.instance.setTransform(-149.9,-299.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-149.9,-299.9,300,600);


(lib.Tween29 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.x2();
	this.instance.setTransform(-116.4,-177.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-116.4,-177.9,233,356);


(lib.Tween27 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.x3();
	this.instance.setTransform(-20.9,-20.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-20.9,-20.4,42,41);


(lib.Tween26 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.x3();
	this.instance.setTransform(-10.2,-10,0.49,0.49);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10.2,-10,20.6,20.1);


(lib.Tween25 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.x3();
	this.instance.setTransform(-14.7,-14.3,0.704,0.704);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.7,-14.3,29.6,28.9);


(lib.Tween24 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.x3();
	this.instance.setTransform(-21.7,-21.1,1.036,1.036);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-21.7,-21.1,43.5,42.5);


(lib.Tween23 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.x3();
	this.instance.setTransform(-14.7,-14.4,0.706,0.706);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.7,-14.4,29.7,29);


(lib.Tween22 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.x3();
	this.instance.setTransform(-10.2,-10,0.49,0.49);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10.2,-10,20.6,20.1);


(lib.Symbol32 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhBIbIgwBTIqmmHIB8jWIFGAAIAAAnIhaAAIhhCoIJcFeIAgg3IAAAAIA4hhIAwAAIgBAAIBDAAIgIgDIAIgSIAQAFQAJACAIAAQAHAAAFgCQAFgDADgDQADgEAAgFQAAgEgDgEQgCgDgEgCIgGgBIgFgBIgJABIgIACIgJgIIAXgjQgKgBgJgEQgKgEgJgIQgKgJgGgLQgGgMgCgNQgCgOAAgNIAAg1QAAgVAEgRQAEgRAKgMQAJgNAQgHQAQgIAXAAIANABQAJAAAIADQAJACAJAFQAJAFAIAJQAHAJADAIQADAJAAAIIABAPIgwAAQAAgGgCgGQgCgGgFgEQgFgEgLAAQgKAAgGAEQgGAEgCAHQgDAHAAAGIgBAMIAABCQAAAPADAIQACAIAGAEQAHAEALAAQAKAAAGgFQAFgEADgHQACgIAAgJIAzAAIgBARQgBAKgEALQgEALgIAJQgJAKgOAFQgPAGgWAAIgDAAIgOAVIAGgBIAFgBIAFAAQAHAAAGACQAHACAFAEQAGAEADAGQADAGAAAIQAAAKgFAIQgEAIgIAFIgDACIBKAAIiDDMIiWhWIg1BbgAHvFRQgHgCgJgEQgIgFgGgHQgHgIgEgLQgEgLAAgPQAAgIACgKQACgKAFgKQAFgKAKgJQAKgJAPgHQAQgIARgEQARgEAPAAIAAgSIgBgKQgBgEgCgDQgDgFgHgCQgGgDgJAAQgNAAgKAEQgKAEgIAGIgOALIgcgjIAPgLQAIgGAJgEQAKgEAOgDQANgCASAAIAPABIASADIATAHQAJAEAHAHQAJAJADAIQAEAJABAHIAAANIAABwIABACIABAFIAEAFQADACAEAAIAAApIgRAAQgLAAgIgDQgIgDgFgEIgJgJIgGgJIgCAAIgGAIIgHAGIgIAGIgHAEQgEACgKADQgIACgKAAIgQgBgAIpDbIgPAFQgHADgIAFQgHAGgEAIQgFAIAAAMQAAAIADAGQADAGAGAEQAFAEAHAAQAKAAAHgFQAGgEAEgHQADgHACgHIABgMIAAgkIgLADgAgyFRQgHgCgJgEQgIgFgHgHQgGgIgEgLQgEgLAAgPQAAgIACgKQACgKAFgKQAFgKAKgJQAJgJAQgHQAQgIARgEQAPgEAPAAIAAgSIgCgKQAAgEgDgDQgDgFgGgCQgEgDgJAAQgOAAgKAEQgJAEgIAGIgOALIgdgjIAPgLQAIgGAKgEQAKgEANgDQAOgCARAAIANABIATADIASAHQAJAEAIAHQAIAJAEAIQADAJABAHIABANIAABwIAAACIACAFIAEAFQADACAEAAIAAApIgSAAQgLAAgHgDQgIgDgGgEIgJgJIgFgJIgCAAIgHAIIgGAGIgIAGIgFAEQgFACgJADQgJACgJAAIgQgBgAAFDbIgMAFQgIADgHAFQgHAGgFAIQgEAIAAAMQAAAIADAGQADAGAFAEQAFAEAIAAQAKAAAEgFQAHgEADgHQAEgHABgHIABgMIAAgkIgLADgACHFMIAAk6IA9AAIAAE6gAi1FMIgghAIgCAAIgfBAIhAAAIBAhzIg9hwIA/AAIAXAvIACAEIAEAJIACAAIADgJIACgEIAXgvIA/AAIg8BwIBBBzgAk7A7IAAktIA3AAIAAAkIAEAAQAKgVAPgKQAPgKAVAAQAOAAAKAFQAJAEAHAHQAGAGADAIQADAIACAGQACALABANQABANAAAQIAAAiIAAAgIgBAWIgDAQQgCAHgFAGQgEAGgGAFQgGAFgJADQgJADgNAAQgOAAgKgEQgLgFgIgHQgIgIgGgJIgDAAIAABngAjri/QgGACgFAEQgGAEgDAEIAABmIAKAIQAGAEAGACQAFADAHAAQAJAAAFgEQAFgDACgIQACgHABgMIAAgbIgBgtIgBgHQgBgIgCgFQgDgEgDgDIgHgCIgGgBQgIABgGACgADTA4IAAgmIC6AAICIjpIpcleIiBDgIkDAAICmkhICfBcIAvhTICVBXIA0hcIKmGHIimEjgAjpA4IAAgnIFdABIAAAmgAoFgFQgbgSgJgkQgIgaAHgbQADgLAFgNIAKgWQAKgTADgJQAGgQgBgMQAAgRgIgNQgHgOgMgGQgJgFgKABQgNABgOALIgBgBQAKgPAOgIQAOgJARgBQAWgDAXAKQAYAKAVAVQAfAeARAcQATAhAIAvQADAVgFAXQgGAYgOATQgMAPgPAJQgPAIgSACIgNAAQgcAAgWgMgAmZiEQAVAHAEAWQACAQgFAQQgKAdgWANQgSAKgiACIgWASQAiAJAigRQAhgSAMgiQAHgRgCgSQgCgUgLgNQgFgHgLgIIgTgOQgYgRgGgPQgDgHACgGQACgFAEgBQAEgCAFADQAEADACAIIABgKQAAgFgFgFQgDgCgHgBQgHgBgFABQgJADgCADQgCADgBAIQgKgEgJAAQgNABgDAJQARgFAbAaQAKAKAFAIQAFAIgFgBQgFgCgIAEIgQAIQgVAMgGgHQgEgEAAgFQAAgEADgDQAEgDAFABQAFAAAFAFQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAIABgGQABgJgHgDQgGgDgIACQgIACgFAFQgIAHgCALQgBAJAEAJQAEAKAIAFQAJAGAKAAQAJAAAGgDQAGgCAHgFIAJgIQAFgEAGABQgGACgFAKIgIARQgFALgEAFQgFAGgIgBIAQADQAIABAIgFQAFAPALACQALACAJgIQAKgJABgLQABgNgNgJQAIAJgBAIQAAAGgGACQgGACgHgDQgHgEgEgKQgGgRANgLQAJgHAKAAQAFAAAFACgAgxgIQgIgCgJgEQgIgFgGgHQgHgIgEgLQgEgLAAgPQAAgIACgKQACgKAFgKQAFgKAKgJQAKgKAPgHQARgHAQgEQAOgEAQAAIAAgSIgBgKQgBgEgCgDQgDgEgGgDQgFgDgJAAQgNAAgKAEQgKAEgIAGIgOALIgcgjIAPgLQAIgGAKgEQAJgEAOgDQANgCASAAIANABIASADIATAHQAJAEAHAHQAJAJADAIQAEAIABAIIAAANIAABwIABACIACAFIAEAFQACACAFAAIAAApIgSAAQgLAAgIgDQgIgDgFgEIgJgKIgGgIIgBAAIgHAIIgGAGIgIAGIgGAEIgOAFQgIACgKAAQgIAAgHgBgAAGh+IgNAFQgHADgIAFQgHAGgEAIQgEAIgBAMQAAAIADAGQADAGAGAEQAFAEAHAAQAKAAAFgFQAGgEAEgHQADgHACgHIABgNIAAgjIgLADgAELgNIg/h5IA0hqIBAAAIg4BmIBFB9gACJgNIAAk6IA7AAIAAE6g");
	this.shape.setTransform(79.2,63.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.2,158.5,126.3);


(lib.Symbol30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Agoh/QAOAzATA+QAaBbAWAz");
	this.shape.setTransform(37.6,12.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Ah7jXQAOAzASA9QAmB5AZAyQAfBCAjAfQAgAdA2AW");
	this.shape_1.setTransform(46,21.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AlRkJQAOA0ATA9QAlB6AaAwQAgBDAjAfQAtAoBYAcQBXAcB4AbQByAZAgAAQAMAAAOAC");
	this.shape_2.setTransform(67.3,26.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("Anpl2QAOA0ATA9QAlB6AZAyQAhBCAjAeQAsAnBYAcQBZAdB3AaQBxAZAgAAQAnAAAsATQA2AXADAhQAEAnA7AvQA8AwA+ALQADABADAA");
	this.shape_3.setTransform(82.5,37.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AqsmNQAOAzATA9QAlB7AZAyQAhBCAjAfQAsAmBYAcQBZAcB5AbQBxAZAgAAQAlAAAsATQA2AWADAiQAEAmA7AvQA8AxA+ALQAoAHBigLQBWgJAaANQBLAlBHAK");
	this.shape_4.setTransform(102,39.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AtjmPQAOA0ATA9QAlB6AZAyQAhBCAjAgQAsAlBYAcQBaAdB4AaQBxAZAhAAQAnAAArATQA2AXAEAhQAEAnA6AvQA6AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA9gDDRguQANgDANgD");
	this.shape_5.setTransform(120.3,40);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AwymPQAOA0ATA9QAlB6AZAyQAhBCAjAgQAsAlBYAcQBZAdB5AaQBxAZAgAAQAoAAArATQA2AXADAhQAFAnA6AvQA8AwA+ALQAoAHBhgKQBWgKAaANQBvA4BogGQA9gDDRguQDFgsAwgRQA1gTBSgPQAkgHAYgB");
	this.shape_6.setTransform(141,40);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("A0NmZQAOA0ATA9QAlB6AZAyQAhBDAjAfQAsAmBYAcQBZAcB5AbQBxAZAgAAQAnAAAsATQA2AWADAiQAEAmA7AvQA8AxA+ALQAoAHBigLQBWgJAaANQBuA3BngFQA+gEDRguQDFgrAvgRQA2gUBRgPQBfgRAKARQAMATAzALQA0AKAogKQAcgIBVgtQBLggAMAeQANAfgXAoIgZAiIAZAZQAVAXAcAl");
	this.shape_7.setTransform(162.9,41);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("A3KouQAOA0ATA9QAlB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB5AaQBxAZAgAAQAnAAAsATQA2AVADAhQAEAnA7AvQA8AwA+ALQAoAHBigKQBWgKAaANQBwA4BngGQA8gDDRguQDFgsAvgRQA2gTBRgPQBfgRAKAQQAMAUAzAKQA0ALAogLQAcgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA8ArQAjAZA4AcQAfAUBRAY");
	this.shape_8.setTransform(181.8,55.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1).p("A5upyQAOAzATA9QAlB7AZAyQAhBCAjAfQAsAoBYAcQBZAcB5AbQBxAZAgAAQAnAAAsATQA2AWADAiQAEAkA7AvQA8AxA+ALQAoAHBigKQBWgKAaANQBwA4BngGQA+gDDPgvQDFgrAvgRQA2gUBRgPQBfgQAKAQQAMAUAzAKQA0ALAogLQAcgHBVgtQBLgfAMAcQANAggXAoIgZAhIAZAZQAmArA+BXQBABYA8AsQAjAZA4AcQAkAXBoAdQBQAWA8ALQAqAIA6AiQA8AjAAAS");
	this.shape_9.setTransform(198.2,62.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("A8ktUQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA2AXADAhQAEAnA7AvQA8AwA+ALQAoAHBigKQBWgKAaANQBwA4BngGQA+gDDRguQDDgsAvgRQA2gTBRgPQBfgRAKAQQAMAUAzAKQA0ALAogLQAcgHBVgtQBLghAMAeQANAggXAoIgZAhIAZAZQAmArA+BVQBABZA8ArQAjAZA4AcQAkAXBoAdQBQAWA8ALQAqAIA6AiQA8AjAAASQAAAWAsBRQAuBWAjAfQANAMBIBUQA9BGAsAdQAZARAYAU");
	this.shape_10.setTransform(216.5,85.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1,1,1).p("A+IxUQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAbQBQAWA8ALQAqAIA7AiQA7AjAAASQAAAWAsBRQAvBWAiAfQAOAMBIBUQA9BGArAdQA+AqA2A3QA8A/AOAtQAPAwAXB8QAWB5AAAbQAAABgBAX");
	this.shape_11.setTransform(226.5,110.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("A+N1AQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAeQBQAWA8AKQAqAIA7AjQA7AiAAASQAAAWAsBPQAvBXAiAfQAOALBIBUQA9BGArAeQA+ApA2A3QA8A/AOAuQAPAvAXB8QAWB6AAAbQAAABgEBeQgEBPADAkQAFA8AKDhQgHhOgchWQgriGhGg5");
	this.shape_12.setTransform(227,134.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1).p("A+N1AQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAeQBQAWA8AKQAqAIA7AjQA7AiAAASQAAAWAsBPQAvBXAiAfQAOALBIBUQA9BGArAeQA+ApA2A3QA8A/AOAuQAPAvAXB8QAWB6AAAbQAAABgEBeQgEBPADAkQAFA8AKDhQgHhOgchWQg3ishkgsQgkgQjYh4QgSgKgRgJ");
	this.shape_13.setTransform(227,134.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("A+N1AQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAeQBQAWA8AKQAqAIA7AjQA7AiAAASQAAAWAsBPQAvBXAiAfQAOALBIBUQA9BGArAeQA+ApA2A3QA8A/AOAuQAPAvAXB8QAWB6AAAbQAAABgEBeQgEBPADAkQAFA8AKDhQgHhOgchWQg3ishkgsQgkgQjYh4QiahVhPgJQhKgJiigqQiXgngSAAQgZAAg2AU");
	this.shape_14.setTransform(227,134.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("A+N1AQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAeQBQAWA8AKQAqAIA7AjQA7AiAAASQAAAWAsBPQAvBXAiAfQAOALBIBUQA9BGArAeQA+ApA2A3QA8A/AOAuQAPAvAXB8QAWB6AAAbQAAABgEBeQgEBPADAkQAFA8AKDhQgHhOgchWQg3ishkgsQgkgQjYh4QiahVhPgJQhKgJiigqQiXgngSAAQggAAhNAgQhJAfgvAgQgkAYgtgVQgWgMgJgFQgQgIgHACQgRADhHAkQg+AfgZAPQgQAJhDAGQgeADgYAB");
	this.shape_15.setTransform(227,134.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("A+N1AQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAeQBQAWA8AKQAqAIA7AjQA7AiAAASQAAAWAsBPQAvBXAiAfQAOALBIBUQA9BGArAeQA+ApA2A3QA8A/AOAuQAPAvAXB8QAWB6AAAbQAAABgEBeQgEBPADAkQAFA8AKDhQgHhOgchWQg3ishkgsQgkgQjYh4QiahVhPgJQhKgJiigqQiXgngSAAQggAAhNAgQhJAfgvAgQgkAYgtgVQgWgMgJgFQgQgIgHACQgRADhHAkQg+AfgZAPQgQAJhDAGQgxAFghAAQgQAAg5g2QgKgJg+g+QgTgVhBgiQhFglgjgDQhWgPg6gBQgWgBgTAC");
	this.shape_16.setTransform(227,134.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("A+N1AQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAeQBQAWA8AKQAqAIA7AjQA7AiAAASQAAAWAsBPQAvBXAiAfQAOALBIBUQA9BGArAeQA+ApA2A3QA8A/AOAuQAPAvAXB8QAWB6AAAbQAAABgEBeQgEBPADAkQAFA8AKDhQgHhOgchWQg3ishkgsQgkgQjYh4QiahVhPgJQhKgJiigqQiXgngSAAQggAAhNAgQhJAfgvAgQgkAYgtgVQgWgMgJgFQgQgIgHACQgRADhHAkQg+AfgZAPQgQAJhDAGQgxAFghAAQgQAAg5g2QgKgJg+g+QgTgVhBgiQhFglgjgDQhWgPg6gBQhtgDgMA2QgNA1AZBiQANAyAPAnIhLBkQiRAjgtAFQgTABhZA6QgHAEgGAE");
	this.shape_17.setTransform(227,134.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("A+N1AQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAeQBQAWA8AKQAqAIA7AjQA7AiAAASQAAAWAsBPQAvBXAiAfQAOALBIBUQA9BGArAeQA+ApA2A3QA8A/AOAuQAPAvAXB8QAWB6AAAbQAAABgEBeQgEBPADAkQAFA8AKDhQgHhOgchWQg3ishkgsQgkgQjYh4QiahVhPgJQhKgJiigqQiXgngSAAQggAAhNAgQhJAfgvAgQgkAYgtgVQgWgMgJgFQgQgIgHACQgRADhHAkQg+AfgZAPQgQAJhDAGQgxAFghAAQgQAAg5g2QgKgJg+g+QgTgVhBgiQhFglgjgDQhWgPg6gBQhtgDgMA2QgNA1AZBiQANAyAPAnIhLBkQiRAjgtAFQgTABhZA6QhpBBhSAfQhvAoh1BB");
	this.shape_18.setTransform(227,134.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,1,1).p("A+N2JQAOA0ASA9QAmB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB4AaQByAZAgAAQAnAAAsATQA1AXAEAhQAEAnA6AvQA8AwA/ALQAoAHBigKQBWgKAaANQBvA4BogGQA+gDDQguQDFgsAugRQA1gTBSgPQBfgRAKAQQALAUAzAKQA1ALAogLQAbgHBWgtQBLghAMAeQAMAggWAoIgZAhIAZAZQAlArA/BXQA/BZA9ArQAiAZA4AcQAkAXBoAdQBQAWA8ALQAqAIA7AiQA7AjAAASQAAAWAsBRQAvBUAiAfQAOAMBIBUQA9BGArAdQA+AqA2A3QA8A/AOAtQAPAwAXB8QAWB5AAAbQAAABgEBfQgEBOADAkQAFA8AKDhQgHhNgchWQg3ithkgsQgkgQjYh3QiahWhPgJQhKgIiigqQiXgogSAAQggAAhNAhQhJAfgvAfQgkAYgtgVQgWgLgJgFQgQgIgHABQgRAEhHAjQg+AfgZAPQgQAKhDAGQgxAEghAAQgQAAg5g1QgKgJg+g/QgTgVhBgiQhFgkgjgEQhWgPg6gBQhtgCgMA1QgNA1AZBjQANAyAPAmIhLBkQiRAjgtAFQgTAChZA5QhpBChSAeQirA/i9B6QiBBTgsAbQgTAMgRAK");
	this.shape_19.setTransform(227,141.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("A9m39QAOAzATA9QAlB7AZAyQAhBCAjAfQAsAoBYAcQBZAcB5AbQBxAZAgAAQAnAAAsATQA2AWADAiQAEAmA7AvQA8AxA+ALQAoAHBjgLQBVgJAaANQBwA4BngGQA+gEDRguQDDgrAwgRQA1gUBSgPQBfgRAKARQALATAzALQA1ALAogLQAbgIBWgsQBLghAMAeQAMAfgWAoIgZAiIAZAZQAlAqA/BYQA/BYA8AsQAjAYA4AdQAkAXBoAdQBQAWA8ALQAqAHA7AjQA7AiAAATQAAAVAsBRQAvBXAiAfQAOAMBIBRQA9BHArAdQA+ApA2A4QA8A+AOAuQAOAvAYB8QAWB6AAAbQAAABgEBeQgEBPADAkQAFA8AKDhQgHhOgchWQg3ishkgsQgkgQjYh4QiahVhPgJQhKgJiigqQiXgngSAAQggAAhNAgQhKAfguAgQgkAYgtgVQgWgMgJgFQgQgIgHACQgRADhHAkQg+AfgZAPQgRAJhCAGQgxAFghAAQgQAAg5g1QgKgKg+g+QgVgVg/giQhGglgjgDQhVgPg6gBQhtgDgNA2QgMA1AZBjQAMAxAPAnIhLBkQiRAjgtAFQgSAChaA5QhoBBhTAfQirA+i9B7QiABTgtAbQh1BGgtAKQgrAJhfApIhXAoIhLBLIgxAJ");
	this.shape_20.setTransform(223,153.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1).p("A7m4XQAOA0ATA9QAlB6AZAyQAhBCAjAgQAsAnBYAcQBZAdB5AaQBxAZAgAAQAnAAAsATQA2AXADAhQAEAnA7AvQA8AwA+ALQAoAHBigKQBWgKAaANQBwA4BngGQA+gDDRguQDDgsAvgRQA2gTBRgPQBfgRAKAQQAMAUAzAKQA0ALAogLQAcgHBVgtQBLghAMAeQANAggXAoIgZAhIAZAZQAmArA+BXQBABZA8ArQAjAZA4AcQAkAXBoAdQBQAXA8AKQAqAIA6AiQA8AjAAASQAAAWAsBRQAuBXAjAeQANAMBIBSQA9BGAsAeQA+ApA1A3QA9A/AOAuQAOAvAXB8QAXB6AAAbQAAABgFBeQgDBPADAkQAFA8AKDhQgIhOgbhWQg3ishkgsQglgQjXh4QiahVhPgJQhLgJiigqQiWgngSAAQggAAhNAgQhKAfgvAgQgjAYgtgVQgWgMgKgFQgPgIgIACQgQADhHAkQg/AfgZAPQgQAJhCAGQgxAFgiAAQgQAAg4g2QgKgJg/g+QgVgVhAgiQhGglghgDQhWgPg5gBQhtgDgNA2QgMA1AZBiQAMAyAPAnIhLBkQiRAjgtAFQgSABhaA6QhoBBhTAfQirA+i9B7QiABTgtAbQh1BGgtAKQgrAJhfApIhXAoIhLBLIkxA8");
	this.shape_21.setTransform(210.2,156);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).wait(993));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol25 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B41F2A").s().p("ApyFrQgEgCAAgDIAAgCIAIgSQgLgBgJgDQgJgDgGgFQgGgEgDgFQgDgEAAgFQAAgJAKgIIADgBIAAAAQAJAJAMAGIAMAFIANABQAOAAAHgEQAHgFAAgKQAAgFgGgEQgFgFgLgDIgUgFQgLgCgJgGQgFgCgEgEIgHgIQgDgEgBgGQgBgFAAgGQAAgJACgGQACgHAEgGQAFgFAGgEQAHgFAJgCQALgEANAAQANAAAKADQALACAHAEQAHAEAEAFQADAFAAAFQAAAFgCAEQgDAFgGADIgDABQgIgJgKgFQgKgEgMAAQgOAAgGAEQgHAFAAAJQAAAGAFADQAFAEAKACIAZAHQAPAEAJAHQAIAGAEAIQAEAIAAAKQAAAJgDAIQgCAIgFAFQgFAGgIAEQgHAEgKACIgaAaQgDACgEAAgALFFQQgHgBgGgDIgMgHQgGgEgEgGIgIgLIgGgNQgDgJgBgVIAAgCQAAgGAEgDQADgDAGAAIBjAAQgBgJgDgHQgEgHgFgFQgHgHgIgDQgIgDgJAAQgNAAgJADQgJAEgGAHIgIAMQgIgBgEgDQgGgGAAgHQAAgHAFgGQAEgGAIgFQAKgHALgDQAMgDANAAIAPABQAIABAHADQAHADAGAEIALAKQAFAFAEAHIAHANIADAPIACARQAAANgDALQgDALgGAKQgFAKgJAHQgIAIgKAFQgHADgIABQgHACgIAAQgIAAgHgCgAKyEhQADAFAEAFQAFAFAGADQAHADAJAAQAJAAAHgDQAIgDAGgGQAEgEAEgGIAFgOIhRAAIAEAPgAnjFQQgHgBgGgDIgMgHQgGgEgEgGIgIgLIgGgNQgDgJgBgVIAAgCQAAgGAEgDQADgDAGAAIBjAAQgBgJgDgHQgEgHgFgFQgHgHgIgDQgIgDgJAAQgNAAgJADQgJAEgGAHIgIAMQgIgBgEgDQgGgGAAgHQAAgHAFgGQAEgGAIgFQAKgHALgDQAMgDANAAIAPABQAIABAHADQAHADAGAEIALAKQAFAFAEAHIAHANIADAPIACARQAAANgDALQgDALgGAKQgFAKgJAHQgIAIgKAFQgHADgIABQgHACgIAAQgIAAgHgCgAn2EhQADAFAEAFQAFAFAGADQAHADAJAAQAJAAAHgDQAIgDAGgGQAEgEAEgGIAFgOIhRAAIAEAPgABuFOQgFgCgEgFIgBgDIAAgBIAvhAIguhAQAAgDAGgFQAIgFAIAAQAFAAAFADQAEADAEAGIAeAtIAegtQAEgHAFgDQAEgDAFAAQAHAAAEADQAFACAEAFIACADIgvBBIAvBAQAAADgHAFQgHAFgIAAQgGAAgFgDQgEgDgEgGIgeguIgfAvQgEAGgFADQgEADgFAAQgGAAgFgDgAh6FNQgFgEgDgJIgJgYIg4AAIgKAZQgDAIgEAEQgFAEgHAAQgFAAgEgCQgEgCgDgDIgCgDIA0iIQACgFAGgCQAGgDAJAAIANABQAHADACAGIA2CHQAAADgGAEQgGAEgHAAQgHAAgFgEgAiTEOIgUg3IgWA3IAqAAgANoFQQgHAAgDgEQgEgEAAgIIAAhrIgjAAQgIAAgEgEQgEgEAAgHIAAgBQAAgHAEgEQAEgEAIAAIBoAAQAIAAAEAEQAEAEAAAHIAAABQAAAHgEAEQgEAEgIAAIgiAAIAABrQAAAIgEAEQgEAEgIAAgAJqFQQgHAAgDgEQgEgEAAgIIAAhaIgZA9QgDAHgDACQgEACgIAAQgJAAgEgDIgEgIIgag8IAABZQAAAIgDAEQgDAEgHAAIgGAAQgHAAgDgEQgEgEAAgIIAAh5QAAgJAFgEQAEgEAJAAIAJAAQAIAAAEACQAEADADAHIAeBIIAghIQADgHAEgDQADgCAHAAIAKAAQAIAAAFAEQAEAEAAAJIAAB5QAAAIgDAEQgDAEgHAAgAETFQQgHAAgEgEQgEgEAAgIIAAh7QAAgIAEgEQAEgDAHAAIAFAAQAIAAADADQAEAEAAAIIAAB7QAAAIgEAEQgDAEgIAAgAANFMQgDgCgHgIIgegpIgNAAIAAAnQAAAIgEAEQgEAEgHAAIgFAAQgIAAgDgFQgEgEAAgKIAAhzQAAgKAEgFQAFgFAJAAIAtAAQANAAAMADQALADAHAGQAIAGAEAJQADAJAAAMQAAAKgCAHQgCAIgFAGQgFAFgIAEQgHAEgKABIAnAwIABABQAAADgFAEQgGAFgKAAQgIAAgFgEgAgpD/IAbAAQAHAAAFgBQADgBAEgDQADgDACgEQACgFAAgFQAAgGgCgFQgCgEgEgDQgDgDgDgBQgGgBgHAAIgaAAgAkZFOQgDgCgGgHIgzg9IAAA4QAAAIgEAEQgDAEgIAAIgFAAQgHAAgEgEQgEgEAAgIIAAh7QAAgIAEgEQAEgDAHAAIAFAAQAIAAADADQAEAEAAAIIAAA3IAyg7QAHgHADgCQAFgCAFAAQAFAAAFACQAFACADAFIABAEIg0A+IA2BBIAAABQAAADgGAFQgGAFgJAAQgFAAgFgCgAufFQQgIAAgDgEQgEgEAAgIIAAh2QAAgKAEgFQAFgFAJAAIAoAAQA/AAAAA0QAAANgEAKQgEAJgIAHQgIAGgLADQgMAEgQAAIgXAAIAAAiQAAAIgEAEQgEAEgHAAgAuMEDIAXAAQAIAAAFgBQAGgCADgDQAEgDACgFQACgEAAgHQAAgGgCgEQgCgFgEgDQgDgDgGgCQgFgBgIAAIgXAAgAFKFKQgGgGAAgIIAAhyQAAgJAFgFQAFgGAJAAIA5ACIAQAEIAOAGIAMAJQAFAFAEAGQAFAGACAHIAEAPQACAHAAAJQAAAJgCAIIgEAPIgHANQgEAGgFAFIgNAKQgGAEgIACQgIADgIABIg3ABQgJAAgFgFgAFnExIAVAAQAMAAAJgDQAJgDAGgGQAGgGAEgIQADgJAAgMQAAgLgDgIQgEgJgGgGQgGgGgJgDQgJgDgLAAIgWAAgAsRFPQgJAAgFgEQgFgFAAgKIAAhyQAAgKAFgFQAFgFAJAAIBVAAQAIAAAEAEQAEAEAAAHIAAABQAAAIgEADQgEAEgIAAIhFAAIAAAeIAyAAQAIAAAEADQAEAEAAAHIAAABQAAAHgEADQgEAEgIAAIgyAAIAAAhIBGAAQAIAAAEADQAEAEAAAHIAAABQAAAIgEADQgEAEgIAAgAEIClQgFgFAAgIQAAgIAFgFQAGgFAIAAQAIAAAFAFQAGAFAAAIQAAAIgGAFQgFAFgIAAQgJAAgFgFgAorAEQgPgHgHgMQgHgLAAgMQAAgJADgHQAEgGAHgFQAKgGALAAIAEABQAEAMAGAIQAGAJAJAGQAJAGAMADQAMACAOAAQAYAAAPgIQAKgFAFgJQAEgIAAgLQAAgKgDgIQgDgHgHgFQgGgFgKgDQgKgCgNAAIgPAAQgQAAgHgGQgIgGAAgLIAAgEQAAgLAHgGQAIgFAPAAIAWAAQAVAAAKgJQAKgIAAgRQAAgKgDgHQgDgHgHgEQgHgFgKgCIgXgCQgNAAgKACQgKADgIAFQgIAFgGAIQgHAIgEALIgDABQgLAAgKgHQgHgEgEgHQgDgGAAgIQAAgNAHgKQAHgLAOgJQAPgKAUgFQATgFAXAAQBzAAAABRQAAALgDAJQgDAKgGAIQgHAHgJAGQgKAGgNAEQAPAEAKAHQALAHAHAKQAHAJAEAMQADALAAAOQAAAZgJARQgKASgTAJQgPAJgVAFQgVAEgaAAQgzAAgggWgAqZAXQgOAAgHgHQgHgIAAgNIAAi4QgNAJgNAAQgSAAgLgLQgMgKAAgRQAAgVAOgJIAEgCIAAAAQANAKAPAAQAPAAAKgJQALgKACgPIAUAAQAOAAAIAIQAHAIAAAPIAADuQAAANgHAIQgIAHgOAAgAKxASQgHgEgLgNIhhhyIAABrQAAANgHAIQgIAHgOAAIgKAAQgOAAgHgHQgHgIAAgNIAAjsQAAgPAHgIQAHgHAOAAIAKAAQAOAAAIAHQAHAIAAAPIAABoIBghxQAMgNAHgEQAIgEAKAAQALAAAJAEQAIAFAHAKIACAGIhjB4IBmB9IABABQAAADgLAJQgNALgQAAQgLAAgIgEgAGcAWQgOAAgHgHQgHgIAAgNIAAjsQAAgPAHgIQAHgHAOAAIAJAAQAPAAAHAHQAIAIAAAPIAADsQAAANgIAIQgHAHgPAAgAjJAWQgOAAgHgHQgHgIAAgNIAAjsQAAgPAHgIQAHgHAOAAIAJAAQAPAAAHAHQAIAIAAAPIAADsQAAANgIAIQgHAHgPAAgACrAUQgRAAgJgJQgJgJAAgQIAAjkQAAgPAHgIQAHgHAOAAIAKAAQAOAAAIAHQAHAIAAAPIAADNIBtAAQAQAAAIAIQAHAHAAAOIAAABQAAANgHAHQgIAHgQAAgAhHAUQgRAAgJgJQgJgJAAgQIAAjkQAAgPAHgIQAHgHAOAAIAKAAQAOAAAIAHQAHAIAAAPIAADNIBrAAQAQAAAIAIQAHAHAAAOIAAABQAAANgHAHQgIAHgQAAgAGHkwQgKgKAAgPQAAgPAKgKQAKgJARAAQAPAAAKAJQAKAKAAAPQAAAPgKAKQgKAJgQAAQgQAAgKgJgAjekwQgKgKAAgPQAAgPAKgKQAKgJARAAQAPAAAKAJQAKAKAAAPQAAAPgKAKQgKAJgQAAQgQAAgKgJg");
	this.shape.setTransform(94.4,36.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,188.8,73);


(lib.Symbol24 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B41F2A").s().p("ADME2QgFgCAAgDIAAgDIAKgWQgOgCgLgEQgLgDgJgHQgHgFgDgFQgEgGgBgHQAAgLANgKIAEgBIAAAAQAMAMAPAHIAPAGQAIABAIAAQASABAJgHQAIgFAAgMQAAgHgGgGQgIgFgNgEIgZgHQgNgDgNgGQgGgDgFgFQgGgEgDgGQgDgGgCgGQgBgIgBgHQAAgLADgIQADgJAFgHQAGgHAJgFQAHgFAMgEQAOgEAQAAQARAAANADQANADAKAGQAIAFAFAFQAEAHAAAHQAAAGgDAFQgEAGgGAEIgEABIgBAAQgJgLgNgHQgNgFgQgBQgQABgJAFQgIAGAAAMQAAAHAGAEQAGAFAMADQASADAPAFQASAGALAJQALAHAEALQAFAJABANQAAAMgEAKQgDAJgGAHQgGAHgKAGQgKAEgMADIgBACIgfAeQgEADgFABgANCEWQgJgCgIgEQgIgEgHgFQgHgGgGgGQgFgIgFgHIgGgRQgFgLgBgaIAAgCQAAgIAFgEQAEgDAHgBIB+AAQgCgKgEgJQgFgJgGgHQgIgJgKgDQgLgFgMAAQgPAAgNAFQgKAFgIAIIgKAPQgKgBgFgEQgIgHABgJQAAgJAFgHQAGgIAKgHQAMgHAPgFQAOgEAQAAQAKAAAKACQAJABAJAEQAJAEAHAEQAIAGAGAHQAHAHAFAIQAFAIADAJIAGATIABAWQAAAPgEAPQgDANgIANQgHAMgKAKQgLAJgNAHQgJAEgIACQgKACgKAAQgKAAgJgCgAMqDZIAIANQAHAHAIAEQAJADALAAQALAAAKgDQAJgFAHgHQAGgGAFgGQADgIADgKIhmAAQACALADAHgAu2EWQgJgCgIgEQgHgEgHgFQgHgGgHgGQgFgIgEgHIgHgRQgEgLgBgaIAAgCQAAgIAEgEQAFgDAGgBIB+AAQgCgKgDgJQgFgJgGgHQgJgJgKgDQgLgFgMAAQgPAAgMAFQgKAFgIAIIgKAPQgLgBgFgEQgHgHAAgJQAAgJAGgHQAGgIAKgHQAMgHAOgFQAPgEAPAAQALAAAJACQAKABAIAEQAJAEAIAEQAIAGAGAHQAHAHAFAIQAEAIAEAJIAFATIACAWQgBAPgEAPQgDANgHANQgHAMgLAKQgKAJgOAHQgIAEgJACQgJACgLAAQgKAAgJgCgAvODZIAIANQAHAHAIAEQAKADAKAAQALAAAKgDQAJgFAHgHQAHgGAEgGQAEgIACgKIhlAAQACALACAHgASUEVQgKAAgEgFQgFgFAAgKIAAibQAAgKAFgFQAEgFAKAAIAGAAQAKAAAEAFQAGAFAAAKIAACbQAAAKgGAFQgEAFgKAAgAQQEVQgJAAgEgFQgFgFAAgKIAAiIIgsAAQgKABgFgFQgFgFAAgKIAAgBQAAgJAFgEQAFgFAKAAICDAAQAKAAAGAFQAEAEAAAJIAAABQAAAKgEAFQgGAFgKgBIgrAAIAACIQAAAKgFAFQgFAFgKAAgALLESQgFgCgHgJIg/hMIAABGQAAAKgGAFQgEAFgKAAIgGAAQgKAAgEgFQgEgFAAgKIAAibQAAgKAEgFQAEgFAKAAIAGAAQAKAAAEAFQAGAFAAAKIAABFIA/hLQAHgJAFgCQAGgDAGAAQAHAAAGADQAFADAFAGIABAFIhBBPIBEBSIAAABQAAADgHAGQgJAHgKAAQgIAAgFgDgAINEQQgEgDgHgJIgqg0IgRAAIAAAxQABAKgFAFQgFAFgKAAIgFAAQgKAAgFgGQgEgGAAgMIAAiRQAAgMAFgHQAHgGAKAAIA6AAQASAAAPAEQAOAEAKAHQAKAHAEAMQAEALABAQQAAAMgDAJQgEAKgGAHQgGAHgJAEQgKAFgNACIAzA9IAAABQAAAEgGAFQgIAGgMAAQgKAAgHgFgAHHCvIAhAAQAKAAAGgCQAGgCAFgDQAFgEACgFQABgFAAgIQAAgHgBgFQgDgGgFgDQgEgEgGgCQgIgCgIABIghAAgAFeEVQgKAAgFgFQgEgFAAgKIAAibQAAgKAEgFQAFgFAKAAIAFAAQAKAAAFAFQAFAFAAAKIAACbQAAAKgFAFQgFAFgKAAgAAtESQgFgCgHgJIg+hMIAABGQAAAKgFAFQgFAFgKAAIgFAAQgKAAgFgFQgEgFAAgKIAAibQAAgKAEgFQAFgFAKAAIAFAAQAKAAAFAFQAFAFAAAKIAABFIA9hLQAIgJAFgCQAFgDAGAAQAIAAAGADQAFADAFAGIABAFIhBBPIBDBSIAAABQAAADgHAGQgIAHgLAAQgHAAgFgDgAiJEVQgJAAgEgFQgFgFgBgKIAAibQABgKAFgFQAEgFAJAAIAGAAQAKAAAFAFQAFAFAAAKIAACbQAAAKgFAFQgFAFgKAAgAo1EVQgJAAgFgFQgFgFAAgKIAAibQAAgKAFgFQAFgFAJAAIAGAAQAKAAAEAFQAFAFABAKIAACbQgBAKgFAFQgEAFgKAAgAqFEVQgJAAgEgFQgEgFgBgKIAAhyIggBNQgDAJgFADQgEACgKAAQgMAAgFgEQgCgCgDgIIgghMIAABxQAAAKgFAFQgEAFgIAAIgIAAQgIAAgEgFQgFgFAAgKIAAiZQABgLAFgFQAFgGALAAIAMAAQAKAAAFADQAFADADAKIAnBbIAnhbQAFgJAEgEQAFgDAJAAIALAAQAMAAAFAGQAGAFAAALIAACZQAAAKgFAFQgEAFgIAAgAxbEVQgKAAgFgFQgEgFAAgKIAAiIIgsAAQgKABgFgFQgFgFAAgKIAAgBQAAgJAFgEQAFgFAKAAICDAAQAKAAAFAFQAFAEABAJIAAABQgBAKgFAFQgFAFgKgBIgrAAIAACIQAAAKgFAFQgFAFgKAAgAkoEUQgMAAgFgGQgGgGAAgMIAAiWQAAgKAFgFQAEgFAJAAIAHAAQAJAAAFAFQAFAFAAAKIAACHIBIAAQAKABAGAEQAEAFAAAJIAAABQAAAKgEAEQgGAFgKAAgAnkEUQgMAAgGgEQgHgFAAgKIAAgDQABgMAOgRIBYhpIhSAAQgJAAgFgEQgFgFAAgIIAAgDQAAgIAFgEQAFgFAJAAIBxAAQANAAAGAFQAFAEABAJIAAADQAAAGgEAIQgDAHgIAIIhZBqIBYAAQAJAAAFAEQAFAFAAAIIAAADQAAAIgFAFQgFAEgJAAgASGA9QgGgGAAgKQAAgKAGgHQAHgGAKAAQALAAAGAGQAHAHAAAKQAAAKgHAGQgGAGgLAAQgKAAgHgGgAFPA9QgGgGAAgKQAAgKAGgHQAIgGAKAAQAKAAAHAGQAHAHAAAKQAAAKgHAGQgHAGgKAAQgLAAgHgGgAiWA9QgHgGAAgKQAAgKAHgHQAHgGAKAAQALAAAGAGQAHAHgBAKQABAKgHAGQgGAGgLAAQgLAAgGgGgApDA9QgHgGABgKQgBgKAHgHQAHgGAKAAQALAAAGAGQAHAHAAAKQAAAKgHAGQgGAGgLAAQgLAAgGgGgAE8g5QgPgDgKgHQgKgFgEgGQgEgHgBgIQAAgKANgKIAEgBIAAAAQAMALAPAIIAPAFQAIACAIAAQASAAAIgGQAJgGAAgMQAAgGgGgGQgIgFgNgEIgagHQgNgDgLgHQgHgDgFgFQgGgEgDgGQgDgFgBgHQgCgHAAgIQAAgKADgIQACgJAGgIQAFgGAIgFQAJgFALgEQAOgFARAAQAQAAANAEQANADAKAFQAIAGAFAFQAEAGAAAHQAAAGgEAGQgDAFgHAEIgDACIAAAAQgLgMgNgGQgNgGgPAAQgRAAgIAGQgIAGAAALQAAAHAGAFQAGAFAMADQASADAPAFQASAFALAJQAKAIAGAKQAEAKAAANQABAggZAPQgKAHgNADQgOAEgSAAQgRAAgOgEgArJg8QgPgFgKgLQgLgJgFgRQgFgPAAgWIAAhcQAAgKAFgGQAEgEAKAAIAFAAQAKAAAFAEQAEAGAAAKIAABcQABAMACAIQADAJAEAGQAGAGAHADQAHACAKAAQAKAAAHgCQAHgDAGgGQAEgGADgJQACgIAAgMIAAhcQAAgKAFgGQAFgEAJAAIAGAAQAJAAAFAEQAFAGAAAKIAABcQAABVhUAAQgUAAgQgGgAJMg8QgGgGgEgLIgLgdIhHAAIgMAeQgEALgGAFQgGAEgIAAQgGAAgGgCQgFgCgEgFIgCgEIBCiqQACgGAIgEQAGgDANAAQALAAAFACQAJADADAIIBDCqIABAAQAAAEgIAFQgHAFgJgBQgJAAgHgEgAItiMIgahGIgaBGIA0AAgAjPg8QgHgEgEgIIhDimQABgDAIgFQAJgGAJABQAJAAAGAEQAGAGAEAKIAqB9IAqh9QAEgKAFgGQAHgEAIAAQAIAAAFACQAHADAEAFQABAAAAABQAAAAAAAAQABABAAAAQAAABAAAAIAAABIhDClQgDAIgHAEQgGAEgKAAQgJAAgGgEgADUg9QgEgDgIgKIgog0IgRAAIAAAxQAAALgFAFQgFAEgJAAIgGAAQgKAAgFgFQgEgGAAgMIAAiSQAAgMAFgHQAHgFAKAAIA6AAQATAAAOADQAOAEAKAHQAKAIAEAMQAEAKAAAQQAAAMgCAKQgDAJgHAIQgGAGgKAFQgJAEgMADIAxA9IABAAQAAAEgGAFQgIAHgMgBQgKABgHgFgACOieIAhAAQAJAAAHgCQAGgCAFgEQAEgDACgGQACgFAAgHQAAgIgCgFQgCgGgFgDQgEgDgGgCQgIgCgIAAIghAAgAlNg5QgKAAgEgEQgFgFAAgLIAAiaQAAgKAFgGQAEgEAKAAIAGAAQAJAAAGAEQAEAGAAAKIAACaQAAALgEAFQgGAEgJAAgAmbg5QgGAAgGgCQgGgDgDgFIhXh3IAABtQAAALgFAFQgEAEgKAAIgEAAQgJAAgEgEQgFgFAAgLIAAiZQAAgLAFgFQAEgGAKABIAFAAQANAAAKAMIBTBzIAAhrQAAgKAFgGQAFgEAJAAIAEAAQAKAAAEAEQAFAGgBAKIAACZQABALgFAGQgFAEgKAAgAKdg6QgLAAgGgFQgGgHABgLIAAiWQgBgKAFgGQAFgEAJAAIAGAAQAKAAAFAEQAEAGABAKIAACHIBIAAQAJAAAGAEQAFAFAAAJIAAABQAAAKgFAFQgGAEgJAAgAg4g6QgKAAgGgFQgGgHAAgLIAAiRQAAgMAGgHQAGgFAKAAIBqAAQALAAAEAEQAFAFABAJIAAABQgBAJgFAGQgEAEgLAAIhUAAIAAAmIA9AAQAKAAAGAFQAEAEAAAIIAAABQAAAKgEAEQgGAFgKgBIg9AAIAAArIBWAAQAKAAAFADQAFAFAAAJIAAABQAAAKgFAFQgFAEgKAAgAlbkRQgHgGAAgKQAAgKAHgGQAHgHAKAAQALAAAHAHQAGAGAAAKQAAAKgGAGQgHAHgLgBQgLABgGgHg");
	this.shape.setTransform(120,31.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,239.9,62.6);


(lib.Tween2_1 = function() {
	this.initialize();

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9D2029").s().p("A82SPIH0tjITpAAInKNCMAlaAVoIlTJLgAQf6SIgEAHIznAAIM22VIPBIrIn4Nqg");

	this.addChild(this.shape_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-184.7,-310.4,369.6,621);


(lib.Tween1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B41F2A").s().p("EgX1AoNIEVngIUIAAIqFP0gAJAwtMgmCgV+IFrp1MA0aAeSIrLTpIzXAEg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-185.9,-310.4,372,621);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E1182C").s().p("AkZBgIBvi/IHEAAIAAC/g");
	this.shape.setTransform(28.2,9.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E1182C").s().p("AodBgIBvi/IPLAAIAAC/g");
	this.shape_1.setTransform(54.2,9.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E1182C").s().p("AteBgIBvi/IZOAAIAAC/g");
	this.shape_2.setTransform(86.4,9.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E1182C").s().p("AMXBgIAAi/IKnABIAAC+gA29BgIBvi/IZOAAIAAC/g");
	this.shape_3.setTransform(147.1,9.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E1182C").s().p("AHtBgIAAi/IT6ABIAAC+gA7mBgIBvi/IZQAAIAAC/g");
	this.shape_4.setTransform(176.8,9.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E1182C").s().p("AEFBgIAAi/IbKACIAAC9gA/OBgIBvi/IZQAAIAAC/g");
	this.shape_5.setTransform(200,9.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E1182C").s().p("AfmBgIAAi9IGqAAIAAC9gAi5BgIAAi/IbIACIAAC9gEgmPABgIBvi/IZQAAIAAC/g");
	this.shape_6.setTransform(244.9,9.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E1182C").s().p("AZBBgIAAi9IT0ABIAAC8gApeBgIAAi/IbIACIAAC9gEgs0ABgIBvi/IZQAAIAAC/g");
	this.shape_7.setTransform(287,9.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E1182C").s().p("AVvBgIAAi9IaYABIAAC8gAsxBgIAAi/IbIACIAAC9gEgwHABgIBvi/IZRAAIAAC/g");
	this.shape_8.setTransform(308,9.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E1182C").s().p("ASEBgIAAi9MAhvAACIhrC7gAwcBgIAAi/IbIACIAAC9gEgzyABgIBvi/IZRAAIAAC/g");
	this.shape_9.setTransform(331.5,9.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(3427));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.Symbol55("synched",0);
	this.instance.setTransform(42.7,42.8,1,1,0,0,0,42.7,42.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({startPosition:0,_off:false},0).wait(6));

	// Layer 1
	this.instance_1 = new lib.Symbol54("synched",0);
	this.instance_1.setTransform(32.4,53.1,1,1,0,0,0,25.6,25.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({startPosition:0},0).to({_off:true},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.8,27.6,51.1,51.1);


(lib.Symbol50 = function() {
	this.initialize();

	// Layer 1
	this.instance = new lib.Symbol48("synched",0);
	this.instance.setTransform(269.6,33.1,1,1,0,0,0,269.6,29.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B23336").s().p("AIKARIAAgUQAAgFAEgEQAFgEAEAAIBQAAQAFAAADAEQAEAEAAAFIAAAUgApyARIAAgUQAAgFAFgEQAFgEAEAAIBPAAQAFAAAEAEQAEAEAAAFIAAAUg");
	this.shape.setTransform(320.2,1.8);

	this.addChild(this.shape,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,539.3,62.6);


(lib.Symbol40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween21("synched",0);
	this.instance.setTransform(120,23.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0.672},16).wait(960));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,240,47);


(lib.Symbol39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween17("synched",0);
	this.instance.setTransform(149.5,300.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},12).wait(875));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,299.1,600.2);


(lib.Symbol38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.Tween15("synched",0);
	this.instance.setTransform(186.1,464.7,1,0.016);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:3.2,scaleY:3.86,y:360.1},8,cjs.Ease.get(1)).to({scaleY:0.17,y:469.3},9,cjs.Ease.get(1)).wait(1136));

	// Layer 3
	this.instance_1 = new lib.Tween16("synched",0);
	this.instance_1.setTransform(171,-161.4,1,0.013);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleY:4.95,y:38.8},8,cjs.Ease.get(1)).to({scaleY:0.13,y:-157.7},9,cjs.Ease.get(1)).wait(1136));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-161.9,357.1,627.2);


(lib.Symbol37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween14("synched",0);
	this.instance.setTransform(183.6,9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:28.51,y:256.6},10,cjs.Ease.get(1)).to({scaleX:0.04,scaleY:0.73,rotation:-89.8,x:181.6,y:485.9},8,cjs.Ease.get(1)).wait(627));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,367.1,18);


(lib.Symbol27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	/* Layers with classic tweens must contain only a single symbol instance. */

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol25copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 11
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmKDLQgDgCgBgGIgJheQAAgIADgEQADgEAHgBIAfgDQAygEAEAoQABALgDAIQgCAHgFAGQgGAGgJADQgJAEgNABIgSACIADAbQAAAGgCADQgDAEgGAAIgEABIgCAAQgEAAgDgDgAlpBnIgSACIAEAnIASgCIAKgCIAHgEQACgDACgEQABgEgBgFQAAgFgCgDQgCgEgDgCQgDgCgEgBIgHgBIgEABgAkRDDQgGgBgEgDQgFgDgDgFQgDgFgBgGQAAgIADgGQADgGAHgFQAHgEALgDQALgDAOgBIADgBIgCgHQgBgEgDgCQgCgCgEgBQgDgBgFABQgIAAgFAFQgFAEgDAHIgBAAIgBAAQgHABgFgCQgEgDAAgGQgBgEACgEQACgEAGgEQAFgEAIgCQAIgDAJgBQALgBAIACQAIABAGAFQAGAEADAGQADAHABAKIAFA2QAAAAAAAAQAAAAgBABQAAAAgBAAQgBAAgBABIgGABQgGABgEgEQgEgDgCgHIgFAHIgHAGQgIAEgKABIgHABIgFgBgAjvCWQgPACgEACQgGACgDAEQgDADABAFQAAAFAEADQAEACAHAAIAJgDIAGgEQADgEABgDQABgFAAgEIgBgGgAi2C4QgEgDAAgGIgLhzQAAgCAEgBIAGgBQAFgBAEADQAEACACAFIADAKIAFA5IAWgiQAEgGADgBQAEgDADAAQAEAAAEABIAGAEIABACIgZAnIAkAlQAAACgDADQgGAEgFABQgEAAgDgCQgFgBgDgEIggggIADAeQAAAGgCAEQgDADgGAAIgCABIgCAAQgFAAgCgCgAg2CqQgEgDgBgIIgIhaQgBgIADgEQADgEAHgBIBCgGQAGgBAEADQADACAAAGIABABQAAAGgDADQgCADgHABIg0AFIACAYIAmgEQAGAAAEACQADACAAAGIAAAAQABAGgDADQgDADgGABIglAEIACAaIA1gGQAGAAAEADQADACABAFIAAABQAAAGgDAEQgDADgGAAIhCAHIgDAAQgFAAgDgDgAA5CXQgHgGgDgIQgEgIgBgKQgBgLADgIQACgKAFgHQAGgHAGgEQAIgEAKgBQAKgBAHADQAIADAFAHIgFgwQAAgBAFgCIAFgBQAGAAADACQAFACACAFIADALIAJBhQAAAGgCADQgDADgGABIgDAAQgGAAgDgCQgDgDgBgGIAAgDIgEAIIgHAGQgDADgFABIgJACIgFAAQgQAAgLgMgABZBYQgGAAgEADQgEACgDAEIgEAJQgBAFABAGQACASAOAFQAFACAFgBQAFAAADgCQAFgCACgDQADgEACgEQABgEgBgEIgBgSQgEgHgGgDQgEgDgGAAIgEABgACoCWQgDgCgBgGIgGhEQgBgGADgEQADgDAGgBIACAAQAGgBADADQAEADAAAHIAHBDQAAAGgCAEQgDADgGAAIgDABIgBAAQgFAAgDgDgADXCSQgDgDgBgGIgHhNQAAgBAEgCIAGgBQAHgBAEAEQAEADACAIQACgIAFgFQAGgFAIgBQAIgBAEAEQAFADABAIQAAAEgBAEIgEAFIgCABQgFgEgIABQgEABgEACQgDACgBAEQgDAEAAAFQgBAGABAHIACAcQABAGgDADQgCADgGABIgDAAIgBAAQgFAAgDgCgAElCKQgEgCAAgGIgHhEQAAgGACgEQADgDAGgBIADAAQAGgBADADQADADABAHIAGBDQABAGgDAEQgDADgFAAIgDABIgCAAQgEAAgDgDgAFUCGQgEgDAAgGIgLhzQAAgBAEgCIAGgBQAFAAAEACQAEACACAFIADALIAFA5IAWgjQAEgFADgCQAEgCADAAQAEgBAEABIAGAFIABACIgZAmIAkAlQAAACgDAEQgGAEgFAAQgEABgDgCQgFgCgDgEIggggIADAfQAAAGgCADQgDADgGABIgCAAIgCAAQgFAAgCgCgACfAwQgEgDgBgHQAAgGADgEQADgEAHAAQAHgBADADQAEADAAAHQABAHgDADQgDAEgGAAIgDAAQgFAAgDgCgAEbAkQgDgDgBgHQgBgGAEgEQADgEAGAAQAHgBAEADQADADABAHQABAHgDADQgDAEgHAAIgCAAQgFAAgEgCgAoGARQgDgCAAgGIgJhcQgBgIADgEQADgEAHgBIAggDQAxgEAEAoQABALgCAIQgCAHgGAGQgGAGgJADQgJAEgMABIgSACIACAZQABAGgDADQgDAEgGAAIgEABIgBAAQgFAAgDgDgAnlhRIgSACIAEAnIASgCIALgCIAGgEQADgDABgEQABgEAAgFQgBgFgCgDQgBgEgEgCQgDgCgEgBIgHgBIgEABgAmEAHQgIgCgHgFQgHgFgEgIQgEgIgBgKIAAgCQAAgDABgCQABgBAAAAQAAAAABgBQAAAAABAAQABAAAAAAIA/gGIgEgJIgGgHQgDgCgFgBQgFgBgFABQgFAAgGAEQgHAEgHAIQgDAAgEgCQgGgDgBgGQAAgIAJgHQAGgEAHgCQAHgDAJgBQAWgCAPAMQAHAGAFAIQADAIABALQACAVgMAPQgGAGgIAEQgIADgLABIgGAAIgMgBgAmKgbQABAFACAEQABAEAEACQACADAFABQAEABAEgBIAJgCIAHgFQACgDACgEIACgJgAkyAAQgDgDgBgGIgHhOQAAgBAEgBIAGgCQAHAAAEADQAEAEACAHQACgIAFgFQAGgEAIgBQAIgBAEAEQAFADABAIQAAAEgBADIgEAGIgCABQgFgEgIABQgEAAgEACQgDADgBADQgDAEAAAGQgBAFABAIIACAbQABAGgDAEQgCACgGAAIgDAAIgBAAQgFAAgDAAgAjigSQgHgGgDgIQgEgIgBgKQgBgLADgIQACgKAFgHQAFgHAHgEQAIgEAKgBQAKgBAHADQAIADAFAHIgFgwQAAgBAFgCIAFgBQAGAAADACQAFACACAFIADALIAJBhQAAAGgCADQgDADgGABIgDAAQgGAAgDgCQgDgDgBgGIAAgDIgEAIIgHAGQgDADgFABIgJACIgFAAQgQAAgLgMgAjChRQgGAAgEADQgEACgDAEIgEAJQgBAFABAGQACASAOAFQAFACAFgBQAFAAADgCQAFgCACgDQADgEACgEQABgEgBgEIgBgSQgEgHgGgDQgEgDgGAAIgEABgAhfgSQgJgDgHgGQgHgFgEgIQgDgIgBgKIAAgCQgBgEACgBQAAgBABgBQAAAAAAAAQABgBABAAQAAAAABAAIA/gGIgEgJIgHgGQgDgCgFgBQgEgBgGAAQgEABgGADQgHAEgHAIQgEAAgEgCQgFgDgBgGQgBgIAKgHQAFgEAHgCQAIgDAJAAQAWgDAOAMQAIAGAEAIQAEAIABALQACAVgMAPQgGAIgIAEQgJAEgKABIgGAAIgMgBgAhlg2QAAAEACAEQACAEADACQADADAEABQAEABAFAAIAJgCIAGgGQADgCABgFIACgIgAgNgcQgDgDgBgGIgLhzQAAgBAFgCIAFgBQAGAAADACQAFACACAFIACALIAIBhQAAAGgCADQgDADgEABIgDAAIgBAAQgFAAgDgCgAA1ggQgJgDgHgGQgHgFgEgIQgDgIgBgKIAAgCQgBgEACgBQAAgBABgBQAAAAAAAAQABgBABAAQAAAAABAAIA/gGIgEgJIgHgGQgDgCgFgBQgEgBgGAAQgEABgGADQgHAEgHAIQgEAAgEgCQgFgDgBgGQgBgIAKgHQAFgEAHgCQAIgDAJAAQAWgDAOAMQAIAGAEAIQAEAIABALQACAVgMAPQgGAIgIAEQgJAEgKABIgGAAIgMgBgAAvhEQAAAEACAEQACAEADACQADADAEABQAEABAFAAIAJgCIAGgGQADgCABgFIACgIgACHgqQgEgDAAgGIgIhOQAAgBAFgBIAFgCQAHAAAEADQAFAEACAHQABgIAGgFQAGgEAHgBQAJgBAEAEQAFADAAAIQABAEgBADIgFAGIgCABQgFgEgHABQgFAAgDACQgDADgCADQgCAEgBAGQgBAFABAIIADAbQAAAGgCAEQgDADgGAAIgCABIgCAAQgFAAgCgCgADVgyQgEgCAAgGIgHhEQAAgGACgEQADgDAGgBIADAAQAGgBADADQADADABAHIAGBDQABAGgDAEQgDADgFAAIgDABIgCAAQgEAAgDgDgAEEg2QgEgDAAgGIgIhNQAAgBAFgCIAFgBQAHgBAEAEQAEADADAHQAEgIAHgFQAHgFAKAAQAIgBAHACQAHACAFAFQAEAFADAGQACAGABAJIAEAsQABAGgDADQgDADgFABIgDAAQgGABgDgDQgEgDAAgGIgEgoQgCgTgQABQgIABgFAEQgEADgDAGIAFAwQAAAGgCADQgDADgGABIgCAAIgCAAQgFAAgCgCgAFwhAQgDgDgBgGIgGhDQgBgHADgEQADgDAGAAIACgBQAGAAADADQAEADAAAGIAHBEQAAAGgCADQgDADgGABIgDAAIgBAAQgFAAgDgCgAGahEQgDgCAAgFIAAgBQgBgGAGgHIAkgzIgkADQgKABgBgJIAAgCQgBgJAKgBIA7gGQAFAAADABQADADAAAEIAAACQABAEgCACIgpA6IAngDQAKgBABAJIAAACQABAEgCADQgDADgFAAIg9AGIgCAAQgDAAgDgCgAH8hOQgDgCgBgGIgGhEQgBgGADgEQADgDAGgBIACAAQAGgBADADQAEADAAAHIAHBDQAAAGgCAEQgDADgGAAIgDABIgBAAQgFAAgDgDgADLiYQgDgDgBgHQgBgGAEgEQADgEAGAAQAHgBAEADQADADABAHQABAHgDADQgDAEgHAAIgCAAQgFAAgEgCgAFninQgEgCgBgHQAAgHADgEQADgDAHgBQAHgBADAEQAEADAAAGQABAHgDAEQgDADgGABIgDAAQgFAAgDgDgAHzi0QgEgDgBgHQAAgGADgEQADgEAHAAQAHgBADADQAEADAAAHQABAHgDADQgDAEgGAAIgDAAQgFAAgDgCg");
	this.shape.setTransform(82.4,73.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},32).wait(1605));

	// 9
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ArIBoQgCgCgBgFIgGhMQAAgGACgEQADgDAGgBIAZgCQApgDACAhQABAIgCAHQgCAGgFAFQgEAEgIADQgHADgKAAIgPACIACAWQAAAFgCADQgCADgFAAIgDAAIgCAAQgEAAgCgCgAq6AYIACAgIAPgCQAFAAADgBQAEgBACgDQACgCABgDIAAgHQAAgEgBgDQgBgDgDgCIgGgCIgJgBgApZBgQgJgCgFgFQgGgFgEgIQgDgHgBgLIgEgwQAAgFACgDQADgCAFAAIACAAQAFAAADABQADACAAAFIAEAwIACAKQACAFACACQADADAEABQAEABAFAAQAFgBADgCQAEgBACgEQADgCAAgFQABgFAAgGIgEgvQAAgFACgBQACgCAFgBIADAAQAFAAACACQADACAAADIAEAwQADArgqADIgFAAIgNgBgAoJBXQgDgCgBgHIgGhMQAAgDABgDQADgDAFAAIADgBQAFAAACACQADADAAADIAGBFIAlgDQAFAAADACQADACAAAEIAAABQAAAFgCADQgCACgGABIgvAEIgCAAQgFAAgCgDgAmpBTIgNgEIgIgFQgCgEAAgEQgBgFAGgGIACAAQAHAFAIADIAHACIAJABQAJgBAEgDQAEgEAAgGQAAgDgEgDQgEgDgHgBIgNgCQgHgBgHgDIgGgDQgDgCgBgDQgDgDAAgDQgCgEAAgEQAAgFABgEQAAgFADgCIAHgGQADgEAGgCQAHgDAJAAQAIgBAHABQAHABAFACQAFADACACQACADAAAEQABACgCACIgFAFIgBABIgBAAQgFgGgHgCQgHgBgIABQgIAAgEACQgEADAAAGQABAEADACQADACAHABIARADQAJACAGAEQAGAEACAFQADAEABAHQABAQgLAKIgMAGQgHACgJAAIgJABIgHgBgAlMBKQgJgCgFgFQgGgFgEgIQgDgHgBgLIgEguQAAgFACgDQADgCAFgBIACAAQAFAAADACQADACAAAFIAEAuIACAKQACAFACACQADADAEABQAEABAFAAQAFgBADgCQAEgBACgEQADgCAAgFQABgFAAgGIgEgtQAAgFACgDQACgCAFgBIADAAQAFAAACACQADACAAAFIAEAuQADArgqADIgFAAIgNgBgAhnBKQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBIABgBIAEgNQgJgCgIgDQgHgEgGgHQgFgGgDgIQgDgIgBgJIAAgKIACgIIAEgJIAFgJIAIgGQADgEAFgCQAEgCAFgBIALgCQAJgBAHABQAHACAGADIAIAHQADADAAAEQAAAEgCADQgCADgFACIgDABIAAAAIgFgGIgGgEIgHgCIgIAAQgGABgFACQgFADgEAFQgDAFgCAFQgBAEAAAGQABAHACAFQADAGAFAEQAEAEAFABQAFACAHAAIAIgCQAEgBACgCQAEgCACgDIADgHIABgBQADAAAEACQAGADAAAGQABADgCAEIgFAHIgKAHQgFADgIACIgOARQgBAAAAAAQgBABAAAAQgBAAgBAAQAAABgBAAgAj+BCQgEgCAAgFIAAgBQgBgHAHgJIApg3IgqADQgFABgCgCQgDgCgBgFIAAgBQAAgEACgDQADgCAEgBIA6gEQAGgBADACQAEADAAAEIABACIgCAHIgFAIIgpA3IAtgDQAFgBACADQADABAAAFIABABQAAAEgCADQgDACgFABIg8AFIgCAAQgEAAgDgCgAgmAzIgFgDIgBgCIAahYQABgEAEgCIAJgCIAHAAQAEACACADIAqBSIAAABQAAABgEADQgDADgFAAQgEABgEgDQgDgCgDgFIgHgPIgiADIgFAQQgBAFgDADQgDADgEAAIgGAAgAgNAGIAZgCIgOgggABaAmQgDgCgBgFIgFhEIgXACQgFABgCgCQgDgCgBgFIAAgBQAAgEACgDQADgDAFAAIBDgGQAFAAACACQADACAAAFIAAAAQABAFgCADQgDACgFABIgWACIAGBDQAAAFgCADQgCACgFABIgEAAIgBAAQgEAAgBgCgACcAfQgDgDgBgFIgGhIQAAgFACgEQADgEAGAAIAkgCIALABIAJADIAJAFIAGAHIAGAIIADAJIACALIAAALIgCAJIgEAIIgGAHIgHAHIgJAFQgEACgGABIgjAEQgGAAgEgDgAC3gtIgOABIAFA6IANgBQAIgBAGgCQAFgCAEgFQAEgDABgFQACgGgBgHQAAgHgDgFQgCgGgFgDQgEgEgGgCIgGAAIgHAAgAEFAYQgDgCgBgFIgGhOQAAgFACgCQACgDAFAAIADgBQAFAAACACQADADAAAFIAHBNQAAAFgCADQgCACgFABIgDAAIgCAAQgDAAgCgCgAEuAUQgDgCAAgGIgGhJQgBgGACgDQADgEAGAAIAdgDQAKgBAHACQAIABAFAEQAFADADAGQADAFABAIQAAAGgBAFQgBAFgDAEQgDAEgFADQgFADgFABIAcAbQAAACgDADQgEAEgGAAQgFAAgDgCQgDgBgEgFIgYgXIgIABIACAYQAAAFgCACQgCADgFAAIgDABIgBAAQgEAAgCgDgAFMg7IgRABIADAeIARgCIAHgBIAGgDQACgCAAgDQACgDgBgEQAAgEgCgCQgBgDgDgBQgCgCgDgBIgGAAIgCAAgAGNANQgDgDgBgFIgGhNQAAgFACgDQACgCAFgBIADAAQAFgBACADQADACAAAFIAHBOQAAAFgCACQgCADgFAAIgDABIgCAAQgDAAgCgCgAG2AJQgDgDAAgGIgHhLQAAgFACgDQACgCAFgBIADAAQAFAAADACQADACAAAFIAGBGIAkgDQAGgBACACQADACAAAFIAAABQABACgCADQgDADgFAAIgwAEIgCAAQgEAAgDgCgAIHADQgCgCgBgDIgGhOQAAgGACgDQADgDAFgBIAGAAQAFgBADACQACABADAFIAXAtIARgxQABgEACgCQADgCAEgBIAGAAQAGgBADADQADACABAGIAGBOQAAAFgBADQgDADgEAAIgDAAQgFAAgCgBQgDgDAAgFIgFg6IgNApQgCAEgCACQgCABgFABQgGAAgCgBIgEgGIgTglIAEA6QABAEgCABQgCADgFABIgDAAIgCAAQgDAAgCgCgAJ3gCIgFgDIgBgCIAbhaQABgEADgCIAKgCIAIAAQAFACACADIApBUIAAABQAAABgDADQgEADgEAAQgFABgDgDQgEgCgCgFIgHgPIgkADIgFAQQgCAFgCADQgDADgFAAIgGAAgAKRgvIAbgCIgRgig");
	this.shape_1.setTransform(86.4,143.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},42).wait(1595));

	// 6
	this.instance = new lib.Symbol28("synched",0);
	this.instance.setTransform(85.6,142.2,1,1,0,0,0,85.6,27.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({startPosition:0,_off:false},0).wait(1611));

	// 4
	this.instance_1 = new lib.Symbol33("synched",0);
	this.instance_1.setTransform(85.6,89.8,1,1,0,0,0,69.7,89.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(18).to({startPosition:0,_off:false},0).wait(1619));

	// 3
	this.instance_2 = new lib.Symbol34("synched",0);
	this.instance_2.setTransform(80.4,161.4,1,1,0,0,0,57.6,33);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({startPosition:0,_off:false},0).wait(1627));

	// 2
	this.instance_3 = new lib.Symbol35("synched",0);
	this.instance_3.setTransform(83.1,188.8,1,1,0,0,0,53.6,30.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({startPosition:0,_off:false},0).to({_off:true},1583).wait(53));

	// 7
	this.instance_4 = new lib.Symbol29("synched",0);
	this.instance_4.setTransform(157.6,155,1,1,0,0,0,13.6,13.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(43).to({startPosition:0,_off:false},0).to({_off:true},1593).wait(1));

	// 1
	this.instance_5 = new lib.Symbol36("synched",0);
	this.instance_5.setTransform(63.6,217.6,1,1,0,0,0,26.9,21.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true},1584).wait(53));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(36.7,196.3,53.7,42.7);


(lib.Symbol25copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 11
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmTEoQgGgBgFgDQgGgDgEgEIgJgJIgGgKQgDgFgCgGIgCgNIAAgOQAAgGACgGIAFgLQACgGAEgFIAJgIQAFgEAFgCIAMgFIANgCIANAAQAGAAAGACIALAEQAFADAFAEIAIAJIAHAKIAEAMIADAMQABALgDAKQgCAKgFAIIAQAPQAAACgEAEQgFAEgGABQgEAAgEgCQgFgCgEgEQgHAFgIADQgIADgJABIgNABQgGgBgGgCgAmDDFQgIABgGADQgHAEgEAGQgEAGgCAHQgBAHABAIIACALIAFAKIAHAHQAFAEAFACQAHABAHAAQAIgBAIgEIgNgLQgFgEAAgGQgBgDADgEIABgBQACgCAEgBQAFAAAGAFIAMAKQACgEAAgFIAAgLQgBgMgGgJQgDgEgFgDQgEgEgFgCQgFgBgGAAIgEAAgAkTEdQgKgCgHgGQgOgMgDgWQgBgKADgJQADgJAGgIQAGgHAJgDQAIgFALgBQAIgBAHACQAHABAGADQAGADAFAFQAFAFADAGQAEAJACALQAAAHgBAHQgBAHgDAGQgDAGgGAFQgEAFgHADQgJAFgLABIgGAAQgHAAgGgCgAkHDUQgFAAgEADQgFACgDAEQgDAFgBAEQgCAGAAAFIADALQACAEAEAEQAEAEAFABQAFABAGAAQAGgBAEgCQAEgCADgFQADgEACgFQABgFAAgFQgBgGgDgFQgBgFgEgDQgEgEgFgBIgIgBIgDAAgAi9EUQgEgDAAgGIgIhOQAAgBAFgBIAFgCQAHAAAEADQAFAEACAHQABgIAGgFQAFgEAIgBQAJgBAEAEQAFADAAAIQABAEgBADIgFAGIgCABQgFgEgHABQgFAAgDACQgDADgCADQgCAEgBAGQgBAFABAIIADAbQAAAGgCAEQgDADgGAAIgCABIgCAAQgFAAgCgCgAhyEOQgEgBgDgDIgBgCIAYgpIgfgjQAAgCAEgDQAEgEAGgBQAFAAAEABQAEACACAFIASAXIANgaQADgGAEgCQADgCAEgBQAEAAAEABQADABAEADIABACIgZApIAgAkQAAACgEADQgFAEgGAAQgEABgEgCQgEgCgDgFIgSgWIgNAZQgFAKgIABIgIgBgAESENIgGgDIgBgCIAMgkQgHAAgCgFIgnhGQAAgBAEgEQAFgDAFgBQAFAAAEADQAEADADAGIAZAyIAMg1QACgHADgEQAEgEAFAAIAHABQADAAADADIABACIgfBwQgBAGgEAEQgEADgEABIgDAAIgFgBgAgPEDQgEgDAAgGIgIhNQAAgBAFgCIAFgBQAHgBAEADQAEAEACAHQADgIAGgFQAHgEAJgBIAKAAQAFAAAEADQAEACACADIAGAIIAFgJIAGgHQAEgDAFgBIAJgCQAIgBAGACQAGACAFAEQAFAEACAHQADAGABAJIAEAuQABAGgDADQgDADgGABIgCAAQgGAAgDgCQgEgDAAgGIgEgpQgBgJgEgFQgFgEgIABQgFABgFACQgEAEgDAGIAFAwQAAAGgCADQgDAEgGAAIgCABQgGAAgDgDQgEgCAAgGIgEgpQgCgTgPACQgGAAgFADQgEAEgDAFIAFAxQAAAGgCADQgDADgEABIgCAAIgCAAQgFAAgCgCgACfD2QgFgBgFgEQgFgCgCgFQgDgFgBgGQgBgIAEgHQADgFAHgFQAGgFALgDQALgCAPgCIADAAIgCgIQgCgDgCgCQgCgCgEgBQgEgBgFAAQgIABgFAFQgFADgDAHIgBAAIAAABQgIABgEgDQgEgCgBgGQAAgFACgEQACgEAFgEQAFgEAIgCQAIgDAKAAQAKgBAIABQAIACAGAEQAGAEADAHQAEAHABAJIAFA2QAAABgBAAQAAAAAAAAQgBABgBAAQgBAAgBAAIgFACQgHABgEgEQgEgDgBgHIgGAHIgHAGQgHAEgLABIgGAAIgGAAgADBDJQgOACgFACQgGACgCADQgDADAAAFQABAGAEACQADADAHgBIAJgCIAHgFQADgDABgEQABgEgBgFIAAgFgAFeDgQgEgCAAgGIgHhEQAAgGACgEQADgDAGgBIADAAQAGgBADADQADADABAHIAGBDQABAGgDAEQgDADgFAAIgDABIgCAAQgFAAgCgDgAGNDcQgEgDAAgGIgIhNQAAgBAFgCIAFgBQAHgBAEAEQAEADADAHQAEgIAHgFQAHgFAKAAQAIgBAHACQAHACAFAFQAEAFADAGQACAGABAJIAEAsQABAGgDADQgDADgFABIgDAAQgGABgDgDQgEgDAAgGIgEgoQgCgTgQABQgIABgFAEQgEADgDAGIAFAwQAAAGgCADQgDADgGABIgCAAIgCAAQgFAAgCgCgAoeBvQgDgDAAgGIgJhhQgBgFACgDQADgDAGgBIAEAAQAGgBADADQADADABAEIAEArIAjgwQAEgGADgCQADgCAEAAQAFgBAEACQAEABADAEIABADIglAzIAwAvIAAABQAAACgEAEQgFAFgHAAQgEABgEgBIgHgHIgtgsIAEAtQABAGgDADQgDADgGABIgEAAIgBAAQgFAAgDgCgAmrBkQgEgDAAgGIgHhDQAAgHACgEQADgDAGAAIADgBQAGAAADADQADADABAGIAGBEQABAGgDADQgDADgFABIgDAAIgCAAQgFAAgCgCgAl8BgQgEgDAAgGIgIhOQAAgBAFgBIAFgCQAHAAAEADQAFAEACAHQABgIAGgFQAFgEAIgBQAJgBAEAEQAFADAAAIQABAEgBADIgFAGIgCABQgFgEgHABQgFAAgDACQgDADgCADQgCAEgBAGQgBAFABAIIADAbQAAAGgCAEQgDADgGAAIgCABIgCAAQgFAAgCgCgAkvBYQgDgCgBgGIgLhxQAAgCAFgBIAFgBQAGgBADACQAFADACAFIADAKIAJBfQAAAGgCAEQgDADgGAAIgDABIgBAAQgFAAgDgDgAjrBUQgJgCgHgGQgHgGgEgIQgDgIgBgKIAAgCQgBgDACgCQAAAAAAgBQABAAAAgBQABAAAAAAQABAAABAAIA/gGIgEgJIgHgHQgDgCgFgBQgEgBgGABQgEAAgGAEQgHAEgHAIQgEAAgEgCQgFgDgBgGQgBgIAKgHQAFgCAHgCQAIgDAJgBQAWgCAOAKQAIAGAEAIQAEAIABALQACAVgMAPQgGAHgIAFQgJADgKABIgHABIgLgCgAjxAwQAAAFACAEQACAEADACQADADAEABQAEABAFgBIAJgCIAGgFQADgDABgEIACgJgAiZBLQgEgDAAgGIgIhMQAAgBAFgBIAFgCQAHAAAEADQAEAEADAHQAEgJAHgEQAHgFAKgBQAIgBAHADQAHACAFAFQAEAEADAGQACAFABAIIAEAsQABAGgDAEQgDADgFAAIgDABQgGAAgDgCQgEgDAAgGIgEgoQgCgUgQACQgIABgFADQgEAEgDAGIAFAvQAAAGgCAEQgDADgGAAIgCABIgCAAQgFAAgCgCgAgrA2QgGgGgEgIQgDgIgBgKQgBgLACgIQACgIAFgHQAGgHAHgEQAIgEAJgBQAKgBAHADQAGADAFAHIgEgwQAAgBAEgCIAGgBQAFAAAEACQAEACADAFIACALIAJBfQABAGgDADQgDADgFABIgDAAQgGAAgDgCQgEgDAAgGIgBgDIgEAIIgGAGQgEADgCABIgKACIgFAAQgQAAgLgMgAgLgHQgFAAgEADQgFACgCACIgEAJQgBAFABAGQABASAPAFQAFACAEgBQAFAAACgCQAEgCADgDQADgEABgEQABgEAAgEIgCgSQgDgFgGgDQgDgCgGAAIgEAAgAGOA8IgFgEIgCgCIAMgjQgGgBgDgEIgmhEQAAgCAEgDQAFgEAFAAQAFgBADADQAEADADAGIAZAyIANg1QABgHAEgDQADgEAFgBIAHABQAEABADADIABABIggBuQgBAHgEADQgDAEgFAAIgCABIgGgBgABDA1QgEgCAAgGIgHhCQAAgGACgEQADgDAGgBIADAAQAGgBADADQADADABAHIAGBBQABAGgDAEQgDADgFAAIgDABIgCAAQgFAAgCgDgACTAsQgFgEAAgGIgJhZQAAgGADgFQADgFAHAAIAtgDIANABIAMAEQAFADAFAEIAIAHQAEAFADAFIAEALIADANQAAAHgBAHIgCAKIgEALIgHAKIgJAIIgLAGIgMAEIgsAFIgBAAQgGAAgEgDgACygyIgRABIAHBIIARgCQAJgBAHgDQAHgDAFgFQAEgGACgEQACgIgBgJQgBgJgDgGQgEgHgFgEQgFgEgIgCIgJgBIgHABgAEVAaQgIgGgEgJQgEgIgBgJQgCgUAMgPQAHgIAIgEQAIgEAKgBQAKgBAIACQAJADAHAFQAHAGAEAIQAEAIABAKIAAACQAAAEgBACQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAgBAAIg+AGQABACACAEQADAEAEADQADACAFABQAFACAFgBQAFAAAGgEQAGgFAIgHQADAAAEABQAFADABAGQABAIgKAHQgFAEgHADQgHACgJABIgHABQgSAAgMgKgAEwgoIgIACIgHAFIgEAHQgCAEAAAGIAtgFQgBgFgCgDQgCgEgDgDIgHgDIgGgBIgDAAgAHuAPQgIgCgHgGQgHgGgEgGQgEgIgBgKIAAgCQAAgDABgCQABAAAAgBQAAAAABgBQAAAAABAAQABAAAAAAIA/gGIgEgJIgGgHQgDgCgFgBQgFgBgFABQgFAAgGAEQgHAEgHAIQgDAAgEgCQgGgDgBgGQAAgIAJgHQAGgEAHgCQAHgDAJgBQAWgCAPAMQAHAGAFAIQADAIABALQACAVgMANQgGAHgIAFQgIADgLABIgGABIgMgCgAHogTQABAFACAEQABAEAEACQACADAFABQAEAAAEAAIAJgCIAHgFQACgDACgEIACgJgAm1gBQgDgCgBgHQgBgHAEgEQADgDAGgBQAHgBAEAEQADADABAGQABAHgDAEQgDACgHAAIgDAAQgFAAgDgBgAA5gvQgDgDgBgHQgBgGAEgEQADgEAGAAQAHgBAEADQADADABAHQABAHgDADQgDAEgHAAIgDABQgFAAgDgDgAoChYQgDgCgBgGIgJhgQgBgHADgEQADgEAHgBIAIAAQAGgBADACQADACADAFIAeA3IATg7QACgGADgCQADgDAFgBIAHAAQAHgBAEADQAEADABAHIAJBgQAAAGgCAEQgCADgGAAIgEABQgGAAgCgCQgDgDgBgGIgHhIIgQAzQgBAFgDACQgCACgHABQgHAAgDgCQgCgBgCgFIgZguIAHBHQAAAGgCAEQgCADgGAAIgEABIgCAAQgEAAgCgDgAlxhtQgHgGgEgIQgEgIgBgLQgCgVAMgPQAGgHAIgEQAJgFAKgBQAKgBAIADQAJACAGAGQAHAGAEAHQAEAJABAKIAAACQABADgCACQAAABAAAAQgBAAAAABQgBAAgBAAQAAAAgBAAIg/AGQABAFADAEQACAEAEACQAEADAFABQAEABAFAAQAFgBAGgEQAHgEAHgIQADAAAEACQAGADABAGQAAAIgJAHQgFAEgIACQgHADgJABIgGAAQgSAAgNgKgAlViwIgJACIgGAFIgFAHQgBAEAAAFIAsgEQAAgFgDgEQgBgDgDgDIgHgEIgGAAIgDAAgAkOhuQgEgDAAgGIgLhzQAAgCAEgBIAGgBQAFgBAEADQAEACACAFIADAKIACAfQAFgIAHgFQAHgEAKgBQAKgBAIADQAIADAGAHQAGAGAEAHQAEAJAAAKQABALgCAIQgCAJgFAHQgGAIgHAEQgIAEgJABQgUACgKgPIAAABQAAAGgCAEQgDADgGAAIgCABIgCAAQgFAAgCgCgAjni4QgIAAgGAFQgFAEgDAIIACARQAAAEADAEQACAEADADIAIAEQAEABAFgBQAGAAAEgDIAHgGQACgEABgFQACgFgBgFIgCgLQgCgFgEgDQgDgEgFgBIgHgBIgDAAgAiZiBQgIgGgEgJQgEgIgBgLQgCgUAMgPQAHgIAIgEQAIgEAKgBQAKgBAIACQAJADAHAFQAHAGAEAIQAEAIABAKIAAACQAAAEgBACQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAgBAAIg+AGQABAEACAEQADAEAEADQADACAFABQAFACAFgBQAFAAAGgEQAGgFAIgHQADgBAEACQAFADABAGQABAIgKAHQgFAEgHADQgHACgJABIgHABQgSAAgMgKgAh+jFIgIACIgHAFIgEAHQgCAEAAAGIAtgFQgBgFgCgDQgCgEgDgDIgHgDIgGgBIgDAAgAg3iDQgDgCgBgGIgLhzQAAgCAFgBIAFgBQAGgBADACQAFADACAFIADAKIAJBhQAAAGgCAEQgDADgGAAIgDABIgBAAQgFAAgDgDgAgHiHQgEgDAAgGIgLhzQAAgBAEgCIAGgBQAFAAAEACQADACACAFIACALIAJBhQABAGgDADQgDADgFABIgDAAIAAAAQgFAAgCgCgAA6iLQgIgDgHgGQgHgFgEgIQgEgIgBgKIAAgCQAAgEABgBQAAgBABAAQAAgBABAAQAAAAABAAQABgBAAAAIA/gGIgEgJIgGgGQgDgCgFgBQgFgBgFAAQgFABgGADQgHAEgHAIQgDAAgEgCQgGgDgBgGQAAgIAJgHQAGgEAHgCQAHgDAJAAQAWgDAPAMQAHAGAFAIQADAIABALQACAVgMAPQgGAIgIAEQgIAEgLABIgGAAIgMgBgAA0ivQABAEACAEQABAEAEACQACADAFABQAEABAEAAIAJgCIAHgGQACgCACgFIACgIgACMiVQgDgDgBgGIgHhNQAAgBAEgCIAGgBQAHgBAEAEQAEADACAIQACgIAFgFQAGgFAIgBQAIgBAEAEQAFADABAIQAAAEgBAEIgEAFIgCABQgFgEgIABQgEABgEACQgDACgBAEQgDAEAAAFQgBAGABAHIACAcQABAGgDADQgCADgGABIgDAAIgCAAQgEAAgDgCgADaidQgDgCgBgGIgGhEQgBgGADgEQADgDAGgBIACAAQAGgBADADQAEADAAAHIAHBDQAAAGgCAEQgDADgGAAIgDABIgBAAQgFAAgDgDgAEJihQgDgDgBgGIgHhNQAAgBAEgCIAGgBQAGgBAEAEQAFADACAHQAEgIAHgFQAIgFAJAAQAJgBAGACQAHACAFAFQAEAFADAGQADAGABAJIAEAsQAAAGgCADQgDADgGABIgDAAQgGABgDgDQgDgDgBgGIgEgoQgBgTgRABQgHABgFAEQgFADgCAGIAEAwQABAGgDADQgCADgGABIgDAAIgCAAQgEAAgDgCgAF2irQgEgDAAgGIgHhDQAAgHACgEQADgDAGAAIADgBQAGAAADADQADADABAGIAGBEQABAGgDADQgDADgFABIgDAAIgCAAQgFAAgCgCgAGgivQgDgCgBgFIAAgBQAAgGAFgHIAkgzIgjADQgLABgBgJIAAgCQgBgJALgBIA7gGQAFAAACABQADADABAEIAAACQAAAEgBACIgpA6IAmgDQALgBABAJIAAACQAAAEgCADQgDADgFAAIg9AGIgBAAQgEAAgCgCgADRkDQgEgDgBgHQAAgGADgEQADgEAHAAQAHgBADADQAEADAAAHQABAHgDADQgDAEgGAAIgDABQgFAAgDgDgAFskSQgDgCgBgHQgBgHAEgEQADgDAGgBQAHgBAEAEQADADABAGQABAHgDAEQgDADgHABIgDAAQgFAAgDgDg");
	this.shape.setTransform(82.7,73.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},32).wait(1605));

	// 9
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AriBzQgDgDAAgGIgHhVQgBgHADgDQADgEAHgBIAcgCQAtgEADAlQABAKgCAHQgDAHgFAFQgFAFgIADQgJADgLABIgQABIACAZQAAAGgCADQgDADgFAAIgEABIgBAAQgFAAgCgCgArDAYIgQABIADAkIAQgBQAFgBAEgCIAGgDQADgDABgEQABgDAAgEIgCgIIgFgFQgCgCgFgBIgGAAIgDAAgAp/BrQgDgDAAgFIgGhGQAAAAABgBQAAAAAAAAQABgBAAAAQABAAABgBIAFgBQAGgBAEADQAEAEACAHQABgIAFgEQAFgEAHgBQAIgBAEADQAEAEABAHQAAAEgBADQgBADgDACIgCABQgEgEgHABIgHACIgFAFQgCAEAAAFQgBAFAAAHIACAZQABAFgCADQgDADgFAAIgCABIgCAAQgEAAgDgCgAolBlQgJgDgHgFQgNgLgBgUQgBgJACgIQADgJAGgGQAFgHAIgDQAIgEAKgBQAGAAAHABQAGABAGADQAGADAEAEIAHALQAEAIABAJQAAAHgBAGIgEAMQgDAGgEAEQgFAEgGADQgIAEgKABIgGAAIgLgBgAoZAiQgFABgEACQgEACgDAEQgDADgBAFQgCAFABAFQAAAFACAEQACAEAEAEQADADAFABQAEACAFgBQAFAAAEgDQAEgBADgEQADgEABgFQABgEAAgFIgCgJQgCgFgEgDIgHgFIgHgBIgDAAgAnPBcQgDgDgBgFIgEg2IgGABQgFAAgDgCQgDgBAAgFIAAgBQgBgEADgDQACgCAFgBIAGAAIAAgFQgBgHACgFQABgHAEgEQAHgHAOgCQAHAAAGACIAGAEIACAGQABAGgEADIgBABQgFgEgGABQgFAAgDADQgCADAAAFIAAAFIALgBQAFAAADABQADADAAAEIAAACQABAEgDACQgCACgFABIgKAAIAEA2QABAFgCAEQgDACgFABIgDAAIgCAAQgEAAgCgCgAmXBYQgDgDgBgGIgFg9QAAgGADgDQACgDAFAAIADgBQAFAAADADQADADAAAFIAFA+QABAFgCADQgDADgFAAIgDABIgBAAQgFAAgCgCgAlmBUQgIgCgDgDQgEgDgBgFQAAgGAFgDIACgCQAGAFAHADQAHACAIgBQAHAAADgDQAEgCAAgEQAAgDgEgCQgDgCgGgBIgMgBQgGAAgFgDQgHgCgDgFQgDgFgBgHQAAgEABgEIADgIIAGgGIAIgEQAGgCAIgBIALAAIAKABQAHACADADQAEAEAAAFQABADgCACIgEAFIgBAAIgBAAQgFgFgGgCQgGgCgIAAQgHABgDACQgDACAAAEQAAADADACIAKADIAMACQAHAAAFACQAGADAEAEQADAFABAHQAAAIgCAFQgDAGgFAEIgLAEIgOADQgPAAgGgCgAkWBNQgIgCgDgDQgEgDgBgFQAAgGAFgDIACgCQAGAFAHADQAHACAIgBQAHAAADgDQAEgCAAgEQAAgDgEgCQgDgCgGgBIgMgBQgGAAgFgDQgHgCgDgFQgDgFgBgHQAAgEABgEIADgIIAGgGIAIgCQAGgCAIgBIALAAIAKABQAHACADACQAEADAAAFQABADgCACIgEAFIgBAAIgBAAQgFgFgGgCQgGgCgIAAQgHABgDACQgDACAAAEQAAADADACIAKADIAMACQAHAAAFACQAGADAEAEQADAFABAHQAAAIgCAFQgDAGgFAEIgLAEIgOADQgPAAgGgCgAi5BHQgIgDgHgFQgNgLgCgUQAAgJACgIQACgJAGgGQAGgFAIgDQAHgEAKgBQAHAAAGABQAHABAFADQAGADAFAEIAHAJQAEAIAAAJQABAHgBAGIgEAMQgDAGgFAEQgFAEgFADQgIAEgKABIgHAAIgLgBgAitAEQgFABgEACQgEACgDAEQgDADgBAFQgBAFAAAFQABAFACAEQACAEADAEQAEADAEABQAEACAFgBQAFAAAFgDQAEgBACgEQAEgEABgFQABgEgBgFIgCgJQgCgFgEgDIgHgFIgGgBIgEAAgAhrA/QgDgDAAgFIgGhEQAAAAABgBQAAAAAAAAQABgBAAAAQABAAABgBIAFgBQAGgBAEADQAEAEACAGQAEgHAGgEQAHgFAIgBQAIAAAGACQAGACAFAEQAEAFACAGQACADABAIIADAoQAAAFgCAEQgCACgGABIgCAAQgGAAgCgCQgEgDAAgFIgDgkQgCgQgPABQgGABgEABQgFADgCAGIADArQABAFgCADQgDADgFAAIgCABIgCAAQgEAAgDgCgAAAA4QgEgBgEgCQgEgDgCgEQgDgFgBgGQAAgHADgFQADgGAGgEQAGgEAIgDIAXgDIADAAIgBgFQgCgEgCgBIgGgDQgDgBgEABQgHAAgFAEQgEAEgCAEIgBAAQgHABgDgCQgEgBAAgFQgBgEACgEIAGgHQAGgDAEgCQAHgDAJAAQAKgBAHACQAIABAFAEQAFAEADAGQADAGABAGIAEAxQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAgBABIgFABQgGAAgEgDQgEgDgBgGIgFAGIgGAFQgHAEgKABIgDAAIgHgBgAAfAQQgNACgFACQgFACgCADQgDACAAAFQABAFADACQAEACAGAAQAEAAAEgCIAGgEQADgDABgEIABgIIgBgEgABSAvQgDgDgBgFIgIhmQAAgBAAAAQAAAAABgBQAAAAABAAQABAAABAAIAFgCQAFAAADACQAEACACAFQACAEAAAFIAHBWQABAGgCADQgDACgFABIgDAAIgBAAQgFAAgCgCgACtAqQgFgBgEgEQgEgDgCgFQgCgFAAgHIgDgkIgEAAQgFABgDgCQgDgCAAgEIAAgBQgBgFADgDQACgCAFAAIAEgBIgBgKQAAgGACgDQADgDAFAAIACgBQAFAAADADQADACABAGIAAAKIAOgBQAFAAADACQADACAAAEIAAACQABAEgDACQgCACgFABIgOABIACAiQABAMAJgBQAHgBADgGIABAAIADACQADADAAAEQABAEgCADIgFAGQgHADgIABIgEAAIgHgBgADvAkQgIgDgGgFQgGgFgEgHQgDgIAAgIIgBAAIABgFQABgBAAAAQAAAAABAAQAAgBABAAQABAAAAAAIA5gFQgBgEgCgEIgGgGIgHgDIgJAAQgEAAgGADQgGAEgHAHQgDAAgDgCQgGgDAAgGQgBgHAJgGQAFgDAGgCQAHgCAIgBQAUgCANALQAHAFAEAIQAEAHAAAKQACARgMANQgFAHgHAEQgIAEgJAAIgFABQgGAAgGgCgADqADQAAAEACAEQACADADADIAGADIAIABQAEAAADgCIAHgFIAEgGIABgIgAE5AcQgDgCAAgGIgGhEQAAAAABAAQAAgBAAAAQABAAAAgBQABAAABAAIAFgCQAGAAAEADQADADACAHQAEgIAHgEQAGgEAHgBQAGAAAEABQAEAAAEACQADACADADIAEAHIAFgIIAGgGIAHgDQAEgCAFAAQAHgBAGACQAGACAEADQAEAEACAGIADAOIADAnQABAGgCADQgDADgFAAIgCAAQgGABgDgDQgDgCAAgGIgDgjQgBgIgEgEQgEgEgHAAQgFABgEADQgEACgDAGIAEAqQAAAFgCADQgCADgGAAIgCABQgGAAgCgCQgDgDgBgFIgDgjQgBgRgPABQgFAAgDADQgFADgCAGIADApQABAGgCADQgDACgFABIgCAAIgCAAQgEAAgDgCgAHQAQQgEgDAAgGIgFg7QgBgGADgDQACgDAGAAIACgBQAFAAAEADQACADABAFIAFA8QAAAFgCADQgDADgFAAIgCABIgCAAQgEAAgCgCgAH2ANQgDgDAAgEIgBgBQAAgFAFgFIAhguIggADQgKABAAgJIAAgBQgBgJAJAAIA1gFQAFAAADACQACABABAFIAAABQAAADgBADIgmA0IAjgDQAKgBAAAIIABAAQAAAEgCADQgDACgEABIg4AEQgEAAgCgBgAJPAGQgEgDAAgEIgJhoQAAAAABAAQAAgBAAAAQABAAABAAQAAgBABAAIAFgBQAFgBAEADQAEACABAEQACAFABAFIAHBYQAAADgCADQgDADgFAAIgCABIgCAAQgEAAgCgCgAJ6ACQgEgCAAgEIgFg+QgBgFADgDQACgDAGgBIACAAQAFgBAEADQACADABAGIAFA9QAAAGgCABQgDACgFABIgCAAIgCAAQgEAAgCgCgAKkAAQgDgCgBgGIgIhoQAAAAAAAAQAAgBABAAQAAAAABgBQABAAABAAIAFgCQAFAAADACQAEACACAFIACAJIAEA0IAVgfQADgFADgBQADgDADAAQAEAAADABQADABADADIABACIgXAjIAgAhQAAACgDADQgFAEgFAAQgDABgEgCIgHgFIgcgdIACAbQAAAGgCADQgCABgFAAIgDAAIgBAAQgFAAgCAAgAmegDQgEgDAAgGQgBgGADgDQADgEAGAAQAGgBADADQAEADAAAGQABAGgDADQgDADgGABIgCAAQgEAAgDgCgAHIhLQgDgDgBgGQAAgGACgDQADgEAGAAQAHgBADADQADADABAGQAAAGgDADQgCADgGABIgCAAQgFAAgDgCgAJyhZQgDgDgBgGQAAgGACgDQADgDAGgBQAHAAADADQADACABAGQAAAGgDAEQgCADgGAAIgCAAQgFAAgDgCg");
	this.shape_1.setTransform(86.5,142.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},42).wait(1595));

	// 6
	this.instance = new lib.Symbol28("synched",0);
	this.instance.setTransform(85.6,142.2,1,1,0,0,0,85.6,27.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({startPosition:0,_off:false},0).wait(1611));

	// 4
	this.instance_1 = new lib.Symbol33("synched",0);
	this.instance_1.setTransform(85.6,89.8,1,1,0,0,0,69.7,89.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(18).to({startPosition:0,_off:false},0).wait(1619));

	// 3
	this.instance_2 = new lib.Symbol34("synched",0);
	this.instance_2.setTransform(80.4,161.4,1,1,0,0,0,57.6,33);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({startPosition:0,_off:false},0).wait(1627));

	// 2
	this.instance_3 = new lib.Symbol35("synched",0);
	this.instance_3.setTransform(83.1,188.8,1,1,0,0,0,53.6,30.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({startPosition:0,_off:false},0).to({_off:true},1583).wait(53));

	// 7
	this.instance_4 = new lib.Symbol29("synched",0);
	this.instance_4.setTransform(157.6,155,1,1,0,0,0,13.6,13.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(43).to({startPosition:0,_off:false},0).to({_off:true},1593).wait(1));

	// 1
	this.instance_5 = new lib.Symbol36("synched",0);
	this.instance_5.setTransform(63.6,217.6,1,1,0,0,0,26.9,21.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true},1584).wait(53));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(36.7,196.3,53.7,42.7);


(lib.Symbol25_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 11
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjhHPQgDgDgBgIIgJhYQgBgHADgEQAEgEAHgBIAogEIASAAQAIABAFAEQAGADADAFQADAGABAHIgBAJIgDAHIgGAGIgJAFIAMADIAJAFIAFAIQACAFAAAGQABAKgCAHQgDAHgHAFQgGADgIADIgSADIgnAEIgCAAQgFAAgEgDgAi2GbIgYADIADAfIAYgDQALgBAEgDQADgCABgEQACgEgBgEQAAgEgCgCQgCgDgCgCIgIgCIgEAAIgFAAgAi9FtIgWACIADAeIAWgDQAKgBAEgEQAFgFgBgHQgBgHgFgDQgEgDgGAAIgFABgAhtHFQgDgDAAgGIgHhCQgBgGADgDQACgDAGgBIADAAQAGgBADADQADADABAGIAGBCQABAGgDADQgCADgGABIgDAAIgBAAQgFAAgDgCgAhEHBQgDgCAAgEIAAgCQgBgGAFgGIAjgzIgiAEQgLABgBgKIAAgBQgBgJALgBIA5gGQAFAAADACQACABABAFIAAABQAAAEgBADIgoA5IAmgEQAIgBABAJIAAABQABAFgCADQgDACgDABIg8AGIgBAAQgEAAgCgCgAAbGuQgHgGgDgIQgDgIgBgJQgBgLABgJQADgIAEgHQAGgHAHgEQAHgEAKgBQAJgBAIACQAHADAGAGIgFguQAAAAAAgBQAAAAABAAQAAgBABAAQABAAABAAIAFgCQAFAAAEACQAEACADAFQACAFAAAFIAKBfQAAAGgCADQgDADgGABIgCAAQgGABgDgDQgDgDgBgGIAAgDIgFAIIgGAGQgDADgFABIgJACIgFAAQgPAAgLgLgAA6FvIgKADQgEADgDAEQgCADgBAGQgBAFAAAFQACASAPAFQAEABAFAAQAEAAAEgCQAEgCADgEQADgDABgEQACgEgBgEIgBgRQgEgHgGgDQgFgDgHAAIgCAAgACbGsQgIgCgHgGQgGgFgEgIQgEgHgBgKIgBgCIABgGQACgBADAAIA9gHQgBgFgDgDQgCgEgEgDIgIgDQgEgBgFAAQgFABgGAEQgGAEgIAIQgDAAgEgCQgFgDgBgGQgBgIAJgHQAGgEAHgCIAQgDQAVgCAOALQAIAFAEAIQAEAJABAKQACAVgMAOQgGAIgIAEQgHAEgKABIgGAAQgHAAgGgCgACVGJQABAFACAEQABADAEADQACACAFABQADABAFAAQAFgBAEgCIAGgEIAEgHIACgJgADsGiQgEgCAAgGIgIhMQAAAAAAgBQAAAAABAAQAAAAABgBQABAAABAAIAGgBQAGgBAFADQAEADACAIQAEgJAHgEQAHgFAJgBQAIgBAHACQAHACAEAFQAFAEACAHQADAGABAJIAEAqQABAGgDADQgCAEgGAAIgDAAQgGABgDgDQgDgCAAgGIgEgnQgCgTgRABQgHABgEADQgFAEgCAGIAFAuQAAAGgCAEQgDADgGAAIgCABIgCAAQgFAAgCgDgAh2FhQgEgDAAgGQgBgHADgEQADgDAGgBQAHAAAEACQADAEABAGQABAHgDADQgDAEgHAAIgDAAQgEAAgDgCgAjdEPQgEgDAAgGIgEgkIgvg5QAAgCADgEQAFgFAIAAQADgBAEACQADACADAFIAdAlIAVgqQADgGADgCQADgDADAAQAHgBAGAEQAFADAAACIgjBBIAEAkQAAAGgCAEQgDADgGABIgEAAIgDAAQgDAAgCgCgAiBEIQgGgCgFgFQgEgFgDgGQgCgHgBgIIgEgrQgBgGACgDQADgDAFgBIADAAQAGgBADADQADADABAGIAEAnIACAIIADAGQADACADABQADABAFAAQAGgBAFgEQAEgDADgGIgFgvQgBgGADgDQACgDAGgBIADAAQAGgBADADQADADABAGIAHBLQAAABgEACIgFABQgHAAgEgDQgEgDgCgHQgEAJgHAEQgIAFgJABIgDAAQgHAAgFgBgAEhD/QgCgDgBgGIgEgmIgEAIIgGAGQgEADgEABIgJACQgTACgNgNQgGgGgDgIQgEgIgBgJQgBgLACgJQACgIAFgHQAFgHAIgEQAHgEAJgBQAKgBAIADQAHADAGAHQAAgHAEgEQADgEAHAAIAFAAQAEAAABABIALBuQAAAGgDAEQgCADgGABIgDAAIgCAAQgEAAgDgCgAD/CaIgKADQgEADgDAEQgDADgBAGQgBAFABAFQACASAOAFQAEABAFAAQAKgBAFgHQAHgHgBgJIgCgQQgEgHgFgDQgGgDgGAAIgCAAgAgmD8QgDgCgBgGIgHhMQAAAAAAgBQAAAAAAAAQABAAABgBQABAAABAAIAFgBQAHgBAEADQAEADACAHQAEgIAHgEQAGgFAHgBQAGgBAEACIAJACIAGAFQADADACAFIAFgJIAHgHIAHgDIAJgDQAIgBAGACQAHACAEAEQAFAEACAGQADAHABAJIAEAsQABAGgCADQgDADgGABIgDAAQgFAAgDgCQgEgDAAgGIgEgoQgBgJgFgEQgEgEgIABQgFAAgEAEQgFADgCAFIAFAvQAAAGgCAEQgDADgGABIgCAAQgGAAgDgCQgEgDAAgGIgEgnQgCgTgNABQgGABgEADQgEADgDAGIAFAvQABAGgDAEQgDADgFAAIgDABIgBAAQgFAAgDgDgACFDuQgFgBgFgCQgFgDgCgFQgDgFgBgGQAAgHADgHQADgFAHgFQAGgEALgDQAKgEAOgBIADAAIgBgIQgCgDgCgCQgDgCgDgBIgIAAQgIABgGAEQgFAEgCAHIgBAAIgBAAQgHABgEgCQgEgDgBgGQAAgEACgEQACgEAFgEQAFgEAHgCQAIgDAJgBQALgBAIACQAIACAGAEQAFAEAEAGQADAHABAJIAFA1QAAABgEABIgFABQgHABgEgDQgEgDgCgHIgFAHIgGAFQgIAFgKABIgEAAIgIgBgACmDDQgOACgFACQgFACgDADQgDADABAFQAAAFAEACQAEADAHgBIAIgCQAEgCADgDQACgCACgFQABgDgBgFIAAgFgAlGBYQgDgDAAgGIgJhRIgbACQgGAAgDgBQgDgDgBgGIAAAAQAAgGACgDQADgDAGAAIBQgIQAGgBADACQAEADABAGIAAAAQAAAGgDADQgDADgGABIgaACIAIBRQABAGgDAEQgDADgFABIgEAAIgDAAQgEAAgCgCgAjkBQQgIgCgHgGQgGgFgEgIQgEgIgBgKIgBgBIABgGQACgCADAAIA9gGQgBgFgDgEQgCgEgEgCIgIgDQgEgCgFABQgFAAgGAFQgGAEgIAHQgDAAgEgCQgFgDgBgGQgBgHAJgFQAGgEAHgDIAQgDQAVgCAOALQAIAEAEAIQAEAIABALQACAUgMAPQgGAHgIAEQgHAEgKABIgGAAQgHAAgGgBgAjqAtQABAEACAEQABAEAEACQACADAFABQADABAFgBQAFAAAEgCIAGgFIAEgHIACgJgAiTBGQgEgDAAgGIgIhJQAAgBAAAAQAAAAABgBQAAAAABAAQABgBABAAIAGgBQAGAAAFADQAEADACAIQACgJAFgEQAFgFAIgBQAIgBAFAEQAEADABAHQAAAFgBADQgBACgDACIgCABQgFgEgHAAQgEABgEACQgDADgCADQgCAEAAAGIAAAMIADAbQAAAGgCADQgDADgGABIgCAAIgCAAQgFAAgCgCgAgzA/QgFgBgEgDQgFgEgCgFQgCgGgBgIIgEgnIgEABQgGAAgDgBQgDgCAAgFIAAgCQgBgEADgDQACgCAGgBIAEAAIgBgMQgBgGADgDQADgEAGAAIACAAQAFgBADADQAEADAAAGIABALIAQgBQAFgBADACQADACAAAFIAAABQABAFgDADQgCACgGAAIgPACIAEAkQABANAJgBQAHgBAEgGIABAAQAAAAABAAQAAAAAAAAQABAAABABQAAAAABABQACADABAEQAAAEgBAEIgGAGQgHAEgIABIgEAAIgJgBgAATA3QgIgCgHgGQgEgFgEgIQgEgHgBgKIgBgCIABgGQACgBADAAIA7gHQgBgDgDgDQgCgEgEgDIgIgDQgEgBgFAAQgFABgGAEQgGAEgIAHQgDAAgCgBQgFgDgBgGQgBgIAJgHQAEgEAHgCIAQgDQAVgCAOALQAIAFAEAIQAEAJABAIQACAVgMAOQgGAIgIAEQgHAEgKABIgGAAQgHAAgGgCgAANAUQABAFACAEQABADAEADQACACAFABQADABAFAAQAFgBAEgCIAGgEIAEgHIACgJgABjAtQgDgCgBgGIgHhKQAAAAAAgBQAAAAAAAAQABAAABgBQABAAABAAIAFgBQAHgBAEADQAEADACAHQAEgIAHgEQAGgFAJgBQAGgBAEACIAJACIAGAFQADADACAFIAFgJIAHgHIAHgDIAJgDQAIgBAGACQAHACAEAEQAFAEACAGQADAHABAJIAEAqQABAGgCADQgDADgGABIgDAAQgFAAgDgCQgEgDAAgGIgEgmQgBgJgFgEQgEgEgIABQgFAAgEAEQgFADgCAFIAFAtQAAAGgCAEQgDADgGABIgCAAQgGAAgDgCQgEgDAAgGIgEglQgCgTgPABQgGABgEADQgEADgDAGIAFAtQABAGgDAEQgDADgFAAIgDABIgBAAQgFAAgDgDgAEFAdQgDgDAAgGIgHhAQgBgGADgDQACgDAGgBIADAAQAGgBADADQADADABAGIAGBAQABAGgDADQgCADgGABIgDAAIgBAAQgFAAgDgCgAEvAZQgDgCgBgEIAAgCQAAgGAEgGIAjgxIgiAEQgKABgBgKIAAgBQgBgJAKgBIA5gGQAFAAADACQADABAAAFIAAABQABAEgBADIgoA3IAlgEQALgBABAJIAAABQAAAFgCADQgCACgGABIg7AGIgCAAQgDAAgCgCgAD8hFQgEgDAAgGQgBgHADgEQADgDAGgBQAHAAAEACQADAEABAGQABAHgDADQgDAEgHAAIgDAAQgEAAgDgCgAkChrQgJgBgGgEQgHgDgDgDQgDgEAAgFQgBgGAHgHIACgBIABAAQAHAHAKADIAKACIAJABQALgBAFgEQAFgEgBgIQAAgEgEgDQgFgDgIgBIgQgDQgIgBgIgDQgFgCgDgCIgGgGIgEgIIgCgIQAAgHABgFQABgFADgFQADgFAFgDQAFgEAGgDQAJgDAKgBQAKgBAIABQAIABAGADIAJAFQADAEAAAEQABAEgCADIgGAHIgCABIAAAAQgHgHgIgCQgIgDgKABQgKABgFAEQgEAEAAAHQABAEAEADQAEACAHABIAUADQAMADAIAEQAGAFAEAFQAEAGAAAHQACAUgOALQgFAFgJADQgIADgLABIgKAAIgJAAgAish3QgDgDgBgGIgGhCQgBgGACgDQADgDAGgBIACAAQAGgBADADQADADABAGIAHBCQAAAGgCADQgDADgFABIgDAAIgCAAQgFAAgCgCgAiDh7QgDgCAAgEIAAgCQgBgGAFgGIAjgzIgiAEQgLABgBgKIAAgBQgBgJALgBIA5gGQAFAAADACQACABABAFIAAABQAAAEgBADIgoA5IAmgEQAKgBABAJIAAABQABAFgCADQgDACgFABIg8AGIgBAAQgEAAgCgCgAgiiOQgHgGgDgIQgDgIgBgJQgBgLABgJQADgIAEgHQAGgHAHgEQAHgEAKgBQAJgBAGACQAHADAGAGIgFguQAAAAAAgBQAAAAABAAQAAgBABAAQABAAABAAIAFgCQAFAAAEACQAEACADAFQACAFAAAFIAKBfQAAAGgCADQgDADgGABIgCAAQgGABgDgDQgDgDgBgGIAAgDIgFAIIgGAGQgDADgFABIgHACIgFAAQgPAAgLgLgAgDjNIgKADQgEADgDAEQgCADgBAGQgBAFAAAFQACASAPAFQAEABADAAQAEAAAEgCQAEgCADgEQADgDABgEQACgEgBgEIgBgRQgEgHgGgDQgFgDgFAAIgCAAgABciQQgIgCgHgGQgGgFgEgIQgEgHgBgKIgBgCIABgGQACgBADAAIA9gHQgBgFgDgDQgCgEgEgDIgIgDQgEgBgFAAQgFABgGAEQgGAEgIAIQgDAAgEgCQgFgDgBgGQgBgIAJgHQAGgEAHgCIAQgDQAVgCAOALQAIAFAEAIQAEAJABAKQACAVgMAOQgGAIgIAEQgHAEgKABIgGAAQgHAAgGgCgABWizQABAFACAEQABADAEADQACACAFABQADABAFAAQAFgBAEgCIAGgEIAEgHIACgJgACsiaQgDgCgBgGIgHhMQAAAAAAgBQAAAAAAAAQABAAABgBQABAAABAAIAFgBQAHgBAEADQAEADACAIQAEgJAIgEQAGgFAKgBQAIgBAGACQAHACAFAFQAEAEADAHQADAGAAAJIAFAqQAAAGgCADQgDAEgGAAIgCAAQgGABgDgDQgDgCgBgGIgEgnQgCgTgQABQgHABgFADQgEAEgDAGIAFAuQABAGgDAEQgDADgFAAIgDABIgBAAQgFAAgDgDgAi1jbQgEgDgBgGQgBgHADgEQADgDAHgBQAGAAAEACQAEAEABAGQAAAHgDADQgDAEgGAAIgDAAQgFAAgCgCgAlkkkIgIgFIgBgCIAAgBIAfg1IgpguQAAgCAFgFQAFgEAGgBQAEAAAFACIAHAGIAaAhIAUglQADgGADgDQADgCAEAAQAFgBAEABQAEACADADIABADIgfA2IApAtIAAABQABACgFAEQgFAFgHAAQgEABgEgCQgEgCgDgFIgbghIgUAmQgDAFgDADQgDACgEABIgDAAIgFgBgAhGkrQgBAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBIAAgBIAFgQIgEgCQgHgBgFgEQgGgDgFgGQgEgGgCgGQgDgGgBgIQgBgKACgJQADgJAGgHQAGgHAIgEQAIgEAKgBQAKgBAHABQAIACAGAEQAJAGABAIQAAAEgCAEQgCACgFACIgDABIgBAAQgEgHgGgDQgGgDgIAAIgKADIgIAHQgCAEgBAEQgCAFABAGQAAAFADAFQACAFADADQAEADAFABQAEACAGgBQAIAAAGgFQAFgEACgIIABAAQAEAAAEACQAFACABAGIgBAHQgBADgDADQgDAFgFADQgFADgGABIAAABIgRAVQgCACgEAAgAjkkwQgGgBgEgCQgFgDgDgFQgCgFgBgGQgBgHADgHQAEgFAGgFQAHgEAKgDQALgEAOgBIADAAIgCgIQgBgDgDgCQgCgCgEgBIgIAAQgIABgFAEQgFAEgDAHIgBAAIAAAAQgIABgEgCQgEgDAAgGQgBgEADgEQACgEAEgEQAGgEAHgCQAHgDAKgBQAKgBAIACQAIACAGAEQAGAEADAGQADAHABAJIAGA1QAAABgFABIgFABQgHABgDgDQgFgDgCgHIgEAHIgHAFQgIAFgKABIgEAAIgHgBgAjDlbQgOACgFACQgGACgDADQgCADAAAFQABAFAEACQADADAHgBIAJgCQAEgCACgDQADgCABgFQABgDAAgFIgBgFgAiMk8QgDgCAAgGIgMhwQAAgBAAAAQABgBAAAAQABAAAAAAQABgBABAAIAGgBQAFgBAEACQAEACACAGQACAEABAGIAJBeQABAGgDADQgCAEgGAAIgDABIgBAAQgFAAgDgDgAAJlIQgGgBgDgCQgEgDgDgFQgCgFgBgGQgBgHADgHQAEgFAEgFQAHgEAKgDQALgEAOgBIADAAIgCgIQgBgDgDgCQgCgCgEgBIgIAAQgIABgFAEQgFAEgDAHIgBAAIAAAAQgGABgEgCQgEgDAAgGQgBgEADgEQACgEAEgEQAEgEAHgCQAHgDAKgBQAKgBAIACQAIACAGAEQAGAEADAGQADAHABAJIAGA1QAAABgFABIgFABQgHABgDgDQgFgDgCgHIgEAHIgHAFQgIAFgKABIgEAAIgHgBgAAqlzQgOACgFACQgGACgDADQgCADAAAFQABAFAEACQADADAHgBIAJgCQAEgCACgDQADgCABgFQABgDAAgFIgBgFgABilUQgDgCgBgGIgLhwQAAgBAAAAQAAgBABAAQAAAAABAAQABgBABAAIAFgBQAGgBADACQAEACADAGQACAEAAAGIAKBeQAAAGgCADQgDAEgFAAIgDABIgCAAQgFAAgCgDgACalWQgFgBgFgDQgFgDgCgEQgDgFgBgGQAAgIADgGQADgGAHgFQAGgEALgDQAKgDAOgBIADgBIgBgHQgCgEgCgBQgDgDgDAAIgIAAQgIAAgGAEQgFAEgCAHIgBAAIgBABQgHABgEgDQgEgCgBgGQAAgFACgDQACgFAFgDQAFgEAHgCQAIgDAJgBQALgBAIACQAIABAGAEQAFAEAEAHQADAGABAKIAFA0QAAABgEACIgFABQgHAAgEgDQgEgDgCgHIgFAHIgGAGQgIAEgKABIgEAAIgIAAgAC7mCQgOACgFACQgFACgDADQgDAEABAEQAAAGAEACQAEADAHgBIAIgCQAEgCADgDQACgDACgEQABgEgBgEIAAgGgADzliQgEgDAAgGIgIhLQAAgBAAAAQAAAAABgBQAAAAABAAQABgBABAAIAGgBQAGAAAFADQAEADACAIQACgJAFgEQAFgFAIgBQAIgBAFAEQAEADABAHQAAAFgBADQgBAEgDACIgCABQgFgEgHAAQgEABgEACQgDADgCADQgCAEAAAGIAAAMIADAbQAAAGgCADQgDADgGABIgCAAIgCAAQgFAAgCgCg");
	this.shape_1.setTransform(82.3,68.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},32).wait(1605));

	// 9
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqkBwQgEgEgBgJIgIhoQgBgJADgFQAEgEAJgBIBPgHQAIAAADADQAFADAAAHIAAABQABAHgEADQgDAEgIAAIhAAEIADAcIAvgEQAHAAAEACQAEADAAAGIAAABQABAHgDADQgEAEgHABIgvAEIACAfIBBgGQAIAAAEACQAEADAAAGIABACQAAAHgEAEQgDAEgHAAIhRAHIgDAAQgGAAgEgEgAoBBnQgFgBgCgEIguhaQgBgCAGgEQAFgCAFAAQAGgBAFACQAFADADAIIAbA+IAShBQACgJADgCQAEgEAGgBQAFAAAEACQAEABADACIACACIgfBfQgBAEgFADQgEACgHAAIgFABQgEAAgCgCgAmsBeQgEgDgBgIIgGhPQgBgGADgEQADgEAHAAIADgBQAHAAAEADQAEAEABAFIAGBQQABAHgDAEQgEAEgGABIgEAAIgBABQgGAAgDgEgAl1BZQgEgDgBgIIgHhZQAAgBAFgCIAGgBQAIgBAFAEQAFAEACAIQAGgJAJgFQAIgGALgBQAKAAAIACQAIADAFAGQAGAFACAGQAEAIAAAKIAFAzQAAAHgDAEQgDAEgHABIgDAAQgHABgEgEQgEgDAAgIIgEguQgCgXgUABQgIABgGAEQgGAEgCAHIAEA4QABAHgDAEQgDAEgHABIgEAAIgCABQgFAAgDgEgAj1BOQgEgDAAgHIgHhOQgBgHAEgEQADgEAHgBIADAAQAHgBAEAEQADADABAIIAHBNQAAAIgDADQgDAFgHAAIgDABIgCAAQgGAAgDgEgAjEBKQgDgCgBgFIAAgCQAAgHAGgIIArg6IgqAEQgMABgBgMIAAgBQgBgLAMgBIBFgGQAGgBAEADQADACAAAFIAAACQABAFgBADIgyBCIAugEQAMgBABALIAAABQABAGgDADQgDADgGABIhIAGIgCAAQgEAAgDgDgAhQBBQgEgDgBgIIgGhNQgBgIADgEQADgEAHAAIADgBQAHAAAEADQAEAEABAHIAGBOQABAHgDAEQgEAEgGABIgEAAIgBAAQgGABgDgEgAgZA9QgEgEAAgHIgIhZQAAgBAFgCIAHgCQAIAAAFAEQAFAEACAJQAFgKAHgGQAIgFALgBQAKgBAIACQAIADAGAGQAFAGADAHQADAIABAKIAEAxQABAIgDADQgEAFgGAAIgEABQgHAAgDgEQgEgDgBgHIgEgtQgCgXgTACQgJAAgFAEQgEAEgDAIIADA1QAAAIgBAEQgDAEgHAAIgDABIgCAAQgGAAgDgDgACNAjQgIgHgDgJQgEgKgBgKQgBgMACgLQADgKAGgIQAGgJAJgEQAJgFALgBQAMgBAJADQAJAEAGAHIgEg3QgBgCAFgBIAHgCQAGAAAEACQAFADADAGQACAFABAHIAJBwQABAIgDAEQgDAEgHAAIgDABQgHAAgEgDQgEgEAAgHIgBgEIgFAKQgEAEgEACQgEAEgFABQgFACgGABIgFAAQgUAAgNgPgAC0glQgHABgFACQgFADgDAFQgDAFgCAFQgBAGABAHQACAUAQAGQAGACAGgBQAFAAAFgCQAFgDADgEQAEgDABgFQACgFAAgDIgCgVQgEgIgHgEQgGgDgIAAIgDAAgAEoAkQgLgDgIgHQgSgOgCgYQgBgMAEgLQADgKAHgJQAHgIALgFQAKgEAMgBQAJgBAIABQAJACAHADQAHAEAGAGQAGAGADAIQAGAJABANQABAJgCAJQgCAGgEAHQgDAHgGAFQgGAGgIAEQgKAFgNABIgGABQgJAAgIgDgAE4gwQgHAAgFADQgFADgEAFQgEAFgBAGQgCAGAAAGQABAHACAFQADAEAFAEQAEAFAGABQAFACAHAAQAHgBAFgDQAFgCAEgGQAEgDABgFQACgGgBgGQAAgHgDgGQgCgGgFgEQgEgEgGgCQgEgBgFAAIgDAAgAGVAaQgKgCgFgEQgEgFgBgHQgBgHAHgDIACgBIAAAAQAIAFAJACQAJADALgBQAJgBAFgCQAEgDAAgDQAAgEgFgDQgEgCgIgBIgPgCQgHgBgIgDQgIgDgFgGQgEgGAAgJQgBgGABgGQABgFADgEQADgFAFgDIALgGQAHgDALgBIAPAAIANACQAIADAEAEQAFAEABAGQAAAEgCAEIgFAFIgCABQgHgGgIgDQgIgDgKABQgJABgEACQgFADABAGQAAADAEACQAFADAIABIAPACQAJABAGADQAJADAEAGQAFAGABAJQAAAJgDAGQgDAHgHAFQgGAEgIADQgIACgKABQgUAAgIgCgAIQASQgGgBgFgFQgFgEgDgHQgCgEgBgKIgEgxIgGABQgGAAgDgCQgEgDAAgFIgBgCQAAgGADgDQADgDAGAAIAGgBIgBgNQgBgIADgEQAEgEAHAAIACAAQAHgBAEADQAEAEAAAHIABAOIATgCQAGAAAEACQADADAAAFIAAACQABAGgDADQgDADgHABIgTABIAEAuQABAQAMgBQAJgBAFgIQACAAADADQADAEAAAFQABACgCAFQgDAEgEADQgIAFgLABIgDAAQgHAAgFgCgAJfALQgIgCgFgGQgFgEgDgIQgDgHgBgKIgEg0QgBgHADgEQADgFAHAAIADgBQAHAAAFAEQADADABAHIADAwQABAFACAFIAEAGQADADAEABQAEACAFgBQAIAAAFgEQAGgEADgIIgFg4QgBgIAEgEQADgEAHAAIADgBQAHAAAEAEQADADABAHIAIBZQAAACgGABIgGACQgIAAgFgEQgEgDgDgHQgFAIgJAFQgJAGgLABIgDABQgIAAgHgDgAm2gZQgEgDgBgIQgBgIAEgEQAEgEAHgBQAIgBAFAEQAEAEABAHQABAIgEAEQgEAFgIAAIgDABQgGAAgDgEgAj+goQgFgEAAgIQgBgHAEgFQADgEAIgBQAIAAAFADQAEAEABAIQAAAIgDAEQgEAEgIABIgDAAQgGAAgDgDgAhag2QgEgDgBgIQgBgIAEgEQAEgEAHgBQAIgBAFAEQAEAEABAHQABAIgEAEQgEAFgIAAIgDABQgGAAgDgEg");
	this.shape_2.setTransform(86.9,142.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},42).wait(1595));

	// 6
	this.instance = new lib.Symbol28("synched",0);
	this.instance.setTransform(85.6,142.2,1,1,0,0,0,85.6,27.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({startPosition:0,_off:false},0).wait(1611));

	// 4
	this.instance_1 = new lib.Symbol33("synched",0);
	this.instance_1.setTransform(85.6,89.8,1,1,0,0,0,69.7,89.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(18).to({startPosition:0,_off:false},0).wait(1619));

	// 3
	this.instance_2 = new lib.Symbol34("synched",0);
	this.instance_2.setTransform(80.4,161.4,1,1,0,0,0,57.6,33);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({startPosition:0,_off:false},0).wait(1627));

	// 2
	this.instance_3 = new lib.Symbol35("synched",0);
	this.instance_3.setTransform(83.1,188.8,1,1,0,0,0,53.6,30.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({startPosition:0,_off:false},0).to({_off:true},1583).wait(53));

	// 7
	this.instance_4 = new lib.Symbol29("synched",0);
	this.instance_4.setTransform(157.6,155,1,1,0,0,0,13.6,13.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(43).to({startPosition:0,_off:false},0).to({_off:true},1593).wait(1));

	// 1
	this.instance_5 = new lib.Symbol36("synched",0);
	this.instance_5.setTransform(63.6,217.6,1,1,0,0,0,26.9,21.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true},1584).wait(53));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(36.7,196.3,53.7,42.7);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	/* Layers with classic tweens must contain only a single symbol instance. */

	// Layer 1
	this.instance = new lib.Symbol13("synched",0);
	this.instance.setTransform(1515.2,311.6,1,1,-134.9,0,0,291.6,311.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:0,x:291.6,y:311.7},13,cjs.Ease.get(0.98)).to({startPosition:0},4).to({scaleX:1.33,scaleY:1.33},5,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},5,cjs.Ease.get(-0.99)).to({scaleX:1.09,scaleY:1.09},4,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},4).to({startPosition:0},7).to({alpha:0},6).wait(3567));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1088.6,-114.9,853.2,853.2);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.Symbol10("synched",0);
	this.instance.setTransform(102.9,139.3,0.163,0.163,0,0,0,38.5,55.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({startPosition:0,_off:false},0).to({scaleX:1.3,scaleY:1.3,x:56.7,y:74.1},6,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:68.9,y:91.3},4).wait(3229));

	// Layer 4
	this.instance_1 = new lib.Symbol11("synched",0);
	this.instance_1.setTransform(100.6,136.6,0.163,0.163,0,0,0,54.8,74.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:54.7,regY:74.3,scaleX:1.3,scaleY:1.3,x:38.3,y:52},6,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:54.7,y:74.3},4).wait(3231));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(91.7,124.5,17.8,24.2);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(87,310.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:186},9,cjs.Ease.get(1)).to({startPosition:0},48).wait(1643));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98.9,0,372,621);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween2_1("synched",0);
	this.instance.setTransform(296.4,310.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:184.8},10,cjs.Ease.get(1)).wait(2589));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(111.6,0,369.6,621);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhXbAdzMAAAg7lMCu3AAAMAAAA7lg");
	mask.setTransform(232.6,-18.1);

	// Symbol 16
	this.instance = new lib.Symbol16("synched",0);
	this.instance.setTransform(273.4,310.7,1,1,0,0,0,48.7,77.9);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({startPosition:0,_off:false},0).to({y:77.9},11,cjs.Ease.get(1)).to({_off:true},1800).wait(4));

	// Symbol 15
	this.instance_1 = new lib.Symbol15("synched",0);
	this.instance_1.setTransform(155.7,332.5,1,1,0,0,0,46.4,59.1);
	this.instance_1._off = true;

	this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({startPosition:0,_off:false},0).to({y:99.7},11,cjs.Ease.get(1)).to({_off:true},1804).wait(2));

	// Symbol 14
	this.instance_2 = new lib.Symbol14("synched",0);
	this.instance_2.setTransform(44.2,348.9,1,1,0,0,0,44.2,76.2);

	this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({y:116.1},11,cjs.Ease.get(1)).wait(1808));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,272.7,88.5,152.6);


(lib.Symbol4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(2.6,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:0.16},3).to({scaleY:1},3).wait(18));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.2,6.1);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol4_1("synched",0);
	this.instance.setTransform(16.5,39.3,1,1,0,0,0,2.6,3.1);

	this.instance_1 = new lib.Symbol4_1("synched",0);
	this.instance_1.setTransform(35.6,40,1,1,0,0,0,2.6,3.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9A88C").s().p("AgEAEQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBgBgBQAAAAAAAAQAAAAAAAAQAAgBABAAQAAgBAAAAQACgGAEADQAGAEABABQACAEgFACIgCABQgCAAgEgDg");
	this.shape.setTransform(14.8,46.1,3.806,3.806);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E9A88C").s().p("AgIADQgBAAAAAAQAAgBAAAAQAAgBAAgBQAAAAAAAAQABgBAHgDIAHAAQAEAAAAAEQAAADgEABIgGABIgCAAQgEAAgCgCg");
	this.shape_1.setTransform(35.5,47.9,3.806,3.806);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2C1301").s().p("AgJAFIAEgFIAFgDQAGgCAEAFIAAAAIgKAAIgFABIgEAEg");
	this.shape_2.setTransform(15.9,30.4,3.806,3.806);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2C1301").s().p("AAAAAQgIAAgBAAIAAgBQABgCAFAAQADAAABABQAGACAEADIAAABQgDgEgIAAg");
	this.shape_3.setTransform(36.4,31.4,3.806,3.806);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgJABIgBgCIADABIAGAAIgFAAIgDgCIgBgBIAAgEQAKAHAKgEIABACIgCABQgDABgGAAQAHAAAEAAIAAABQgEAHgHAAQgDAAgGgHg");
	this.shape_4.setTransform(24.7,60.7,3.806,3.806);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#472D0C").s().p("AADACQgDACgHgBQAGAAABgCIACgBIAAAAIAGgEQgCAGgDADg");
	this.shape_5.setTransform(27.9,59.2,3.806,3.806);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#472D0C").s().p("AgEgFIADADIAAACIABABIABACIAFABIgGgBIgBgCIABAFQgGgGACgFg");
	this.shape_6.setTransform(21.3,58.9,3.806,3.806);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BC845B").s().p("AgCAOQgEgFgBgGIABgBQAJgDABgRIABAAQABALgGAIIgCADQgBACACADQABAEAIAFIgBABQgGgBgDgEg");
	this.shape_7.setTransform(23.2,46.2,3.806,3.806);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#533323").s().p("AgKABIAAgBIALAAIAJgBQABABAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIgKACQgIAAgCgBg");
	this.shape_8.setTransform(31.1,5,3.806,3.806);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#533323").s().p("AABADIglgGIASADIASAAIAkgBIABABIgBAAQgHAEgNAAIgPgBg");
	this.shape_9.setTransform(30.1,8.4,3.806,3.806);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4E2D1E").s().p("AgBAOQgCgGACgIIACgNIABAAIABABIgCAMQgBAJAAAFIAAAAIgBAAg");
	this.shape_10.setTransform(51.9,31,3.806,3.806);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4E2D1E").s().p("AABARQgDgHAAgKQAAgMAFgFIAAABQgDAKAAAIIACAPIAAABIgBgBg");
	this.shape_11.setTransform(4.3,16.7,3.806,3.806);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#67493B").s().p("AgJAAIAAAAIATAAIAAAAIAAAAIgHABQgEAAgIgBg");
	this.shape_12.setTransform(37.2,16,3.806,3.806);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#67493B").s().p("AgpgIQAOALAaABIAqABQAAAAAAAAQABAAAAAAQAAAAgBAAQAAABAAAAQgRADgOAAQgiAAgRgRg");
	this.shape_13.setTransform(35.7,17.8,3.806,3.806);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#67493B").s().p("AgCAGQgNgGgHgLQgBAAABAAQAPALAHACIAWAIIABABIgBABIgFAAQgKAAgJgGg");
	this.shape_14.setTransform(17.3,19.5,3.806,3.806);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#AB7853").s().p("AgDAAQAAgEADgDQABAIADAHQgHgCAAgGg");
	this.shape_15.setTransform(4.4,44.4,3.806,3.806);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E5A679").s().p("AgJAFQgEgMAKgMIABAAIACAOQgDACAAADQAAAHAHACQADAGAEAFIgBAAQgPAAgEgPg");
	this.shape_16.setTransform(4.4,43.7,3.806,3.806);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2C1301").s().p("AADA/QgDgFgCgFQgDgHgDgKIgCgOQgBgEABgFQgEgNgBgPQgBgOACgFQAEgOAIgFQADgFAPgEIgQAQIgBAEQgFAIAEAHQABACAHALIgGgFIAAAAIAAAMQgCArAGAbg");
	this.shape_17.setTransform(7.4,27.2,3.806,3.806);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E29967").s().p("AgFAGIgBgNQAFACAFAAQAEAGgBAHIgEAAQgDAAgFgCg");
	this.shape_18.setTransform(24.6,74.8,3.806,3.806);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E29967").s().p("AgFgEQAFAAAGgEIAAAOIgBAAIgIACQABgGgDgGg");
	this.shape_19.setTransform(29,74.5,3.806,3.806);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F1C9A0").s().p("AgOA8QgIgFgFgIQgMgQgEgUIAAgBQgIgZACgtQALAHAZAIQARAIAfAAIgKgSQACACALADQAKADABACQACACgBAJIgCANQgCAYgQAdQgHALgEAEQgGAHgJAEQgHADgGAAIgFgBg");
	this.shape_20.setTransform(26,47.4,3.806,3.806);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#472815").s().p("AAAgCIACAAIgDAFg");
	this.shape_21.setTransform(46.7,49.2,3.806,3.806);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#472815").s().p("AgwAOQgLgEgEgDIACgEIARgOIAAAAQAygRAjATQASAJAFAQIgYADQgPACgKgCIgcgEQgSgEgLgGQAGAIACAHIgOgGg");
	this.shape_22.setTransform(31.2,7.9,3.806,3.806);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#AB7853").s().p("AgEAHIAEgNQAEABABADQABACgBACQgDAFgDAAIgDAAg");
	this.shape_23.setTransform(49.7,45.4,3.806,3.806);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2C1301").s().p("AgKAeQAKgfgBgcIgCgBIAPABQgDALgEANIAAAAIgEAKIgKAZg");
	this.shape_24.setTransform(51.4,36.3,3.806,3.806);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#E5A679").s().p("AgWBDIgFgDQAGADAPgFQAHgEAGgHQAEgEAGgLQAQgdADgYIABgNQABgJgCgCQAAgCgLgDQgLgDgBgCIAJASQgdAAgTgIQgZgIgKgHIABgMIAAAAIAHAFQAOAJARAGQASAGALgBIgLgMQgGgGgHgEQAMAGATABIAjADIACABQABAcgKAfIgDAHIAEgHQAIACAEgGQABgBgBgDQgCgEgDAAIAFgLQAIADgBAPQgDAQgVgBQgQAngUAMQgFADgHAAQgHAAgFgCg");
	this.shape_25.setTransform(30.8,45.9,3.806,3.806);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#533323").s().p("AgXATQgQgGgPgJQgJgIgBgDQgEgGAFgJQAFADAKAEIAPAHQgCgHgGgIQALAGARADIAcAFQALABAOgBIAZgDQADAMgDAOIgQgBIgjgDQgTgCgMgFQAGADAHAHIAKALIgDAAQgKAAgQgFg");
	this.shape_26.setTransform(30.9,19.5,3.806,3.806);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(180));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,56.5,78.2);


(lib.Symbol1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Symbol 2
	this.instance = new lib.Symbol2("synched",0);
	this.instance.setTransform(40.8,347.1,0.151,0.151,0,0,0,38.3,13.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:38.2,scaleX:1,scaleY:1,x:71.4,y:211.7},7,cjs.Ease.get(1)).to({startPosition:0},10).wait(1414));

	// Layer 2
	this.instance_1 = new lib.Tween6("synched",0);
	this.instance_1.setTransform(40.4,318.4,0.151,0.151);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.72,scaleY:0.72,x:59.3,y:118.9},3,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,x:68.5,y:-27.7},4).to({y:22.2},10,cjs.Ease.get(1)).wait(1414));

	// Layer 3
	this.instance_2 = new lib.Symbol3("synched",0);
	this.instance_2.setTransform(40.4,323.7,0.151,0.151,0,0,0,28.4,39.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:28.2,regY:39.1,scaleX:1,scaleY:1,x:68.6,y:56.7},7,cjs.Ease.get(1)).to({startPosition:0},10).wait(1414));

	// Layer 4
	this.instance_3 = new lib.Tween2("synched",0);
	this.instance_3.setTransform(40.4,345.4,0.151,0.151,0,0,0,0,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regY:52.6,scaleX:1,scaleY:1,x:68.8,y:200.1},7,cjs.Ease.get(1)).to({startPosition:0},10).wait(1414));

	// Layer 5
	this.instance_4 = new lib.Tween3("synched",0);
	this.instance_4.setTransform(46.8,347.1,0.151,0.151);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({scaleX:1,scaleY:1,x:111.1,y:211.4},7,cjs.Ease.get(1)).to({startPosition:0},10).wait(1414));

	// Layer 6
	this.instance_5 = new lib.Tween4("synched",0);
	this.instance_5.setTransform(37.3,333,0.151,0.151,0,0,0,19.2,-53);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:19.1,scaleX:0.84,scaleY:0.84,rotation:-2,x:45.8,y:157.7},3,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,rotation:24.2,x:47.8,y:118.3},4,cjs.Ease.get(1)).to({regX:19,rotation:0,y:118.2},10).wait(1414));

	// Layer 7
	this.instance_6 = new lib.Tween5("synched",0);
	this.instance_6.setTransform(43.5,334.5,0.151,0.151,0,0,0,-15.1,-43.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({regX:-15.1,regY:-43.2,scaleX:0.84,scaleY:0.84,rotation:-9.1,x:80.6,y:166.4},3,cjs.Ease.get(1)).to({regX:-14.9,regY:-42.9,scaleX:1,scaleY:1,rotation:-29.8,x:88.9,y:128.5},4,cjs.Ease.get(1)).to({regX:-14.8,rotation:0,x:89},10).wait(1414));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(30,315.1,20.1,56.3);


(lib.Symbol31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// PROFESSİONAL VƏ GİGENİK TƏMİZLİK
	this.instance = new lib.Tween52("synched",0);
	this.instance.setTransform(121.8,165);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({startPosition:0,_off:false},0).to({y:130,alpha:1},10,cjs.Ease.get(1)).to({startPosition:0},31).wait(1658));

	// BİZİ SEÇMƏYİNİZDƏ SƏBƏB
	this.instance_1 = new lib.Tween53("synched",0);
	this.instance_1.setTransform(117.3,60.9);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:25.9,alpha:1},10,cjs.Ease.get(1)).to({startPosition:0},62).wait(1633));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5.8,20.1,227.6,63.5);


(lib.Symbol29_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween49("synched",0);
	this.instance.setTransform(19.9,56.6,0.09,0.09,0,0,0,0,28.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.19,scaleY:1.19},9,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},7).wait(1164));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18.1,51.5,3.6,5.1);


(lib.Symbol28_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B41F2A").s().p("ABJBiQgIAAgDgEQgEgEAAgIIAAgvIgGAJQgEAEgFACQgEADgGABQgFACgGAAQgWAAgPgSQgGgIgEgKQgDgLAAgKQAAgNAEgLQADgKAHgJQAHgIAIgEQAJgEAMAAQANAAAJAFQAKAEAFAKQACgJAFgEQAFgFAIABIAGABQAGABAAABIAACJQAAAIgEAEQgEAEgHAAgAASgfQgFACgEAEQgEAFgCAGQgCAGAAAHQAAAVARAHQAGADAGAAQAMAAAIgHQAIgIAAgLIAAgUQgEgIgGgFQgHgFgLAAQgGAAgGADgAEOBfQgEgBgDgEIgCgCIATgqQgIgBgDgGIgmhYQAAgDAGgDQAFgDAGAAQAHAAAEADQAFAEADAIIAYA/IAWg+QACgIAFgFQAEgDAHAAQAEAAAEABIAIAFIABADIgzCCQgDAIgFAEQgEAEgGAAQgFAAgEgCgAHEA1QgHgCgEgEQgFgGgCgHQgCgHAAgKIAAgxIgGAAQgHAAgDgDQgDgDAAgFIAAgDQAAgFADgEQADgCAHAAIAGAAIAAgPQAAgHADgEQAEgEAHAAIADAAQAHAAAEAEQADAEAAAHIAAAPIAUAAQAHAAADACQADAEAAAFIAAACQAAAGgDADQgEADgGAAIgUAAIAAAuQAAARAMAAQAJAAAGgIQACAAACADQAEAEAAAFQAAAGgDADQgDAFgFACQgIAFgLAAQgJAAgHgDgAlRA0QgIgDgGgHQgFgFgCgJQgDgIAAgLIAAg0QAAgIAEgEQAEgDAHAAIADAAQAIAAADADQAEAEAAAIIAAAwQAAAGABAEQACAFACADQADADAEABQAEACAFAAQAIAAAGgEQAGgEAEgHIAAg5QAAgIAEgEQADgDAIAAIADAAQAHAAAEADQAEAEAAAIIAABdQAAACgGABIgGABQgJAAgEgEQgFgFgCgJQgHAKgJAFQgJAFgMAAQgLAAgHgEgAnQA1QgLgCgIgFQgHgEgDgFQgEgFAAgGQAAgIAKgIIADgBIAAAAQAJAJALAGIAMAEIAMACQAOAAAHgFQAHgFAAgIQAAgGgGgEQgFgDgKgCIgUgGQgKgCgJgFIgJgGQgEgDgDgFQgDgFgBgEQgBgGAAgGQAAgIACgGQACgHAEgFQAFgGAGgEQAGgEAJgCQALgEANAAQAMAAALADQAKACAHAEQAHAEADAEQADAFAAAFQAAAFgCAEQgDAFgFACIgDACIAAAAQgIgJgKgEQgKgFgMgBQgNAAgGAFQgGAFAAAIQAAAGAEADQAFAFAKABIAZAHQAOAEAJAHQAHAGAEAHQAEAHAAAJQAAAZgTAMQgIAFgKACQgLADgNAAQgOAAgLgDgACEA1QgHgCgFgDQgFgFgDgGQgDgGAAgIQAAgJAFgIQAEgGAJgDQAJgGAOgCQANgCASAAIAEAAQAAgGgBgEQgCgEgDgDQgCgDgFgBQgEgBgGgBQgKABgHAEQgHAEgEAJIgBAAIgBAAQgJAAgFgDQgFgEAAgHQAAgFADgGQAEgEAGgEQAHgEAKgCQAJgDAMAAQANAAAKADQAKADAHAGQAGAGAEAIQADAJAAAMIAABAQAAACgFAAIgHABQgIABgFgFQgFgEgBgKQgDAGgEADIgJAGQgKAFgNAAQgIgBgHgCgACzADQgSAAgGACQgHADgEADQgEAEAAAGQAAAHAFADQAEAEAJgBQAGAAAFgCQAFgBADgEQAEgDACgEQACgFAAgGIAAgGgAF6A2QgHAAgEgEQgEgEAAgHIAAhSQAAgIAEgEQAEgDAHAAIADAAQAIAAADADQAEAEAAAIIAABSQAAAHgEAEQgDAEgHAAgAg/A2QgHAAgEgEQgEgEAAgHIAAgxQAAgMgFgFQgEgGgKABQgHAAgGADQgGAEgEAGIAAA6QAAAHgDAEQgEAEgHAAIgDAAQgIAAgDgEQgEgEAAgHIAAgwQAAgXgTAAQgHAAgGADQgGAEgEAGIAAA6QAAAHgDAEQgEAEgHAAIgDAAQgIAAgDgEQgEgEAAgHIAAheQAAgBAFgBIAHgBQAIgBAFAFQAFAEACAKQAGgKAJgFQAJgFAKAAQAHAAAGACQAGABAEADIAIAHIAFAKIAIgKIAJgHQAEgDAGgBQAFgCAGAAQAKAAAIADQAIADAFAGQAFAFACAIQADAJAAALIAAA2QAAAHgEAEQgDAEgIAAg");
	this.shape_18.setTransform(191.3,38.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_18}]},39).wait(967));

	// Layer 4
	this.instance = new lib.Symbol29_1("synched",0);
	this.instance.setTransform(106.4,35.2,1,1,0,0,0,19.9,28.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(33).to({startPosition:0,_off:false},0).wait(973));

	// Layer 5
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B41F2A").s().p("AgvBPQgHgCgFgEQgGgEgDgHQgCgGAAgIQAAgJAEgHQAFgIAJgEQAJgFANgCQAOgDAQAAIAEAAQAAgFgCgFQgBgCgBgDQgDgCgEgCQgFgBgFAAQgKAAgHAEQgHAEgEAHIgBAAIgBAAQgKAAgEgDQgFgCAAgHQAAgFADgFQADgFAGgEQAIgEAJgCQAKgDAMAAQANAAAIADQAKADAGAGQAHAGADAJQAEAIAAAKIAABCQAAACgGABIgHABQgIAAgFgFQgFgEgBgJQgDAFgCADIgJAGQgKAFgNAAQgIAAgGgCgAAAAcQgSABgGACQgIACgEADQgDAEAAAGQAAAHAEADQAEAEAJAAQAGAAAFgCQAFgCAEgDQACgDACgFQACgFAAgGIAAgGgACHBNQgEgDgEgFIgkgrIAAAmQAAAIgDADQgEAEgHAAIgDAAQgIAAgDgEQgEgDAAgIIAAiMQAAgCAFgBIAHgBQAHAAAEAEQAFADADAGQABAGAAAHIAABFIAggmQAFgGAEgCQAEgCAFAAQAFAAAEACQAEACADADIABADIgjArIAoAxQAAACgFAEQgHAFgGAAQgFAAgFgDgADBBPQgHAAgEgEQgEgDAAgIIAAhRQAAgIAEgEQAEgEAHAAIADAAQAIAAADAEQAEAEAAAIIAABRQAAAIgEADQgDAEgHAAgAjABOQgJAAgFgEQgEgFAAgKIAAhtQAAgJAEgFQAFgFAJAAIAzAAQANAAAKADQAJACAHAFQAGAFADAHQAEAHAAAKQAAAGgCAFQgCAEgDAEQgDAEgFADQgFADgHABQAIABAGADQAGADAEAFQAEAFACAGQACAGAAAHQAAAMgFAJQgEAJgKAFQgHADgKACQgKACgOAAgAixA1IAfAAQANAAAGgDQAEgDACgEQACgEAAgGQAAgFgBgEIgFgGIgJgDIgMgBIgfAAgAixgGIAdAAQAMAAAGgFQAGgFAAgJQAAgJgGgFQgGgEgMAAIgdAAg");
	this.shape_19.setTransform(238.8,153.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_19}]},26).wait(980));

	// Layer 1
	this.instance_1 = new lib.Symbol29_1("synched",0);
	this.instance_1.setTransform(191.4,139.7,1,1,0,0,0,19.9,28.3);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(22).to({startPosition:0,_off:false},0).wait(984));

	// Layer 2
	this.instance_2 = new lib.Symbol30("synched",0);
	this.instance_2.setTransform(215.8,156.4,1,1,0,0,0,210.2,156);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(1006));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5.6,0.4,420.5,312);


(lib.Symbol27_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween50("synched",0);
	this.instance.setTransform(124.1,28.6);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:8.6,alpha:1},13,cjs.Ease.get(1)).wait(494));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,20,248.3,17.3);


(lib.Symbol26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.Symbol28_1("synched",0);
	this.instance.setTransform(136.8,102.6,0.41,0.41,0,0,0,226.6,151.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({startPosition:0,_off:false},0).wait(923));

	// Layer 1
	this.instance_1 = new lib.Symbol27_1("synched",0);
	this.instance_1.setTransform(124.1,8.6,1,1,0,0,0,124.1,8.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(934));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,248.3,37.3);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.Symbol25("synched",0);
	this.instance.setTransform(117.2,72.9,1,1,0,0,0,94.4,36.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(58).to({startPosition:0,_off:false},0).to({y:32.9,alpha:1},13,cjs.Ease.get(1)).wait(388));

	// Layer 1
	this.instance_1 = new lib.Symbol24("synched",0);
	this.instance_1.setTransform(125.6,72.6,1,1,0,0,0,120,31.3);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:32.6,alpha:1},13,cjs.Ease.get(1)).to({startPosition:0},41).to({y:52.6,alpha:0},12,cjs.Ease.get(1)).to({_off:true},1).wait(392));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5.6,41.3,239.9,62.6);


(lib.Symbol17_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween48("synched",0);
	this.instance.setTransform(128.6,56.7);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:24.7,alpha:1},11,cjs.Ease.get(1)).to({startPosition:0},23).wait(960));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(23.1,35.1,216.5,55.9);


(lib.Symbol16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween47("synched",0);
	this.instance.setTransform(126.1,51.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:21.2,alpha:1},12,cjs.Ease.get(1)).to({startPosition:0},7).to({startPosition:0},19).wait(648));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(31.7,28.1,185.8,48.9);


(lib.Symbol15_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween46("synched",0);
	this.instance.setTransform(123.5,52.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:22.2,alpha:1},12,cjs.Ease.get(1)).to({startPosition:0},20).to({startPosition:0},66).wait(728));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(9.4,14.2,236.4,49);


(lib.Symbol13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween41("synched",0);
	this.instance.setTransform(132.5,139.5,0.047,0.047);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.11,scaleY:1.11},10,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},9).wait(1083));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(126.4,133,12.3,13);


(lib.Symbol11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween39("synched",0);
	this.instance.setTransform(156,60.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},13).wait(837));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,312,121.5);


(lib.Symbol10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween38("synched",0);
	this.instance.setTransform(150,87.5,1,0.046);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.29},12,cjs.Ease.get(1)).to({scaleY:1},8).wait(1195));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,83.5,300,8);


(lib.Symbol9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_2 = new lib.Tween37("synched",0);
	this.instance_2.setTransform(150,156,1,0.026);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleY:1.24},10,cjs.Ease.get(1)).to({scaleY:1},7).wait(1127));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,152,300,8);


(lib.Symbol8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_1 = new lib.Tween36("synched",0);
	this.instance_1.setTransform(30.5,0,0.131,0.131,0,0,0,0,-86.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:-85.8,scaleX:1.26,scaleY:1.26,y:0.2},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,y:0.1},7).wait(1188));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26.5,0,8,22.6);


(lib.Symbol7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_1 = new lib.Tween35("synched",0);
	this.instance_1.setTransform(150,131.5,0.072,0.072);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.16,scaleY:1.16},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},8).wait(902));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(139.2,122,21.7,19);


(lib.Symbol6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// m8.png
	this.instance = new lib.Tween31("synched",0);
	this.instance.setTransform(145.5,198,0.157,0.157);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({startPosition:0,_off:false},0).to({scaleX:1.24,scaleY:1.24},9,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},7).wait(1138));

	// m7.png
	this.instance_1 = new lib.Tween32("synched",0);
	this.instance_1.setTransform(241.5,120.5,0.08,0.08,0,0,0,0,34.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({startPosition:0,_off:false},0).to({scaleX:1.31,scaleY:1.31},9,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},7).wait(1140));

	// m6.png
	this.instance_2 = new lib.Tween33("synched",0);
	this.instance_2.setTransform(85.5,123,0.111,0.111,0,0,0,0,36);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({startPosition:0,_off:false},0).to({scaleX:1.29,scaleY:1.29},9,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},7).wait(1142));

	// m5.png
	this.instance_3 = new lib.Tween34("synched",0);
	this.instance_3.setTransform(181.5,120,0.142,0.142,0,0,0,0,60.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regY:60,scaleX:1.27,scaleY:1.27},9,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},7).wait(1144));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(178.5,102.9,6.1,17.1);


(lib.Symbol4_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_1 = new lib.Tween30("synched",0);
	this.instance_1.setTransform(150,300);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:1},15).wait(922));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.Symbol3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_2 = new lib.Tween29("synched",0);
	this.instance_2.setTransform(116.5,178,0.062,0.062);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:1.19,scaleY:1.19},11,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},9).wait(740));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(109.3,167,14.4,22);


(lib.Symbol2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// x3.png
	this.instance = new lib.Tween22("synched",0);
	this.instance.setTransform(92.8,257.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18).to({startPosition:0,_off:false},0).to({y:-72.6},105,cjs.Ease.get(1)).to({y:-97.9,alpha:0},9).wait(648));

	// x3.png
	this.instance_1 = new lib.Tween23("synched",0);
	this.instance_1.setTransform(159.8,222);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({startPosition:0,_off:false},0).to({y:-109.7},106,cjs.Ease.get(1)).to({y:-133.8,alpha:0},8).wait(651));

	// x3.png
	this.instance_2 = new lib.Tween24("synched",0);
	this.instance_2.setTransform(129.3,254.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({startPosition:0,_off:false},0).to({y:-76.9},106,cjs.Ease.get(1)).to({y:-101.1,alpha:0},8).wait(654));

	// x3.png
	this.instance_3 = new lib.Tween25("synched",0);
	this.instance_3.setTransform(71.3,236);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({startPosition:0,_off:false},0).to({y:-96.6},107,cjs.Ease.get(1)).to({y:-119.8,alpha:0},7).wait(657));

	// x3.png
	this.instance_4 = new lib.Tween26("synched",0);
	this.instance_4.setTransform(39.8,253.9);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(5).to({startPosition:0,_off:false},0).to({y:-76.6},105,cjs.Ease.get(1)).to({y:-101.9,alpha:0},9).wait(661));

	// x3.png
	this.instance_5 = new lib.Tween27("synched",0);
	this.instance_5.setTransform(5,221.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({y:-109.1},105,cjs.Ease.get(1)).to({y:-134.3,alpha:0},9).wait(666));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.9,201,42,41);


(lib.Symbol3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhsJAmXMAAAhMmMDYTAAAMAAABMmg");
	mask.setTransform(154.3,245.6);

	// Symbol 21
	this.instance_3 = new lib.Symbol21("synched",0);
	this.instance_3.setTransform(423.7,-110.7,1,1,0,0,0,46.4,59.1);
	this.instance_3._off = true;

	this.instance_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({startPosition:0,_off:false},0).to({y:99.6},11,cjs.Ease.get(1)).wait(2442));

	// Symbol 20
	this.instance_4 = new lib.Symbol20("synched",0);
	this.instance_4.setTransform(317.6,-88.1,1,1,0,0,0,41.1,81.9);
	this.instance_4._off = true;

	this.instance_4.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(3).to({startPosition:0,_off:false},0).to({y:122.2},11,cjs.Ease.get(1)).wait(2443));

	// Symbol 19
	this.instance_5 = new lib.Symbol19("synched",0);
	this.instance_5.setTransform(236.3,-132.4,1,1,0,0,0,15,77.9);
	this.instance_5._off = true;

	this.instance_5.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(2).to({startPosition:0,_off:false},0).to({y:77.9},11,cjs.Ease.get(1)).wait(2444));

	// Symbol 18
	this.instance_6 = new lib.Symbol18("synched",0);
	this.instance_6.setTransform(152.5,-110.7,1,1,0,0,0,46.4,59.1);
	this.instance_6._off = true;

	this.instance_6.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({startPosition:0,_off:false},0).to({y:99.6},11,cjs.Ease.get(1)).wait(2445));

	// Symbol 17
	this.instance_7 = new lib.Symbol17("synched",0);
	this.instance_7.setTransform(47.6,-110.8,1,1,0,0,0,47.6,56.2);

	this.instance_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({y:99.5},11,cjs.Ease.get(1)).wait(2446));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-167,95.3,112.5);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 9
	this.instance = new lib.Symbol12("synched",0);
	this.instance.setTransform(394.1,311,1,1,0,0,0,291.6,311.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({startPosition:21},21).to({startPosition:75},54).to({y:139.4,startPosition:89},14,cjs.Ease.get(1)).to({startPosition:89},1369).to({y:65.9,startPosition:395},13,cjs.Ease.get(1)).wait(2520));

	// Layer 2
	this.instance_1 = new lib.Symbol3_2("synched",0);
	this.instance_1.setTransform(473.2,423.6,1,1,0,0,0,235,102);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(49).to({startPosition:0,_off:false},0).to({startPosition:26},26).to({scaleX:1.13,scaleY:1.13,x:483.5,y:-441.5,startPosition:40},14,cjs.Ease.get(1)).to({startPosition:40},1369).to({scaleX:0.75,scaleY:0.75,x:452.8,y:-189.5,startPosition:346},13).wait(2520));

	// Layer 3
	this.instance_2 = new lib.Symbol4("synched",0);
	this.instance_2.setTransform(381.5,331,1,1,0,0,0,331.5,9.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(44).to({startPosition:0,_off:false},0).to({startPosition:31},31).to({scaleX:1.13,scaleY:1.13,x:380.1,y:-545.9,startPosition:45},14,cjs.Ease.get(1)).to({startPosition:45},1369).to({regY:9.7,scaleX:0.75,scaleY:0.75,x:384.3,y:-258.6,startPosition:351},13).wait(2520));

	// Layer 4
	this.instance_3 = new lib.Symbol5("synched",0);
	this.instance_3.setTransform(396.5,246.1,1,1,0,0,0,161.1,96.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(37).to({startPosition:0,_off:false},0).to({startPosition:38},38).to({regX:161,scaleX:1.13,scaleY:1.13,x:396.9,y:-641.6,startPosition:52},14,cjs.Ease.get(1)).to({startPosition:52},1369).to({scaleX:0.75,scaleY:0.75,x:395.4,y:-322.1,startPosition:358},13).wait(2520));

	// Layer 8
	this.instance_4 = new lib.Symbol9("synched",0);
	this.instance_4.setTransform(153.2,242.1,1,1,0,0,0,54.7,74.3);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({startPosition:0,_off:false},0).to({startPosition:22},22).to({scaleX:1.13,scaleY:1.13,x:122.6,y:-646.2,startPosition:36},14,cjs.Ease.get(1)).to({startPosition:36},1369).to({scaleX:0.75,scaleY:0.75,x:213.5,y:-325.2,startPosition:342},13).wait(2520));

	// Layer 5
	this.instance_5 = new lib.Symbol6("synched",0);
	this.instance_5.setTransform(393.2,314.8,1,1,0,0,0,291.2,310.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(26).to({startPosition:0,_off:false},0).to({startPosition:0},49).to({scaleX:1.13,scaleY:1.13,x:393.3,y:-564.1},14,cjs.Ease.get(1)).to({startPosition:0},1369).to({scaleX:0.75,scaleY:0.75,x:393,y:-270.8},13).wait(2520));

	// Layer 6
	this.instance_6 = new lib.Symbol7("synched",0);
	this.instance_6.setTransform(184.8,310.5,1,1,0,0,0,184.8,310.5);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(37).to({startPosition:0,_off:false},0).to({startPosition:38},38).to({scaleX:1.13,scaleY:1.13,x:158.3,y:-569,startPosition:52},14,cjs.Ease.get(1)).to({startPosition:52},1369).to({scaleX:0.75,scaleY:0.75,x:237.2,y:-274,startPosition:358},13).wait(2520));

	// Layer 7
	this.instance_7 = new lib.Symbol8("synched",0);
	this.instance_7.setTransform(598.7,312.6,1,1,0,0,0,186,310.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(37).to({startPosition:0,_off:false},0).to({startPosition:38},38).to({scaleX:1.13,scaleY:1.13,x:625,y:-566.6,startPosition:52},14,cjs.Ease.get(1)).to({startPosition:57},5).to({startPosition:52},1364).to({scaleX:0.75,scaleY:0.75,x:546.6,y:-272.4,startPosition:358},13).wait(2520));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-200.1,-292.1,2244.3,1206.4);


(lib.Symbol = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AXXcHMAAAg4NIEOAAMAAAA4Ng");
	var mask_graphics_1 = new cjs.Graphics().p("ASicHMAAAg4NIJDAAMAAAA4Ng");
	var mask_graphics_2 = new cjs.Graphics().p("AN8cHMAAAg4NINpAAMAAAA4Ng");
	var mask_graphics_3 = new cjs.Graphics().p("AJlcHMAAAg4NISAAAMAAAA4Ng");
	var mask_graphics_4 = new cjs.Graphics().p("AFbcHMAAAg4NIWJAAMAAAA4Ng");
	var mask_graphics_5 = new cjs.Graphics().p("ABgcHMAAAg4NIaEAAMAAAA4Ng");
	var mask_graphics_6 = new cjs.Graphics().p("AiKcHMAAAg4NIduAAMAAAA4Ng");
	var mask_graphics_7 = new cjs.Graphics().p("AlocHMAAAg4NMAhMAAAMAAAA4Ng");
	var mask_graphics_8 = new cjs.Graphics().p("Ao4cHMAAAg4NMAkcAAAMAAAA4Ng");
	var mask_graphics_9 = new cjs.Graphics().p("Ar6cHMAAAg4NMAneAAAMAAAA4Ng");
	var mask_graphics_10 = new cjs.Graphics().p("AutcHMAAAg4NMAqRAAAMAAAA4Ng");
	var mask_graphics_11 = new cjs.Graphics().p("AxScHMAAAg4NMAs2AAAMAAAA4Ng");
	var mask_graphics_12 = new cjs.Graphics().p("AzpcHMAAAg4NMAvNAAAMAAAA4Ng");
	var mask_graphics_13 = new cjs.Graphics().p("A1xcHMAAAg4NMAxVAAAMAAAA4Ng");
	var mask_graphics_14 = new cjs.Graphics().p("A3rcHMAAAg4NMAzPAAAMAAAA4Ng");
	var mask_graphics_15 = new cjs.Graphics().p("A5WcHMAAAg4NMA06AAAMAAAA4Ng");
	var mask_graphics_16 = new cjs.Graphics().p("A6zcHMAAAg4NMA2XAAAMAAAA4Ng");
	var mask_graphics_17 = new cjs.Graphics().p("A7zcHMAAAg4NMA3nAAAMAAAA4Ng");
	var mask_graphics_18 = new cjs.Graphics().p("A8TcHMAAAg4NMA4nAAAMAAAA4Ng");
	var mask_graphics_19 = new cjs.Graphics().p("A8scHMAAAg4NMA5ZAAAMAAAA4Ng");
	var mask_graphics_20 = new cjs.Graphics().p("A8+cHMAAAg4NMA59AAAMAAAA4Ng");
	var mask_graphics_21 = new cjs.Graphics().p("A9JcHMAAAg4NMA6TAAAMAAAA4Ng");
	var mask_graphics_22 = new cjs.Graphics().p("A9McHMAAAg4NMA6ZAAAMAAAA4Ng");
	var mask_graphics_23 = new cjs.Graphics().p("A5TcHMAAAg4NMAynAAAMAAAA4Ng");
	var mask_graphics_24 = new cjs.Graphics().p("A1scHMAAAg4NMArZAAAMAAAA4Ng");
	var mask_graphics_25 = new cjs.Graphics().p("AyYcHMAAAg4NMAkxAAAMAAAA4Ng");
	var mask_graphics_26 = new cjs.Graphics().p("AvWcHMAAAg4NIetAAMAAAA4Ng");
	var mask_graphics_27 = new cjs.Graphics().p("AsncHMAAAg4NIZPAAMAAAA4Ng");
	var mask_graphics_28 = new cjs.Graphics().p("AqKcHMAAAg4NIUVAAMAAAA4Ng");
	var mask_graphics_29 = new cjs.Graphics().p("An/cHMAAAg4NIP/AAMAAAA4Ng");
	var mask_graphics_30 = new cjs.Graphics().p("AmHcHMAAAg4NIMPAAMAAAA4Ng");
	var mask_graphics_31 = new cjs.Graphics().p("AkhcHMAAAg4NIJDAAMAAAA4Ng");
	var mask_graphics_32 = new cjs.Graphics().p("AjOcHMAAAg4NIGdAAMAAAA4Ng");
	var mask_graphics_33 = new cjs.Graphics().p("AiOcHMAAAg4NIEdAAMAAAA4Ng");
	var mask_graphics_34 = new cjs.Graphics().p("AhocHMAAAg4NIDAAAMAAAA4Ng");
	var mask_graphics_35 = new cjs.Graphics().p("AhocHMAAAg4NICJAAMAAAA4Ng");
	var mask_graphics_36 = new cjs.Graphics().p("AhocHMAAAg4NIB3AAMAAAA4Ng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_1,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_2,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_3,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_4,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_5,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_6,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_7,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_8,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_9,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_10,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_11,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_12,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_13,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_14,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_15,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_16,x:176.5,y:145.5}).wait(1).to({graphics:mask_graphics_17,x:175,y:145.5}).wait(1).to({graphics:mask_graphics_18,x:171.7,y:145.5}).wait(1).to({graphics:mask_graphics_19,x:169.2,y:145.5}).wait(1).to({graphics:mask_graphics_20,x:167.4,y:145.5}).wait(1).to({graphics:mask_graphics_21,x:166.4,y:145.5}).wait(1).to({graphics:mask_graphics_22,x:166,y:145.5}).wait(1).to({graphics:mask_graphics_23,x:141.1,y:145.5}).wait(1).to({graphics:mask_graphics_24,x:118,y:145.5}).wait(1).to({graphics:mask_graphics_25,x:96.7,y:145.5}).wait(1).to({graphics:mask_graphics_26,x:77.3,y:145.5}).wait(1).to({graphics:mask_graphics_27,x:59.8,y:145.5}).wait(1).to({graphics:mask_graphics_28,x:44.1,y:145.5}).wait(1).to({graphics:mask_graphics_29,x:30.3,y:145.5}).wait(1).to({graphics:mask_graphics_30,x:18.2,y:145.5}).wait(1).to({graphics:mask_graphics_31,x:8.1,y:145.5}).wait(1).to({graphics:mask_graphics_32,x:-0.1,y:145.5}).wait(1).to({graphics:mask_graphics_33,x:-6.6,y:145.5}).wait(1).to({graphics:mask_graphics_34,x:-10.4,y:145.5}).wait(1).to({graphics:mask_graphics_35,x:-10.4,y:145.5}).wait(1).to({graphics:mask_graphics_36,x:-10.4,y:145.5}).wait(789));

	// Layer 3
	this.instance = new lib.Symbol32("synched",0);
	this.instance.setTransform(157.2,209.3,1,1,0,0,0,79.2,76.2);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(825));

	// Layer 1
	this.instance_1 = new lib.x4();

	this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(825));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,313);


(lib.Tween1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol4_1("synched",0);
	this.instance.setTransform(-11.8,9,1,1,0,0,0,2.6,3.1);

	this.instance_1 = new lib.Symbol4_1("synched",0);
	this.instance_1.setTransform(7.1,9,1,1,0,0,0,2.6,3.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgHBHIgHALIhZg0IAQgcIArAAIAAAFIgMAAIgMAWIBOAuIAMgUIAPAAIgBAAIAAgCIADAAIACAAIACAAIABAAIAAgBIAAgBIgBgBIgBAAIgBgBIgBABIgBAAIgBgCIADgEIgDAAIgCgCIgCgDIgBgEIgBgCIAAgIIABgFIACgDIADgDIAFgCIACAAIACABIADABIACACIABACIABACIAAADIgGAAIgBgDIgBgBIgCAAIgCAAIgBACIAAACIgBACIAAAIIABADIABABIACABIACgBIABgBIABgCIAGAAIAAACIAAACIgCAEIgDACIgFAAIgCADIABAAIAAgBIABAAIACABIABABIABABIABACIgBACIgBACIgBAAIAKAAIgRAbIgUgLIgHAMgABSAsIgDAAIgBgBIgCgCIAAgBIgBAAIAAABIgBABIgBABIgBABIgCAAIgDAAIgCAAIgCAAIgCgCIgBgDIgBgEIABgBIABgEIABgCIAEgCIAEgBIAEgBIAAgDIAAgBIAAgBIgBgBIgDAAIgDAAIgCACIgCABIgDgEIACgCIACgBIADgBIAEgBIACAAIACABIADABIACACIACACIAAACIAAACIAAAOIABABIAAABIABAAIAAAGgABJAcIgCABIgCABIgCACIAAADIAAABIACACIABAAIACAAIACgCIAAgBIAAgCIAAgFIgBAAgAAJAsIgCAAIgCgBIgBgCIgBgBIAAAAIgBABIgBABIgBABIAAABIgBAAIgCAAIgCAAIgCAAIgCgCIgBgDIgBgEIAAgBIABgEIACgCIADgCIAFgBIACgBIAAgDIAAgBIgBgBIgBgBIAAAAIgDAAIgCACIgCABIgEgEIACgCIACgBIADgBIAEgBIABAAIACABIACABIADACIABACIABACIAAACIAAAOIAAABIABABIABAAIAAAGgAABAcIgBABIgBABIgCACIgBADIABABIABACIACAAIAAAAIABgCIABgBIAAgCIAAgFIgBAAgAASAsIAAgqIAIAAIAAAqgAgWAsIgFgJIgEAJIgJAAIAJgQIgIgOIAIAAIADAFIABABIAAABIAEgHIAIAAIgIAOIAJAQgAgoAIIAAgnIAHAAIAAAFIABAAIADgEIAFgBIADAAIACACIABACIABABIAAADIAAAFIAAAEIAAAEIAAADIAAACIgBACIgBACIgDABIgCAAIgDgBIgDgBIgCgDIAAAAIAAANgAgegYIgBABIgBABIAAAOIABAAIACABIABAAIACAAIABgBIAAgDIAAgEIAAgFIAAgCIAAgBIgBgBIgBgBIgBAAIgCABgAAcAHIAAgFIAYAAIASgdIhOguIgRAdIgiAAIAWgmIAVAMIAGgLIASALIAHgLIBZAzIgVAlgAgdAHIAAgFIAsAAIAAAFgAhDAAQgDgCgCgFQgBgDABgEIABgDIACgCIABgFIABgDIgBgEIgCgDIgDgBIgEACIADgDIAEgBIAGABIAHAEIAGAHQACAFABAGIAAAGQgBADgCADIgDACIgFAAIgCAAQgDAAgDAAgAgFAAIgCAAIgCgCIgBgDIgBgDIAAgCIABgDIACgDIADgCIAFgBIACgBIAAgDIAAgBIAAgBIgCgBIAAAAIgDAAIgCACIgCABIgEgEIACgBIADgCIADgBIADAAIABAAIACAAIACABIADACIABACIABACIAAACIAAAOIAAABIAAAAIABABIABAAIAAAGIgDAAIgCAAIgCgBIgBgBIgBgCIAAAAIgBACIgBAAIgBABIAAABIgBAAIgCAAIgCAAgAAAgPIgBABIgCACIgBADIABABIABACIACAAIAAAAIABgCIABgBIAAgCIAAgFIgBAAIgBABgAAjAAIgIgRIAHgOIAIAAIgHAOIAJARgAASAAIAAgqIAIAAIAAAqg");
	this.shape_1.setTransform(-0.6,-31.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CB565F").s().p("AkXCQIgEgHIAAghIgCgxQACgeAMgjQAFgTAMgRQAQgXAZgTQA9gpBbgMQArgEASAAIBBAGQBaALA8AqQAZARAQAVQANATAGATIALByIgCASQAAAVgCAAQgMADhCgLIiCgXQgwgIgaAAQgLAAg1AIQheATgoAGQgwAJgUAAQgJAAgEgCgAAIBEIAIgMIATALIASgbIgKAAIAAAAIACgCIAAgCIAAgCIgBgBIgBgBIgCgBIgBAAIAAABIgCAAIADgDIAEgBIAEgCIACgDIAAgCIAAgDIgHAAIAAADIgBABIgCABIgDgBIgBgBIAAgDIAAgJIAAgCIAAgBIABgCIADAAIACAAIABABIAAACIAHAAIAAgCIgBgCIgBgCIgDgBIgCAAIgCgBIgCAAIgFABIgDABIgDAEIAAAFIAAAHIAAADIACAEIACACIACACIACABIgDAEIABABIACAAIABAAIAAAAIACAAIABABIAAABIAAABIgBABIgDAAIgCAAIgCgBIAAADIABAAIgQAAIgLAUIhPguIANgUIAMAAIAAgFIgrAAIgRAaIBaA0IAHgLgABIAZIABABIABABIACABIADABIACAAIAAgGIgBAAIAAgBIgBgBIAAgOIAAgCIAAgCIgCgDIgDAAIgCAAIgCgBIgCAAIgFABIgCAAIgCAAIgDABIAEAFIACgBIACgCIADAAIADAAIABABIAAABIAAABIAAADIgEAAIgFACIgDACIgBACIgCADIAAACIAAAEIACACIACACIACABIACAAIADAAIACgBIABAAIABgBIAAgBIABgBgAAAAZIAAABIACABIACABIACABIACAAIAAgGIgBAAIAAgBIAAgBIAAgOIAAgCIgBgCIgBgDIgDAAIgCAAIAAgBIgCAAIgFABIgDAAIgCAAIgCABIAEAFIABgBIACgCIAEAAIACAAIABABIAAABIAAABIAAADIgDAAIgFACIgDACIgCACIgBADIgBACIABAEIACACIACACIABABIACAAIADAAIACgBIABAAIABgBIAAgBIAAgBgAAPAcIAIAAIAAgnIgIAAgAgSAcIgIgPIAIgNIgIAAIgEAGIAAgBIgBgBIgDgEIgIAAIAIANIgJAPIAJAAIAEgIIAEAIIAIAAgAgsgGIAIAAIAAgOIABAAIACADIADABIADABIACgBIACgBIACgBIABgCIAAgCIAAgDIAAgEIAAgFIAAgEIAAgDIgBgCIgCgCIgCgBIgCAAIgGABIgDAEIAAAAIAAgFIgIAAgAAZgGIA3AAIAVgnIhag0IgGAMIgSgLIgGALIgWgMIgWAmIAjAAIARgeIBOAvIgSAfIgYAAgAghgGIAtAAIAAgFIgtAAgAhJgxIACADIABAEIgBADIgBAEIgCADIgBADQgBAEABADQABAFAEACQADADAFgBIAFgBIADgEQACgCAAgDIABgGQgBgGgCgFIgHgHIgGgEIgGgCIgEACIgDADIAEgCIADABgAgBgpIABABIAAABIAAABIAAADIgDAAIgFACIgDACIgCADIgBACIgBACIABAEIACADIACABIACABIABAAIADAAIACgBIABAAIABgBIAAgBIAAgBIAAAAIABABIABABIACABIACABIACAAIAAgGIgBAAIAAgBIAAAAIAAgBIAAgOIAAgCIgBgCIgBgCIgDgCIgCgBIAAAAIgCAAIgFAAIgCABIgDABIgCACIAEAEIABgBIADgCIADAAIACAAgAAYggIAIARIAJAAIgJgRIAGgOIgHAAgAAPgPIAIAAIAAgqIgIAAgABBAXIgBgCIgBgBIABgDIACgCIACgBIACgBIABAAIAAAFIAAABIAAACIgCACIgCAAIgCAAgAgGAXIgBgCIAAgBIAAgDIACgCIADgBIACgBIAAAAIAAAFIAAABIAAACIgBACIgCAAIgDAAgAgFgVIgCgCIAAgBIABgDIABgCIADgBIACgBIAAAAIAAAFIAAABIAAACIgBACIgCAAIgCAAgAghgWIgBgBIgCgBIAAgNIACgBIABgBIACgBIABAAIABABIABABIAAABIAAABIAAAGIAAAEIAAACIgBACIgCAAIgCAAg");
	this.shape_2.setTransform(-0.3,-29.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#873D44").s().p("AgMAFQgDgCAAgDQAAgCADgCQAGgDAGAAQAHAAAFADQAEACAAACQAAACgEADQgFADgHAAQgGAAgGgDg");
	this.shape_3.setTransform(0,-44.4,3.806,3.806);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#873D44").s().p("AhJAzIgDgDQgCgCABgDIABgJIACgKIAAgFQAAgRAFgQQADgMANgKIALgIQASgIAYgBQAVACANADQAKADAKAIQAOAJADANQADALAAAJIgBATIAFATQABAEgCADQgDAFgegFIgsgIIgEAAQgNAAgUAGQgSAFgGAAQgJAAgDgCg");
	this.shape_4.setTransform(0,-23.9,3.806,3.806);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9A88C").s().p("AgEAEQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBgBgBQAAAAAAAAQAAAAAAAAQAAgBABAAQAAgBAAAAQACgGAEADQAGAEABABQACAEgFACIgCABQgCAAgEgDg");
	this.shape_5.setTransform(-13.2,15.8,3.806,3.806);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E9A88C").s().p("AgIADQgBAAAAAAQAAgBAAAAQAAgBAAgBQAAAAAAAAQABgBAHgDIAHAAQAEAAAAAEQAAADgEABIgGABIgCAAQgEAAgCgCg");
	this.shape_6.setTransform(7.4,17.7,3.806,3.806);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2C1301").s().p("AgJAFIAEgFIAFgDQAGgCAEAFIAAAAIgKAAIgFABIgEAEg");
	this.shape_7.setTransform(-12.1,0.1,3.806,3.806);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2C1301").s().p("AAAAAQgIAAgBAAIAAgBQABgCAFAAQADAAABABQAGACAEADIAAABQgDgEgIAAg");
	this.shape_8.setTransform(8.3,1.1,3.806,3.806);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJABIgBgCIADABIAGAAIgFAAIgDgCIgBgBIAAgEQAKAHAKgEIABACIgCABQgDABgGAAQAHAAAEAAIAAABQgEAHgHAAQgDAAgGgHg");
	this.shape_9.setTransform(-3.3,30.5,3.806,3.806);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#472D0C").s().p("AADACQgDACgHgBQAGAAABgCIACgBIAAAAIAGgEQgCAGgDADg");
	this.shape_10.setTransform(-0.1,29,3.806,3.806);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#472D0C").s().p("AgEgFIADADIAAACIABABIABACIAFABIgGgBIgBgCIABAFQgGgGACgFg");
	this.shape_11.setTransform(-6.7,28.7,3.806,3.806);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BC845B").s().p("AgCAOQgEgFgBgGIABgBQAJgDABgRIABAAQABALgGAIIgCADQgBACACADQABAEAIAFIgBABQgGgBgDgEg");
	this.shape_12.setTransform(-4.8,16,3.806,3.806);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#533323").s().p("AgKABIAAgBIALAAIAJgBQABABAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIgKACQgIAAgCgBg");
	this.shape_13.setTransform(3,-25.2,3.806,3.806);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#533323").s().p("AABADIglgGIASADIASAAIAkgBIABABIgBAAQgHAEgNAAIgPgBg");
	this.shape_14.setTransform(2,-21.7,3.806,3.806);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#4E2D1E").s().p("AgBAOQgCgGACgIIACgNIABAAIABABIgCAMQgBAJAAAFIAAAAIgBAAg");
	this.shape_15.setTransform(23.8,0.8,3.806,3.806);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#4E2D1E").s().p("AABARQgDgHAAgKQAAgMAFgFIAAABQgDAKAAAIIACAPIAAABIgBgBg");
	this.shape_16.setTransform(-23.7,-13.4,3.806,3.806);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#67493B").s().p("AgJAAIAAAAIATAAIAAAAIAAAAIgHABQgEAAgIgBg");
	this.shape_17.setTransform(9.1,-14.2,3.806,3.806);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#67493B").s().p("AgpgIQAOALAaABIAqABQAAAAAAAAQABAAAAAAQAAAAgBAAQAAABAAAAQgRADgOAAQgiAAgRgRg");
	this.shape_18.setTransform(7.6,-12.4,3.806,3.806);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#67493B").s().p("AgCAGQgNgGgHgLQgBAAABAAQAPALAHACIAWAIIABABIgBABIgFAAQgKAAgJgGg");
	this.shape_19.setTransform(-10.7,-10.6,3.806,3.806);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#AB7853").s().p("AgDAAQAAgEADgDQABAIADAHQgHgCAAgGg");
	this.shape_20.setTransform(-23.6,14.1,3.806,3.806);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E5A679").s().p("AgJAFQgEgMAKgMIABAAIACAOQgDACAAADQAAAHAHACQADAGAEAFIgBAAQgPAAgEgPg");
	this.shape_21.setTransform(-23.6,13.4,3.806,3.806);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2C1301").s().p("AADA/QgDgFgCgFQgDgHgDgKIgCgOQgBgEABgFQgEgNgBgPQgBgOACgFQAEgOAIgFQADgFAPgEIgQAQIgBAEQgFAIAEAHQABACAHALIgGgFIAAAAIAAAMQgCArAGAbg");
	this.shape_22.setTransform(-20.6,-2.9,3.806,3.806);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#E29967").s().p("AgFAGIgBgNQAFACAFAAQAEAGgBAHIgEAAQgDAAgFgCg");
	this.shape_23.setTransform(-3.4,44.6,3.806,3.806);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#E29967").s().p("AgFgEQAFAAAGgEIAAAOIgBAAIgIACQABgGgDgGg");
	this.shape_24.setTransform(0.9,44.3,3.806,3.806);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F1C9A0").s().p("AgOA8QgIgFgFgIQgMgQgEgUIAAgBQgIgZACgtQALAHAZAIQARAIAfAAIgKgSQACACALADQAKADABACQACACgBAJIgCANQgCAYgQAdQgHALgEAEQgGAHgJAEQgHADgGAAIgFgBg");
	this.shape_25.setTransform(-2,17.2,3.806,3.806);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#472815").s().p("AAAgCIACAAIgDAFg");
	this.shape_26.setTransform(18.6,19,3.806,3.806);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#472815").s().p("AgwAOQgLgEgEgDIACgEIARgOIAAAAQAygRAjATQASAJAFAQIgYADQgPACgKgCIgcgEQgSgEgLgGQAGAIACAHIgOgGg");
	this.shape_27.setTransform(3.1,-22.3,3.806,3.806);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#AB7853").s().p("AgEAHIAEgNQAEABABADQABACgBACQgDAFgDAAIgDAAg");
	this.shape_28.setTransform(21.6,15.2,3.806,3.806);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2C1301").s().p("AgKAeQAKgfgBgcIgCgBIAPABQgDALgEANIAAAAIgEAKIgKAZg");
	this.shape_29.setTransform(23.3,6,3.806,3.806);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#E5A679").s().p("AgWBDIgFgDQAGADAPgFQAHgEAGgHQAEgEAGgLQAQgdADgYIABgNQABgJgCgCQAAgCgLgDQgLgDgBgCIAJASQgdAAgTgIQgZgIgKgHIABgMIAAAAIAHAFQAOAJARAGQASAGALgBIgLgMQgGgGgHgEQAMAGATABIAjADIACABQABAcgKAfIgDAHIAEgHQAIACAEgGQABgBgBgDQgCgEgDAAIAFgLQAIADgBAPQgDAQgVgBQgQAngUAMQgFADgHAAQgHAAgFgCg");
	this.shape_30.setTransform(2.7,15.6,3.806,3.806);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#533323").s().p("AgXATQgQgGgPgJQgJgIgBgDQgEgGAFgJQAFADAKAEIAPAHQgCgHgGgIQALAGARADIAcAFQALABAOgBIAZgDQADAMgDAOIgQgBIgjgDQgTgCgMgFQAGADAHAHIAKALIgDAAQgKAAgQgFg");
	this.shape_31.setTransform(2.8,-10.7,3.806,3.806);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance_1},{t:this.instance}]}).wait(1194));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.9,-47.8,60.1,95.8);


(lib.Symbol57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol56("synched",0);
	this.instance.setTransform(65,78.7,1,1,0,0,0,65,64.7);

	this.instance_1 = new lib.Symbol53("synched",0);
	this.instance_1.setTransform(101,42.8,1,1,0,0,0,42.7,42.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1571));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,143.8,143.4);


(lib.Symbol52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Symbol57("synched",0);
	this.instance.setTransform(65,71.7,1,1,0,0,0,65,71.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(289));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,143.8,143.4);


(lib.Symbol46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AcLNSQg8gMglgTIAbhlQAsARAvALQAwAJAoABQApAAAYgTQAXgSAAgdQAAgfgZgUQgVgTgxgRIhKgbQgmgRgYgSQgcgWgPgdQgPggAAgrQAAgrASgiQARgfAggVQAfgVApgLQAogKAuAAQAvAAAxAKQAqAJAlAOIgaBtQgmgRgsgJQgmgJgcABQgqAAgYAPQgZAQAAAgQgBAOAJAOQAJALAPAKQAXAPA2ARQAqAMAfAQQAiASAWAXQAYAWAMAdQANAdAAAkQgBApgPAiQgQAhgcAYQgcAZgmAMQgnANguAAQg7AAg8gNgAT5NSQg8gMglgTIAbhlQAsARAvALQAwAJAoABQApAAAYgTQAXgSAAgdQAAgfgZgUQgVgTgxgRIhKgbQgmgRgYgSQgcgWgOgdQgQggAAgrQAAgrASgiQARgfAggVQAfgVApgLQAogKAuAAQAuAAAyAKQAqAJAlAOIgaBtQglgRgtgJQglgJgdABQgqAAgYAPQgaAQABAgQAAAOAIAOQAJALAPAKQAYAPA1ARQAqAMAfAQQAiASAWAXQAYAWAMAdQANAdAAAkQAAApgQAiQgQAhgcAYQgcAZgmAMQgnANguAAQg7AAg8gNgAuiNOQgbgIgYgPQgXgOgUgVQgUgUgOgcQgPgdgKgjQgJgkgCgrQgDgtAFg1IGsAAQgFgmgNgcQgOgcgVgRQgWgTgegIQgfgKgoABQgnAAgnAIQgcAGghANIgYhoQAhgPA4gIQAwgIAxAAQAlAAAhAHQAgAFAbANQAcALAXASQAVARASAVQARAWANAZQANAZAIAcQAQBPAAArQgFBRgMAkIgXA0QgNAYgRAVQgTAVgWARQgWARgaALQgbANgeAFQgfAHgjAAQhQgFglgMgAu4KfQAJAcAQATQARASAZAKQAbAKAjAAQAogBAdgIQAcgJAUgTQARgRALgcQALgbAEgmIkrAAQABAkAJAagEBD5ANWIjvlwIAAFwIiBAAIAApZICCAAIDzF0IAAl0IB/AAIAAJZgEA5lANWIAApZICAAAIAAJZgEAviANWIAApZIDWAAQAnAAAhAGQAhAGAcAKQAcALAXAPQAVAQATAUQARAUAOAYQAMAXAJAcQARBOAAArQAAAmgGAgQgFAhgJAdQgLAbgPAYQgQAXgTATQgVATgYAOQgYAOgdAKQgdAJghAFIhFAFgEAxjAL0IA8AAQAtgBAfgIQAlgKAXgVQAagXAMgmQAOgpAAg9QAAg5gNgoQgMgngYgXQgWgWgjgLQgggKguABIhAAAgEAnOANWIAApZIGEAAIAABsIkDAAIAACCIDOAAIAABrIjOAAIAACVIEGAAIAABrgAORNWIAApZICAAAIAAJZgAJwNWIAAj7IjxAAIAAD7IiAAAIAApZICAAAIAADuIDxAAIAAjuIB/AAIAAJZgA4HNWIAApZICBAAIAAHuID+AAIAABrgA8VNWIgZlmIiIFmIhbAAIiIlmIgZFmIh9AAIAppZICQAAICTGLICSmLICRAAIApJZgEgpGANWIAApZICAAAIAAJZgEgyWANWIAAh0IE2l5IkoAAIAAhsIHAAAIAAB1Ik/F5IFIAAIAABrgEg2QANWIAApZICAAAIAAJZgEg/VANWIAApZIDgAAQAqAAAiAHQAmAHAbARQAdASAQAdQARAfAAAsQAAAogXAkQgLASgPAOQgQAQgUAKQAZAJAVAOQAVAPAOATQANATAGAXQAHAVAAAYQAAAugSAiQgSAggiAVQgeASgrAKQgnAJguAAgEg9UAL0IBUAAIAwgFQAUgEANgJQANgJAHgRQAFgQAAgaQAAgXgJgPQgIgNgQgIQgYgNguAAIhXAAgEg9UAHrIBKAAQApAAATgJQAQgHAIgNQAJgPAAgXQABgXgGgNQgFgOgLgJQgUgOg0ABIhKAAgAj1G6IgNjYIB4AAIgNDYgAmOG6IgNjYIB5AAIgNDYgEhDRAG6IgNjYIB5AAIgNDYgEhFqAG6IgMjYIB4AAIgNDYgEA52AC0QgVgUABgdQgBgdAVgTQATgUAdAAQAdAAAUAUQATATABAdQgBAdgTAUQgUATgdAAQgdAAgTgTgAOhC0QgUgUAAgdQAAgdAUgTQAUgUAcAAQAeAAATAUQAUATAAAdQAAAdgUAUQgTATgeAAQgcAAgUgTgEgo2AC0QgTgUAAgdQAAgdATgTQAUgUAdAAQAdAAAUAUQATATAAAdQAAAdgTAUQgUATgdAAQgdAAgUgTgEg2AAC0QgUgUAAgdQAAgdAUgTQATgUAeAAQAcAAAUAUQAUATAAAdQAAAdgUAUQgUATgcAAQgeAAgTgTgEAtUgA/QhKgJgfgNQgWgJgVgOQgTgOgRgSQgQgTgNgXQgNgXgIgbIgOg9IgEhGIAEhJQAFghAJgfQAIgdAOgZQANgZATgUQARgVAXgPQAXgPAcgKQAbgLAggFQAggFAlAAQApAABIASQAYAIAWANQAWAOARASQATASAOAWQANAYAKAcQAKAdAFAgQAFAiAAAmQAAA6gLAxQgJAvgWAmQgVAngeAbQgfAbgpAQICuByIhHBfgEAswgIzQgfALgSAZQgTAYgJAoQgJApAAA7QAAA2AIAlQAJAlASAXQASAWAcALQAbAJAoABQArgBAdgKQAegMASgZQATgZAJgpQAJgpAAg9QAAg2gJgkQgIgkgSgWQgSgVgcgKQgbgJgoAAQgrAAgcAKgAYfhPQgcgIgYgPQgYgOgTgVQgUgUgPgcQgPgdgIgjQgJgkgEgrQgCgtAFg1IGsAAQgGgmgNgcQgMgcgXgRQgVgTgfgIQgegKgoABQgoAAgmAIQgcAGghANIgXhoQAggPA3gIQAxgIAwAAQAmAAAhAHQAgAFAcANQAbALAWASQAXARARAVQARAWANAZQANAZAIAcQAQBPAAArQgGBRgLAkIgWA0QgOAYgSAVQgSAVgVARQgWARgbALQgaANgfAFQgfAHgjAAQhRgFgjgMgAYIj+QAJAcAQATQARASAaAKQAaAKAkAAQAngBAcgIQAdgJATgTQATgRALgcQAKgbADgmIkqAAQABAkAJAagEg6tgBPQgbgIgYgPQgXgOgUgVQgUgUgOgcQgPgdgKgjQgJgkgCgrQgDgtAFg1IGsAAQgFgmgOgcQgNgcgVgRQgWgTgegIQgfgKgoABQgnAAgnAIQgcAGghANIgXhoQAggPA4gIQAwgIAwAAQAmAAAhAHQAgAFAcANQAbALAWASQAXARARAVQARAWANAZQANAZAIAcQAQBPAAArQgFBRgMAkIgWA0QgOAYgSAVQgRAVgWARQgXARgaALQgbANgeAFQggAHgiAAQhRgFgkgMgEg7DgD+QAJAcAQATQARASAZAKQAbAKAkAAQAngBAcgIQAdgJAUgTQARgRALgcQALgbAEgmIkrAAQABAkAJAagEBDPgBHIAApZICAAAIAAJZgEA+ogBHIjwlwIAAFwIiAAAIAApZICCAAIDyF0IAAl0ICBAAIAAJZgEA0UgBHIAApZICAAAIAAJZgEAlegBHIiHjpIgkAAIAADpIiAAAIAApZIDfAAQA2AAAnAMQAnALAZAXQAaAYAMAhQAMAiAAAsQAAAlgKAdQgKAbgSAXQgRAUgYAOQgXANgcAIICeD5gEAizgGbIBOAAQAygBAXgRQANgJAHgPQAGgPAAgXQAAgYgHgOQgIgPgNgIQgYgMg5AAIhEAAgAOihHIAApZIGEAAIAABsIkDAAIAACCIDOAAIAABrIjOAAIAAEAgAGGhHIjwlwIAAFwIiAAAIAApZICCAAIDyF0IAAl0ICBAAIAAJZgAkLhHIAApZICAAAIAAJZgAqwhHIAAjeIjCl7ICPAAIB0D3IB6j3ICKAAIjEF8IAADdgAxThHIAApZICBAAIAAJZgA4yhHIAApZICBAAIAAHuID+AAIAABrgEgh9gBHIAAh0IE1l5IkoAAIAAhsIHAAAIAAB1Ik+F5IFHAAIAABrgEgl5gBHIAApZIB/AAIAAJZgEgqMgBHIgYlmIiIFmIhcAAIiIlmIgYFmIh+AAIAopZICRAAICUGLICSmLICQAAIAoJZgEhDMgBHIAAntIixAAIAAhsIHgAAIAABsIivAAIAAHtgEBDfgLpQgUgUAAgdQAAgdAUgTQATgUAeAAQAcAAAUAUQAUATAAAdQAAAdgUAUQgUATgcAAQgeAAgTgTgEA0kgLpQgUgUAAgdQAAgdAUgTQATgUAeAAQAcAAAUAUQAUATAAAdQAAAdgUAUQgUATgcAAQgeAAgTgTgAj8rpQgTgUgBgdQABgdATgTQAUgUAdAAQAdAAATAUQAVATgBAdQABAdgVAUQgTATgdAAQgdAAgUgTgAxDrpQgTgUgBgdQABgdATgTQAUgUAdAAQAdAAATAUQAUATAAAdQAAAdgUAUQgTATgdAAQgdAAgUgTgEglpgLpQgVgUAAgdQAAgdAVgTQATgUAdAAQAdAAATAUQAVATAAAdQAAAdgVAUQgTATgdAAQgdAAgTgTg");
	this.shape.setTransform(415.4,653.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},15).wait(276));

	// Symbol 50
	this.instance = new lib.Symbol50("synched",0);
	this.instance.setTransform(1301.8,288.5,1,1,0,0,0,269.6,31.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({startPosition:0,_off:false},0).to({x:383},11,cjs.Ease.get(1)).wait(276));

	// Symbol 51
	this.instance_1 = new lib.Symbol51("synched",0);
	this.instance_1.setTransform(1387.4,206.6,1,1,0,0,0,254.5,30.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({startPosition:0,_off:false},0).to({x:468.5},11,cjs.Ease.get(1)).wait(277));

	// Symbol 49
	this.instance_2 = new lib.Symbol49("synched",0);
	this.instance_2.setTransform(1388.1,128.6,1,1,0,0,0,255.2,30.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({startPosition:0,_off:false},0).to({x:469.2},11,cjs.Ease.get(1)).wait(278));

	// Symbol 52
	this.instance_3 = new lib.Symbol52("synched",0);
	this.instance_3.setTransform(1032.4,168.8,1,1,0,0,0,71.9,71.7);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({startPosition:0,_off:false},0).to({x:113.6,startPosition:11},11,cjs.Ease.get(1)).wait(279));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol1copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Symbol 2
	this.instance = new lib.Symbol2("synched",0);
	this.instance.setTransform(71.4,211.7,1,1,0,0,0,38.2,13.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(1983));

	// Layer 3
	this.instance_1 = new lib.Tween1_1("synched",0);
	this.instance_1.setTransform(68.9,94.9,1,1,0,0,0,0.4,47);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(1983));

	// Layer 4
	this.instance_2 = new lib.Tween2("synched",0);
	this.instance_2.setTransform(68.8,200.1,1,1,0,0,0,0,52.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(1983));

	// Layer 5
	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(111.1,211.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(1983));

	// Layer 6
	this.instance_4 = new lib.Tween4("synched",0);
	this.instance_4.setTransform(47.8,118.2,1,1,0,0,0,19,-53);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).wait(1983));

	// Layer 7
	this.instance_5 = new lib.Tween5("synched",0);
	this.instance_5.setTransform(89,128.5,1,1,0,0,0,-14.9,-43);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleY:0.84,skewX:-119.8,skewY:60,x:105.9,y:117.5},5,cjs.Ease.get(1)).to({_off:true},1974).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132.7,371.3);


(lib.Symbol1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Symbol 2
	this.instance_8 = new lib.Symbol2("synched",0);
	this.instance_8.setTransform(71.4,211.7,1,1,0,0,0,38.2,13.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({regY:13.5,scaleY:0.81,y:241.3},5,cjs.Ease.get(1)).to({scaleY:0.75,y:80.7},6).to({startPosition:0},3,cjs.Ease.get(-0.99)).to({regY:13.4,scaleY:0.78,y:91.2},2,cjs.Ease.get(-0.99)).to({scaleY:0.83,y:100.4},1).to({scaleY:0.89,y:117.5},1).to({scaleY:0.94,y:134.6},1).to({regY:13.6,scaleY:1,y:211.7},1).to({startPosition:0},7,cjs.Ease.get(1)).to({regX:38.4,regY:13.5,scaleX:0.27,scaleY:0.27,x:67.7,y:209.6,alpha:0},6,cjs.Ease.get(1)).wait(1950));

	// Layer 3
	this.instance_9 = new lib.Tween1_1("synched",0);
	this.instance_9.setTransform(68.9,94.9,1,1,0,0,0,0.4,47);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({scaleY:0.81,y:146.2},5,cjs.Ease.get(1)).to({scaleY:1,y:-32.7},6).to({startPosition:0},3,cjs.Ease.get(-0.99)).to({scaleY:1,y:94.9},6,cjs.Ease.get(-0.99)).to({startPosition:0},7,cjs.Ease.get(1)).to({scaleX:0.27,scaleY:0.27,x:67,y:178.4,alpha:0,startPosition:7},6,cjs.Ease.get(1)).wait(1950));

	// Layer 4
	this.instance_10 = new lib.Tween2("synched",0);
	this.instance_10.setTransform(68.8,200.1,1,1,0,0,0,0,52.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({scaleY:0.81,y:231.9},5,cjs.Ease.get(1)).to({scaleY:1,y:72.5},6).to({startPosition:0},3,cjs.Ease.get(-0.99)).to({regY:0,scaleY:1,y:147.5},6,cjs.Ease.get(-0.99)).to({startPosition:0},7,cjs.Ease.get(1)).to({scaleX:0.27,scaleY:0.27,x:67,y:192.5,alpha:0},6,cjs.Ease.get(1)).wait(1950));

	// Layer 5
	this.instance_11 = new lib.Tween3("synched",0);
	this.instance_11.setTransform(111.1,211.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({scaleY:0.81,y:241.1},5,cjs.Ease.get(1)).to({scaleY:1,y:83.9},6).to({startPosition:0},3,cjs.Ease.get(-0.99)).to({scaleY:1,y:211.4},6,cjs.Ease.get(-0.99)).to({startPosition:0},7,cjs.Ease.get(1)).to({scaleX:0.27,scaleY:0.27,x:78.3,y:209.6,alpha:0},6,cjs.Ease.get(1)).wait(1950));

	// Layer 6
	this.instance_12 = new lib.Tween4("synched",0);
	this.instance_12.setTransform(47.8,118.2,1,1,0,0,0,19,-53);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({scaleY:0.51,y:161.9},5,cjs.Ease.get(1)).to({scaleY:1.6,skewX:180,y:-17.6},6).to({startPosition:0},3,cjs.Ease.get(-0.99)).to({regY:-53,scaleY:1.09,skewX:178,x:47.9,y:-2.4},2,cjs.Ease.get(-0.99)).to({regX:20.4,regY:-51.7,scaleX:0.8,scaleY:1.05,skewX:89,skewY:180,x:47.7,y:57.9},2).to({regX:19,regY:-52.9,scaleX:1,scaleY:1,skewX:0,skewY:0,x:47.8,y:118.2},2).to({startPosition:0},7,cjs.Ease.get(1)).to({regX:18.9,scaleX:0.27,scaleY:0.27,rotation:90,x:61.4,y:184.6,alpha:0},6,cjs.Ease.get(1)).wait(1950));

	// Layer 7
	this.instance_13 = new lib.Tween5("synched",0);
	this.instance_13.setTransform(89,128.5,1,1,0,0,0,-14.9,-43);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({scaleY:0.51,y:167.2},5,cjs.Ease.get(1)).to({scaleY:1,y:0.8},6).to({startPosition:0},3,cjs.Ease.get(-0.99)).to({scaleY:1,y:128.5},6,cjs.Ease.get(-0.99)).to({startPosition:0},7,cjs.Ease.get(1)).to({regY:-42.7,scaleX:0.27,scaleY:0.27,rotation:-89.8,x:72.4,y:187.4,alpha:0},6,cjs.Ease.get(1)).wait(1950));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,132.7,371.3);


(lib.adamcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 22
	this.instance = new lib.Symbol1copy2("synched",0);
	this.instance.setTransform(-12.6,89.8,1,1,0,0,0,66.3,185.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30).to({startPosition:0,_off:false},0).wait(915));

	// Layer 2
	this.instance_1 = new lib.Symbol1copy("synched",0);
	this.instance_1.setTransform(-12.6,89.8,1,1,0,0,0,66.3,185.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},30).wait(915));

	// Layer 3
	this.instance_2 = new lib.Symbol40("synched",0);
	this.instance_2.setTransform(-5.4,270.1,1,1,0,0,0,120,23.5);
	this.instance_2.alpha = 0.43;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(945));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127.4,-145.9,242,439.6);


(lib.adam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 22
	this.instance = new lib.Symbol1_1("synched",0);
	this.instance.setTransform(-12.6,89.8,1,1,0,0,0,66.3,185.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30).to({startPosition:0,_off:false},0).wait(915));

	// Layer 2
	this.instance_1 = new lib.Symbol1copy("synched",0);
	this.instance_1.setTransform(-12.6,89.8,1,1,0,0,0,66.3,185.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},30).wait(915));

	// Layer 3
	this.instance_2 = new lib.Symbol40("synched",0);
	this.instance_2.setTransform(-5.4,270.1,1,1,0,0,0,120,23.5);
	this.instance_2.alpha = 0.43;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(945));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127.4,-145.9,242,439.6);


(lib.Symbol12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.instance_1 = new lib.Symbol17_1("synched",0);
	this.instance_1.setTransform(149.1,56,1,1,0,0,0,128.6,24.7);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(49).to({startPosition:0,_off:false},0).wait(1087));

	// Layer 5
	this.instance_2 = new lib.adamcopy("synched",0);
	this.instance_2.setTransform(34.9,392.3,0.651,0.651,0,0,0,-47.3,-12.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(36).to({startPosition:0,_off:false},0).wait(1100));

	// Layer 3
	this.instance_3 = new lib.Symbol("synched",0);
	this.instance_3.setTransform(150,177.1,1,1,0,0,0,150,156.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(42).to({startPosition:0,_off:false},0).wait(1094));

	// Layer 4
	this.instance_4 = new lib.Symbol2_1("synched",0);
	this.instance_4.setTransform(81,130.1,1,1,0,0,0,21,20.5);
	this.instance_4.alpha = 0.762;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(47).to({startPosition:0,_off:false},0).wait(1089));

	// Layer 2
	this.instance_5 = new lib.Symbol13_1("synched",0);
	this.instance_5.setTransform(157,258,1,1,0,0,0,132.5,139.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(13).to({startPosition:0,_off:false},0).to({_off:true},1025).wait(98));

	// Layer 1
	this.instance_6 = new lib.Tween40("synched",0);
	this.instance_6.setTransform(150,617.5,1,0.008);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({scaleY:1,y:300},14,cjs.Ease.get(1)).to({_off:true},1024).wait(98));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,614.9,300,5.1);


(lib.Symbol5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 10
	this.instance_3 = new lib.Symbol16_1("synched",0);
	this.instance_3.setTransform(150,-107.5,1,1,0,0,0,126,21.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({startPosition:0,_off:false},0).wait(1104));

	// Layer 9
	this.instance_4 = new lib.adamcopy("synched",0);
	this.instance_4.setTransform(34.9,233.3,0.651,0.651,0,0,0,-47.3,-12.9);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(42).to({startPosition:0,_off:false},0).wait(1101));

	// Layer 8
	this.instance_5 = new lib.Symbol("synched",0);
	this.instance_5.setTransform(150,177.1,1,1,0,0,0,150,156.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(49).to({startPosition:0,_off:false},0).wait(1094));

	// Layer 7
	this.instance_6 = new lib.Symbol2_1("synched",0);
	this.instance_6.setTransform(81,130.1,1,1,0,0,0,21,20.5);
	this.instance_6.alpha = 0.762;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(54).to({startPosition:0,_off:false},0).wait(1089));

	// Layer 6
	this.instance_7 = new lib.Symbol6_1("synched",0);
	this.instance_7.setTransform(144,279.8,1,1,0,0,0,141.5,111.8);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(27).to({startPosition:0,_off:false},0).wait(1116));

	// Layer 5
	this.instance_8 = new lib.Symbol8_1("synched",0);
	this.instance_8.setTransform(133,-57.4,1,1,0,0,0,30.5,86);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(21).to({startPosition:0,_off:false},0).to({_off:true},1119).wait(3));

	// Layer 4
	this.instance_9 = new lib.Symbol7_1("synched",0);
	this.instance_9.setTransform(147,108,1,1,0,0,0,150,131.5);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(17).to({startPosition:0,_off:false},0).to({_off:true},1121).wait(5));

	// Layer 2
	this.instance_10 = new lib.Symbol9_1("synched",0);
	this.instance_10.setTransform(150,111,1,1,0,0,0,150,156);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(11).to({startPosition:0,_off:false},0).to({_off:true},1125).wait(7));

	// Layer 1
	this.instance_11 = new lib.Symbol10_1("synched",0);
	this.instance_11.setTransform(150,356.5,1,1,0,0,0,150,87.5);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(5).to({startPosition:0,_off:false},0).to({_off:true},1128).wait(10));

	// Layer 3
	this.instance_12 = new lib.Symbol11_1("synched",0);
	this.instance_12.setTransform(146,140.5,1,5.049,0,0,0,156,60.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true},1133).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.9,-166.4,312,613.5);


(lib.Symbol1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 7
	this.instance_14 = new lib.Symbol15_1("synched",0);
	this.instance_14.setTransform(145.7,64,1,1,0,0,0,123.5,22.2);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(35).to({startPosition:0,_off:false},0).wait(987));

	// Layer 6
	this.instance_15 = new lib.adamcopy("synched",0);
	this.instance_15.setTransform(34.9,392.3,0.651,0.651,0,0,0,-47.3,-12.9);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(28).to({startPosition:0,_off:false},0).wait(994));

	// Layer 4
	this.instance_16 = new lib.Symbol("synched",0);
	this.instance_16.setTransform(150,274,1,1,0,0,0,150,156.5);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(23).to({startPosition:0,_off:false},0).wait(999));

	// Layer 5
	this.instance_17 = new lib.Symbol2_1("synched",0);
	this.instance_17.setTransform(81,241,1,1,0,0,0,21,20.5);
	this.instance_17.alpha = 0.762;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(35).to({startPosition:0,_off:false},0).wait(987));

	// Layer 3
	this.instance_18 = new lib.x5();
	this.instance_18.setTransform(20.5,512);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_18}]},7).to({state:[]},997).wait(18));

	// Layer 2
	this.instance_19 = new lib.Symbol3_1("synched",0);
	this.instance_19.setTransform(151,311,1,1,0,0,0,116.5,178);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(7).to({startPosition:0,_off:false},0).to({_off:true},997).wait(18));

	// Layer 1
	this.instance_20 = new lib.Symbol4_2("synched",0);
	this.instance_20.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).to({_off:true},1004).wait(18));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;